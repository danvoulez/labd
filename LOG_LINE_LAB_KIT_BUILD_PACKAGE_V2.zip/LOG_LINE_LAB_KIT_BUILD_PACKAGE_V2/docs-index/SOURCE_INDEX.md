# Source Index

## Active build docs

```txt
README.md
00_START_HERE.md
01_PROJECT_CHARTER.md
build-pack/*
atlas/ATLAS_TABELA.md
atlas/MAP.md
```

## Reduced docs

```txt
simple-docs/00_vision.md
simple-docs/01_the_act.md
simple-docs/02_the_method.md
simple-docs/03_the_lab.md
simple-docs/04_apps_and_cli.md
simple-docs/05_the_bench.md
simple-docs/06_manhattan.md
simple-docs/07_glossary.md
simple-docs/08_how_we_build_it.md
```

## Lab Kit corpus

```txt
labkit-docs/00_ORIGIN_SCOPE_NOTE.md
labkit-docs/01_LOG_LINE_ACT.md
labkit-docs/02_LOGLINE_LAB_KIT_PRODUCT.md
labkit-docs/03_LABKIT_EXPERIENCE_LOOP.md
labkit-docs/04_LABKIT_SURFACES.md
labkit-docs/05_AUTHORITY_AND_SCOPE.md
labkit-docs/06_PACKS_AND_PROFILES.md
labkit-docs/07_LABKIT_IMPLEMENTATION_BLUEPRINT.md
labkit-docs/08_GENERATOR_INPUTS.md
labkit-docs/09_RECOVERY_PROTOCOL.md
labkit-docs/10_PLANNING_CORPUS_NOTES.md
labkit-docs/11_IMPLEMENTATION_REPAIR_NOTES.md
labkit-docs/12_CORPUS_INDEX.md
labkit-docs/13_CHECKSUMS.md
labkit-docs/V1_1_CHANGELOG.md
```

## Context docs

```txt
source-fruits/minilab-context/
source-fruits/manhattan/
source-fruits/foundation-exploration/
```

## Rule

The active build docs govern the package. Source fruits are included for traceability and future extraction, not as competing project roots.
