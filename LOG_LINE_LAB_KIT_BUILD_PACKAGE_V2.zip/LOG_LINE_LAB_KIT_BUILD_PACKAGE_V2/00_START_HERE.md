# START HERE — LogLine Lab Kit Build Package v2

This package exists to stop the architecture from being re-solved.

There is one project:

```txt
logline-lab-kit
```

There is one build-control folder:

```txt
logline-lab-kit/build-pack/
```

The task is **repository recovery + assembly + build**, not open-ended planning.

---

## First command to the builder

Use this prompt:

```txt
OPERATOR_PROMPT_V2.md
```

Do not use older prompts unless they agree with v2.

---

## Mandatory first run

The first run is not feature implementation.

The first run must produce:

```txt
SOURCE_FRUITS_CLASSIFICATION.md
REPO_ASSEMBLY_PLAN.md
ACCEPTANCE_STATUS.md
```

Only after those three files exist may implementation start.

If an agent asks “should I continue with Phase X?” before producing those files, the agent failed the task.

---

## What this package contains

```txt
build-pack/       final architecture, ownership, build order, acceptance
atlas/            exhaustive table and map
simple-docs/      reduced public/product language
labkit-docs/      Lab Kit corpus, recovery protocol, repair notes
source-fruits/    raw recovered code/docs; useful but not authority
repo-skeleton/    target project skeleton
operator/         strict prompts and execution protocols
```

---

## What to build

A complete v0, not a toy demo and not a new architecture.

Complete v0 means:

```txt
Act core
Lab host
CLI
local outbox/cache
spine profile
projections
blocked Acts
evidence
receipt candidates
pack/profile loader
clock
worker boundary
MCP/app boundary
reports
benches
tests
recovery scans
one serious Manhattan L-06 proof
```

---

## The first real product circuit

```txt
Act
→ validation
→ canonical bytes
→ hash
→ local outbox
→ configured spine
→ projection
→ blocked Act / evidence / receipt candidate
→ Lab report
```

This is the smallest complete circuit that proves the product exists.

---

## The first serious real-world proof

```txt
Manhattan L-06
```

Target:

```txt
LAB_8GB emits an Act to check the Ethernet peer link.
The gate admits it.
The worker runs the real ping over Ethernet.
Evidence returns.
A scoped receipt closes only L-06.
A projection shows the machine healthy.
```

This proves Lab Kit can run a serious physical pack without becoming that pack.
