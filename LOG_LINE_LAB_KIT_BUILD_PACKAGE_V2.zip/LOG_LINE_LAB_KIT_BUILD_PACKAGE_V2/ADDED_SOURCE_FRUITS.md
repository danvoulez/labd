# Added Source Fruits

The uploaded code/repo ZIPs have been added under:

```txt
source-fruits/
```

They are deliberately preserved as raw fruits and inventories. They are not automatically promoted into core.

Start with:

```txt
source-fruits/SOURCE_FRUITS_INVENTORY.md
source-fruits/recovery-notes/RECOVERY_ORDER.md
```

Then recover into the project tree according to:

```txt
build-pack/02_REPO_STRUCTURE.md
build-pack/03_MODULE_OWNERSHIP_MATRIX.md
```
