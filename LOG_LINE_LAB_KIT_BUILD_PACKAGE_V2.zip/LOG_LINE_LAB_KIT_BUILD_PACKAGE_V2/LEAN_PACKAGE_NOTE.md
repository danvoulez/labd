# Lean Package Note

This package is the downloadable build package with source fruits, but without heavyweight raw archives or generated build dependencies.

Excluded patterns:
- `source-fruits/incoming-zips/*.zip`
- `node_modules/`
- `target/`
- `.next/`
- `dist/`
- `build/`
- `.git/`
- `__MACOSX/`
- `.DS_Store`
- caches and coverage outputs

The package keeps:
- the build pack
- ATLAS and maps
- simple docs
- Lab Kit docs
- Manhattan docs
- Minilab context docs
- extracted source fruits from the smaller uploaded repos
- inventories and recovery notes

The huge `Archive(1)(1).zip` is deliberately not included. It should be handled later as raw recovery material only.
