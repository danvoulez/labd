# LogLine Lab Kit Build Package v2

This is the corrected, stricter package for building **one project**:

```txt
logline-lab-kit
```

Use:

```txt
OPERATOR_PROMPT_V2.md
```

Do not use older prompts as the controlling instruction.

---

## What changed in v2

v2 fixes the failure mode where an agent reads acceptance tests as a menu and asks which phase to implement.

Now the package requires:

```txt
SOURCE_FRUITS_CLASSIFICATION.md
REPO_ASSEMBLY_PLAN.md
ACCEPTANCE_STATUS.md
```

before any feature implementation.

---

## First files to read

```txt
00_START_HERE.md
OPERATOR_PROMPT_V2.md
operator/DO_NOT_NEGOTIATE.md
operator/FIRST_RUN_PROTOCOL.md
operator/ACCEPTANCE_DEPENDENCY_RULES.md
build-pack/00_BUILD_CONTEXT.md
build-pack/01_FINAL_ARCHITECTURE_TREE.md
build-pack/02_REPO_STRUCTURE.md
build-pack/03_MODULE_OWNERSHIP_MATRIX.md
build-pack/04_BUILD_ORDER.md
build-pack/05_ACCEPTANCE_TESTS.md
build-pack/06_GHOSTS_AND_OPEN_DECISIONS.md
build-pack/07_ARCHIVE_AND_DEBRIS_POLICY.md
atlas/ATLAS_TABELA.md
```

---

## Core decision

```txt
One project: logline-lab-kit
One build-control folder: logline-lab-kit/build-pack
```

No new root names.
