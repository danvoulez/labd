# Source Fruits Recovery Order

## Rule

Raw source fruits are not authority. They become project material only after classification and repair.

## Order

### 1. Use `LogLine-Lab-Kit-online-spine (3).zip`

Primary for:

```txt
profiles/supabase/
crates/logline-lab-supabase/
local/outbox/spine path
repair receipt references
```

Why: it is the most directly aligned to the online spine circuit.

### 2. Compare with `LogLine-Lab-Kit-clean (1).zip`

Use as cleaned baseline candidate, but scan for:

```txt
logline-lab-artifacts
artifact terminology
file-as-truth language
SQLite-as-ledger/truth language
```

### 3. Compare with `logline-lab-kit-ready (1).zip`

Use for breadth: labd, outbox, local SQL, migrations, docs. Do not promote stale docs as authority.

### 4. Mine `logline_lab_kit_rust.zip`

Use for older Rust structures and vendored Foundation. Treat old Minilab-heavy docs as archive context.

### 5. Mine `merging-codex-update-labd-to-comply-with-core-laws.zip`

Use for focused `labd`, engine, constitutional-runtime bridge and gate tests.

### 6. Preserve `Archive(1)(1).zip`

Do not extract by default. Use only if a file is missing from the smaller fruits.

## First Recovery Target

Create:

```txt
logline-lab-kit/recovery/FRUIT_CLASSIFICATION.md
```

Then classify the first 100 files by target:

```txt
core
profile
pack
runtime
adapter
deploy
docs
test/bench
recovery-only
debris
```

## First Build Target After Recovery

```txt
crates/logline-act
crates/logline-lab-core
crates/logline-lab-local
crates/logline-lab-spine
profiles/supabase/migrations
```
