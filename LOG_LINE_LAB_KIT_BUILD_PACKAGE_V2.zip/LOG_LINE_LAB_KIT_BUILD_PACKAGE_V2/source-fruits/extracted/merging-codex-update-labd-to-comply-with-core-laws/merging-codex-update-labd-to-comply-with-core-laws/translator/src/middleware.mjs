import { spawn } from 'node:child_process';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export function sentenceToCandidateAct(sentence, { who = 'dan', now = new Date().toISOString() } = {}) {
  const normalized = sentence.trim();
  const did = normalized.toLowerCase().includes('health') ? 'probe.health' : 'register';
  return {
    who,
    did,
    this: {
      execute: {
        action: did,
        params: { sentence: normalized }
      }
    },
    when: now,
    confirmed_by: { witness: 'human.confirmation.required' },
    if_ok: 'close',
    if_doubt: 'ask_for_evidence',
    if_not: 'reject',
    status: 'pending'
  };
}

export async function admitSentenceWithLabd(sentence, { labd = 'labd', register, who, now } = {}) {
  if (!register) throw new Error('register path is required');
  const dir = await mkdtemp(join(tmpdir(), 'labd-translator-'));
  try {
    const actPath = join(dir, 'candidate.act.json');
    await writeFile(actPath, JSON.stringify(sentenceToCandidateAct(sentence, { who, now }), null, 2));
    return await runJson(labd, ['admit', actPath, '--register', register]);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

function runJson(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', code => {
      if (code !== 0) {
        reject(new Error(`${command} exited ${code}: ${stderr}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch (error) {
        reject(new Error(`labd returned non-JSON: ${error.message}`));
      }
    });
  });
}
