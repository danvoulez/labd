import test from 'node:test';
import assert from 'node:assert/strict';
import { sentenceToCandidateAct } from '../src/middleware.mjs';

test('health sentence becomes a nine-slot candidate Act', () => {
  const act = sentenceToCandidateAct('please run the L-06 health probe', {
    who: 'dan',
    now: '2026-06-05T00:00:00Z'
  });
  assert.equal(act.who, 'dan');
  assert.equal(act.did, 'probe.health');
  assert.equal(act.when, '2026-06-05T00:00:00Z');
  assert.equal(act.if_ok, 'close');
  assert.equal(act.if_doubt, 'ask_for_evidence');
  assert.equal(act.if_not, 'reject');
  assert.equal(act.status, 'pending');
  assert.equal(act.this.execute.action, 'probe.health');
});
