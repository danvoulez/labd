# LogLine lab merge runtime

This workspace marries the referenced `logline-engine` crates and `constitutional-runtime` into one Rust process named `labd`.

## Gates implemented

- `labd certify` reads a real nine-slot Act, runs it through the LogLine engine, and emits the Act LAB-ID.
- `labd admit` evaluates it with register-fed passports, visas, and gates.
- `labd route` / `labd lower` compile the Act through Strong Grammar into IR and a lowered operational plan.
- `labd close` executes only through real dispatchers, records evidence, and asks `logline-status` to close admitted Acts.
- `labd tick` reads due Acts and runs each through the same close path.
- `translator/src/middleware.mjs` turns a human sentence into a candidate Act and can call `labd admit`.

## Example

Operational mode writes to the Supabase spine and requires `SUPABASE_REST_BASE` plus `SUPABASE_KEY`:

```bash
cargo run -p labd -- --now 2026-06-05T00:00:00Z close register/acts/l06-health.act.json --register register/projection.json
```

Dry-run mode may write a scratch file, but that file is non-authoritative:

```bash
cargo run -p labd -- --dry-run --evidence-store file --now 2026-06-05T00:00:00Z close register/acts/l06-health.act.json --register register/projection.json --scratch /tmp/labd-scratch.jsonl
```

One citizen: the LogLine Act. Passport, visa, gate, receipt, evidence are Acts or projections of Acts. Persistence is the spine; a file is never the ledger.
