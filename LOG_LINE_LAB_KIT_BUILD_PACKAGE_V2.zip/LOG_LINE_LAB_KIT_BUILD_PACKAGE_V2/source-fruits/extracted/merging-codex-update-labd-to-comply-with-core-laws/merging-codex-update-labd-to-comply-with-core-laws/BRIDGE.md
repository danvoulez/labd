# Gate 1 bridge notes

This repository now makes the seam executable instead of merely describing it.

## Compiled shape

1. A nine-slot JSON Act is parsed by `labd::act::Act`.
2. `Act::to_proposed` produces `constitutional_runtime::ProposedLogLineAct` for `evaluate_admission`.
3. `RegisterProjection::admission_context` turns closed passports, visas, and gates into the pure in-memory `AdmissionContext`; operational admission state must be projected from spine Acts.
4. `Act::strong_json` lowers the Act's `this.execute` payload to Strong Grammar `Execute` JSON.
5. `compile_strong_json_to_ir_graph` emits the constitutional IR graph.
6. `plan_ir_graph` validates, routes, and lowers the graph with `StandardRuntimeLowerer` and capability manifests derived from Register gates.
7. `execute_compiled_plan` runs through real dispatchers such as `ShellProbeDispatcher`; simulated dispatch exists only for tests or explicit dry-run.
8. `close_execution_evidence` writes evidence records to the operational spine, or to an explicit scratch file in dry-run only.
9. `logline_status::run` closes admitted Acts through the frozen runtime-loaded LogLine canon.
10. The receipt carries `lab_id` as the Act content hash, distinct from receipt tuple/content/envelope hashes.

## Real vs simulated

REAL: admission evaluation, Strong Grammar compilation, IR planning, frozen-canon guard, Act LAB-ID certification, shell probe execution, evidence closure, and engine status closure for admitted Acts.

SIMULATED: only explicit `--dry-run`/test scratch paths. No simulated dispatcher is the operational default, and a scratch file is never the ledger.

## Gate result

The fixture `register/acts/lab512-register.act.json` is admitted by the real admission evaluator and produces a lowered plan. The fixture `register/acts/l06-health.act.json` now closes only if real dispatch produces evidence; otherwise it routes to doubt/not evidence instead of claiming false closure.

## Deferred by design

Remote summon transport, TS/oclif CLI, bench UI, experiments, capacity projections, full ProviderDispatcher and McpDispatcher transport wiring remain outside this slice until registered endpoint/tool Acts are available.

One citizen: the LogLine Act. Passport, visa, gate, receipt, evidence are Acts or projections of Acts. Persistence is the spine; a file is never the ledger.
