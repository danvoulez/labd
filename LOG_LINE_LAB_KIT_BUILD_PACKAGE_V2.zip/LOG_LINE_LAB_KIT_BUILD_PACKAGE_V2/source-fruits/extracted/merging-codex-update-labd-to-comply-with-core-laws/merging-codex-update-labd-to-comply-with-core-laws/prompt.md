
The one sentence
Marry the two Rust engines you already built into a single runtime process, prove it on one real contract end-to-end, and only then grow breadth.

The shape (this part is settled)
human → translator (TS, AI SDK) → candidate LogLine Act
        → labd (ONE Rust binary, embeds both engines):
             logline-engine        certify · hash · receipt · if_ok/if_doubt/if_not
             constitutional-runtime admit · route · lower · evidence
        → execute (MCP / provider / probe)
        → evidence → receipt → Supabase projection
the clock (lab tick) sweeps NOW and feeds due Acts into labd
the Register is a projection that FEEDS admission (passports/visas/gates)
The cut — ruthless
Build (ours, small): labd (the marriage binary + its Rust CLI), the clock (lab tick), the Register→AdmissionContext adapter, the Supabase projections, the translator middleware.
Borrow (don't touch): both Rust engines, MCP host-runtime, mistral.rs, Hermes, Supabase, the AI SDK.
Defer (named, not done): the TS/oclif CLI, remote transport for summon, the bench UI, experiments, capacity projections, IR→Small-Operational-Grammar execution by small models (its backend isn't built — that's research, not wiring).
Park: What-Runs-Natively (the federation layer).
The sequence — gates, not phases
The difference from the attachment: each step has a pass/fail gate. If a gate fails, we stop and replan there — we don't march. I've front-loaded the riskiest unknown on purpose, so we learn the worst thing first.

Gate 0 — Foundations. Rotate the three live secrets. Then on lab512: cargo build && cargo test && cargo test --features supabase-evidence on constitutional-runtime. Gate: it compiles and tests pass. (If it doesn't, that's the real state of the "second engine," and we find out in an hour, not a month.)
Gate 1 — The seam (make-or-break). A 50-line Rust harness: take one real register Act → push it through strong_grammar → planning_compiler → evaluate_admission → get an AdmissionRuling. Write BRIDGE.md from what actually compiles. Gate: our 9-slot Act becomes admissible IR and gets a ruling. (This is the one assumption most likely to break. If the two engines don't speak to each other here, the whole plan changes — so we test it before building anything on top.)
Step 2 — labd, the marriage. One Rust binary embedding both engines, exposing certify / admit / route / lower / close / evidence. In-process — no network, no second language yet. Gate: one Act goes surface → admit → lower → receipt → a Supabase evidence_records row, read back.
Step 3 — lab tick. A Rust subcommand: query due Acts from the spine, run each through labd, close, project. Gate: the L-06 health Act resolves end-to-end on a real tick — admitted, probed, receipted, projected. This is "the Lab executes contracts," proven once.
Step 4 — Register feeds admission. The adapter that turns register/visa/gate Acts in the spine into the AdmissionContext labd consumes. Gate: admission uses real registered identities, not hardcoded passports.
Step 5 — Clean homes + migrate. Now (core proven) make ~/lab/, move engine/, constitutional-runtime/, register/, labd/ in, emit placement Acts. Not before — a clean folder around broken wiring is just tidy debt.
Step 6 — The translator. AI SDK middleware (TS) as a client of labd: messy sentence → candidate Act → lab admit. Gate: one human sentence becomes a candidate Act you confirm.
Step 7+ — Breadth. Bench projections, more Manhattan contracts, capacity bands, experiments, the TS/oclif CLI, remote transport. All deferred until 0–6 hold.
Decisions I'm making (so we stop re-asking)
Canonical root: fresh ~/lab/. Migrate good code in; archive the scatter.
One language for the risky core: the runtime is Rust (labd + a Rust CLI). The translator is TS (AI SDK). They meet at one line — TS calls labd. No cross-language seam inside the part we're proving.
Transport: in-process first (labd embeds both engines directly). HTTP/MCP only when we actually need remote summon — not now.
Identity = content_hash. Settled and proven.
Manhattan = a pack of health Acts, starting with L-06 (it already has a real repair + proof). The old daemon is reference, not runtime.
Park What-Runs-Natively.
What stays honestly open (no pretending)
The grammar seam (Gate 1) — the real risk. Unproven until we run it.
Small models executing Operational Grammar — backend not built; research, deferred.
Whether labd later splits into a service — yes, when remote summoning is real; not a v1 concern.
The first move
Not folders. Not READMEs. Not a line of TypeScript. It's:

1. rotate the 3 secrets
2. lab512: build + test constitutional-runtime  (Gate 0)
3. the 50-line harness: one register Act → admission ruling  (Gate 1)
If Gate 1 turns green, I'll have proven the two engines marry, and the rest is genuinely downhill. If it turns red, we'll know exactly where your architecture needs one more real piece — and we'll have spent a day, not a month, to find out.

That's my plan. The only thing I changed from your instinct is order: prove the scariest seam first, build the marriage binary before the conveniences, close one contract before opening ten.

Shall we lock this — and next session I open with Gate 0?

give more details of this merge

The merge is the whole ballgame, so let me lay it out concretely — and flag honestly what I've actually read in the source versus what Gate 1 still has to confirm.

What each engine actually is
logline-engine (verified from source): a Rust workspace — nine slot crates + logline-status + logline-cli. logline_status exports content_hash/tuple_hash/compute_envelope_hash (canonical JSON + sha256), Canon::from_json_path, run_with_context, walk, validate_against_canon, Branch. Input: a 9-slot Act. Output: a branch verdict (if_ok/if_doubt/if_not) + logline.receipt.v0.
constitutional-runtime (verified): a Rust library. Modules I confirmed: admission (Passport, Visa, Gate, Boundary, AdmissionContext{passports,visas,gates,now}, AdmissionRuling, evaluate_admission — pure), ir (16 primitives), policy (A/B/C/D), capability::CapabilityManifest, lowering (Lowerer trait → OperationalCommand), planning_compiler (surface→IR→admission→routing→lowering), plan_executor (runs a plan against registered runtime commands), strong_grammar (JSON→IR), operational_grammar (the flat line language), evidence (SupabaseRestEvidenceStore + SQLite + File). Its README states it does not emit receipt.v0 — it delegates that to the engine's receipt crate.
That last sentence is the design intent for the merge, in their own words: constitutional-runtime governs; the engine closes.

The division of labor (this resolves the "two judges?" confusion)
They judge different things, so they layer rather than collide:

constitutional-runtime  →  "Is this ACTOR allowed to cross this boundary, and how does it route/lower?"
                            passport + visa + gate + policy + capability  →  IR  →  OperationalCommand
logline-engine          →  "Is this ACT evidentially closed?"
                            confirmed_by + evidence  →  if_ok / if_doubt / if_not  →  receipt.v0
One is authorization + routing (who/where/how), the other is evidence closure (is it true yet). labd runs both, in order: admit → lower → execute → close.

(Honesty flag: the exact boundary — does planning_compiler call evaluate_admission internally per IR node, and does it want the engine's branch verdict as an input or only at closure — is the #1 thing Gate 1 confirms. My read is "admission first, engine-close last," but I haven't traced planning_compiler's internals yet.)

The type seam — the actual data flow
This is the merge, hop by hop. Types in CamelCase are ones I either saw or expect; the ⚠ marks where I have to confirm the field-level shape:

1.  LogLine Act (JSON, 9 slots)                      ← from translator or the Register
2.  → ProposedLogLineAct                  ⚠ confirm fields (who/did/this…)  [admission input]
3.  + AdmissionContext { passports, visas, gates, now }   ← built by the Register adapter
4.  → evaluate_admission(proposed, ctx) → AdmissionRuling { decision, passport_id, visa_id, gate_id }
        ├─ decision = No  → stop, emit a blocked/ghost Act, project. (no execution)
        └─ decision = Yes → continue
5.  → compile to IR        ⚠ via strong_grammar (JSON) OR a direct Act→IRPrimitive map
6.  → planning_compiler → CompiledOperationalPlan  (routing + lowering, deterministic, no side effects)
7.  → plan_executor runs the plan against REGISTERED RUNTIME COMMANDS   ⚠ this is the substrate binding
        (a registered command = "run probe", "call provider@LAB512", "invoke MCP tool")
8.  → EvidenceRecord(s)  → EvidenceStore (Supabase/SQLite/File)
9.  → logline-engine: run_with_context(act, evidence) → Branch + receipt.v0   ← THE CLOSE
10. → receipt + content_hash → Supabase projection (the Register / receipts / evidence views)
Steps 2 and 5 are the seam Gate 1 exists to prove: does our 9-slot Act cleanly become a ProposedLogLineAct and an IR graph? If yes, the rest is plumbing.

How they physically combine
One Cargo workspace, labd depends on both as path deps — no copying, no forking:

~/lab/labd/Cargo.toml
  [dependencies]
  logline-status         = { path = "../engine/crates/status" }
  constitutional-runtime = { path = "../constitutional-runtime", features = ["supabase-evidence"] }
~/lab/labd/src/
  main.rs        clap CLI: certify | admit | route | lower | run | tick | close
  runtime.rs     the orchestrator: the 10-hop flow above, in one function
  bridge.rs      Act ⇄ ProposedLogLineAct ⇄ IR   (the seam — the only genuinely new logic)
  substrate.rs   the registered runtime commands (probe / provider / mcp)  → impl Lowerer/executor target
  spine.rs       AdmissionContext from the Register projection + SupabaseRestEvidenceStore config
bridge.rs is the only real new code. Everything else is calling existing functions in the right order. That's the point — the merge is mostly sequencing two libraries, not writing a third engine.

The substrate binding (step 7, the part the README under-documents)
plan_executor "executes a compiled plan against registered runtime commands." So labd at startup registers a small table of commands the lowered IR can dispatch to:

"probe.shell"      → run a bounded command, capture stdout/exit → EvidenceRecord   (Manhattan L-06 uses this)
"provider.infer"   → call mistral.rs @ 10.88.0.10:1234 over the cable             (the model substrate)
"mcp.tool"         → invoke an MCP tool on a target LAB                            (the hands)
InferSurface::Named("lab-512") from the IR resolves — via the Register binding — to 10.88.0.10:1234. That's where "summon by LAB ID" actually lands: the substrate id in the IR → the endpoint in the Register → a registered command. No separate summon engine.

The receipt handshake (the most important contract)
constitutional-runtime produces a plan result + evidence; it must not mint a receipt. The engine does:

plan_result + evidence  ──>  logline_status::run_with_context(act, evidence)
                              → Branch (if_ok/if_doubt/if_not)
                              → receipt.v0 { hashes: { content_hash, tuple_hash, envelope_hash }, ... }
                        ──>  content_hash = the receipt's identity; written to the spine
So evidence with no witness still closes — to if_doubt — and that's a valid close, not a failure. The engine is the only thing that says "true."

The spine wiring (concrete, from evidence_supabase.rs)
SupabaseRestEvidenceStore::new(
  "https://jlwfigogxftsegzwmaon.supabase.co/rest/v1",   // rest_v1_base
  "evidence_records",                                    // table (its documented schema)
  &service_key,                                          // POST /rest/v1/evidence_records
)
It already does the row insert we hand-rolled with pg. We delete our script; we configure this.

Gate 1, exactly
A bridge.rs unit test, ~50 lines, no network:

load   lab-512 register Act (the 9-slot JSON we already have)
build  a minimal AdmissionContext with one closed Passport (subject="dan") + one Visa allowing did="register"
call   evaluate_admission(proposed, ctx)
assert AdmissionRuling.decision == Yes  AND passport_id/visa_id are populated
then   map the Act → one IR primitive, run planning_compiler, assert a CompiledOperationalPlan comes out
Green = the two engines speak; labd is real plumbing from here. Red = we see the exact field/shape mismatch and design bridge.rs to fix it — which is the one piece worth thinking hard about anyway.

The honesty ledger — verified vs. to-confirm
Verified (read in source): the engine's hash/receipt functions; constitutional-runtime's module list, evaluate_admission + Passport/Visa/Gate/AdmissionContext/AdmissionRuling, the Supabase evidence store signature, the two grammars exist, "delegates receipt to the engine."
To confirm in Gate 0/1 (haven't traced): ProposedLogLineAct's exact fields; whether planning_compiler calls evaluate_admission internally; how a single Act maps to IR (strong_grammar vs direct); the plan_executor "registered runtime commands" API; run_with_context's exact signature for passing evidence.
Genuinely unbuilt (don't plan on it yet): small models emitting/consuming Operational Grammar — ingress.rs says that backend is "scheduled for the Agent Runtime phase."
So the merge is: one workspace, one new file (bridge.rs), two existing engines called in order, the engine closing every receipt. The risk is concentrated in bridge.rs, which is why Gate 1 pokes exactly there before we build anything on top.
