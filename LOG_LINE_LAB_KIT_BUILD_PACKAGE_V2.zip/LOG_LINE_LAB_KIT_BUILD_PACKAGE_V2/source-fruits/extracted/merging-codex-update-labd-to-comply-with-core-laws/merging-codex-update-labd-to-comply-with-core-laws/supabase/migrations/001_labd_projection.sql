-- Operational spine: Acts, receipts, and evidence are rows, never *.ndjson ledgers.
create table if not exists acts (
  content_hash text primary key,
  act jsonb not null,
  admitted boolean not null default false,
  inserted_at timestamptz not null default now()
);

create table if not exists receipts (
  content_hash text primary key,
  tuple_hash text not null,
  envelope_hash text not null,
  lab_id text not null references acts(content_hash),
  receipt jsonb not null,
  inserted_at timestamptz not null default now()
);

create table if not exists evidence_records (
  id bigserial primary key,
  content_hash text,
  kind text not null,
  payload jsonb not null,
  inserted_at timestamptz not null default now()
);

create or replace view register_admission_context as
select
  coalesce(jsonb_agg(act->'this') filter (where act->>'did' = 'register.passport' and admitted), '[]'::jsonb) as passports,
  coalesce(jsonb_agg(act->'this') filter (where act->>'did' in ('grant', 'grant.visa', 'register.visa') and admitted), '[]'::jsonb) as visas,
  coalesce(jsonb_agg(act->'this') filter (where act->>'did' = 'register.gate' and admitted), '[]'::jsonb) as gates
from acts;
