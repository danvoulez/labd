use constitutional_runtime::AdmissionDecision;

mod labd_tests {
    use anyhow::Result;
    use labd::act::Act;
    use labd::register::RegisterProjection;
    use serde_json::Value;
    use std::path::{Path, PathBuf};

    pub const NOW: &str = "2026-06-05T00:00:00Z";

    pub fn repo_path(path: &str) -> PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR")).join("..").join(path)
    }

    pub fn load_act(path: &str) -> Result<Act> {
        let value: Value = serde_json::from_str(&std::fs::read_to_string(repo_path(path))?)?;
        Act::from_value(value)
    }

    pub fn load_register() -> Result<RegisterProjection> {
        RegisterProjection::from_path(repo_path("register/projection.json"))
    }
}

use labd_tests::{load_act, load_register, repo_path, NOW};

#[test]
fn gate_1_register_act_admits_and_lowers() {
    let act = load_act("register/acts/lab512-register.act.json").unwrap();
    let register = load_register().unwrap();
    let outcome =
        labd::bridge::admit_route_lower(&act, &register.admission_context(NOW.into())).unwrap();
    assert_eq!(outcome.admission.decision, AdmissionDecision::Yes);
    assert!(outcome.admission.passport_id.is_some());
    assert!(outcome.admission.visa_id.is_some());
    assert!(outcome.admission.gate_id.is_some());
    assert!(!outcome.graph.is_empty());
    assert!(!outcome.plan.node_plans.is_empty());
}

#[test]
fn gate_admit_no_blocks_without_receipt_v0() {
    let mut act = load_act("register/acts/l06-health.act.json").unwrap();
    act.who = "intruder".into();
    let register = load_register().unwrap();
    let evidence = tempfile::NamedTempFile::new().unwrap();
    let runtime = labd::runtime::LabRuntime::local(evidence.path()).unwrap();
    let receipt = runtime
        .run_act(&act, &register.admission_context(NOW.into()))
        .unwrap();
    assert_eq!(receipt.receipt_version, "blocked.ghost.v1");
    assert!(!receipt.admitted);
    assert!(receipt.execution.is_null());
    assert!(receipt
        .evidence
        .iter()
        .any(|r| r.kind == "admission.blocked"));
}

#[test]
fn l06_health_uses_real_dispatch_evidence() {
    let act = load_act("register/acts/l06-health.act.json").unwrap();
    let register = load_register().unwrap();
    let evidence = tempfile::NamedTempFile::new().unwrap();
    let runtime = labd::runtime::LabRuntime::local(evidence.path()).unwrap();
    let receipt = runtime
        .run_act(&act, &register.admission_context(NOW.into()))
        .unwrap();
    assert_eq!(receipt.act["did"], "probe.health");
    assert_eq!(receipt.receipt_version, "receipt.v1");
    assert_eq!(receipt.lab_id, labd::runtime::act_lab_id(&act).unwrap());
    assert!(!receipt.envelope_hash.is_empty());
    assert!(receipt
        .evidence
        .iter()
        .any(|r| r.kind == "exec.result" && r.payload_json["detail"]["substrate"] == "shell.real"));
    assert!(!serde_json::to_string(&receipt)
        .unwrap()
        .contains("local.simulated"));
}

#[test]
fn due_tick_runs_l06() {
    let register = load_register().unwrap();
    let evidence = tempfile::NamedTempFile::new().unwrap();
    let runtime = labd::runtime::LabRuntime::local(evidence.path()).unwrap();
    let receipts = labd::clock::tick_file(
        &runtime,
        repo_path("register/due-acts.json"),
        &register,
        NOW,
    )
    .unwrap();
    assert_eq!(receipts.len(), 1);
    assert_eq!(receipts[0].act["did"], "probe.health");
}

#[test]
fn gate_canon_is_frozen() {
    assert!(
        labd::runtime::load_frozen_canon(Some(repo_path("engine/source/logline.canon.json")))
            .is_ok()
    );
    let unknown = tempfile::NamedTempFile::new().unwrap();
    std::fs::write(unknown.path(), "{}").unwrap();
    assert!(labd::runtime::load_frozen_canon(Some(unknown.path().to_path_buf())).is_err());
}

#[test]
fn gate_certify_real() {
    let act = load_act("register/acts/l06-health.act.json").unwrap();
    let runtime =
        labd::runtime::LabRuntime::local(tempfile::NamedTempFile::new().unwrap().path()).unwrap();
    let certified = runtime.certify_act(&act).unwrap();
    assert_eq!(
        certified["lab_id"].as_str().unwrap(),
        labd::runtime::act_lab_id(&act).unwrap()
    );
    assert!(certified.get("receipt").is_some());
}

#[test]
fn gate_no_parallel_credential_types() {
    let repo = repo_path("");
    let output = std::process::Command::new("rg")
        .args(["--files", "-g", "*.v0.json"])
        .current_dir(&repo)
        .output()
        .unwrap();
    let files = String::from_utf8_lossy(&output.stdout);
    assert!(!files.contains("visa.v0.json"));
    assert!(!files.contains("passport.v0.json"));
    assert!(!files.contains("gate.v0.json"));
}

#[test]
fn gate_visa_is_an_act_projection() {
    let grant = serde_json::json!({
        "who": "dan",
        "did": "grant.visa",
        "this": {
            "visa_id": "visa.projected",
            "holder": "dan",
            "allowed_dids": ["probe.health"],
            "forbidden_dids": [],
            "status": "closed"
        },
        "when": NOW,
        "confirmed_by": {"witness": "test"},
        "if_ok": "close",
        "if_doubt": "ask",
        "if_not": "reject",
        "status": "closed"
    });
    let projection = labd::register::RegisterProjection::from_acts(&[grant]).unwrap();
    assert_eq!(projection.visas.len(), 1);
    assert_eq!(projection.visas[0].visa_id, "visa.projected");
}
