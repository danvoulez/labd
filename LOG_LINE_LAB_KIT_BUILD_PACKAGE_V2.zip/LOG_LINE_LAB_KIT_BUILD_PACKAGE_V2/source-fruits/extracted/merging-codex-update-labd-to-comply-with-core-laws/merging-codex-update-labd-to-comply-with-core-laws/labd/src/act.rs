use anyhow::{anyhow, Context, Result};
use constitutional_runtime::ProposedLogLineAct;
use logline_status::{canonical_json, LogLine};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Act {
    pub who: String,
    pub did: String,
    #[serde(rename = "this")]
    pub this_: Value,
    pub when: String,
    pub confirmed_by: Value,
    pub if_ok: String,
    pub if_doubt: String,
    pub if_not: String,
    pub status: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub metadata: Option<Value>,
}

impl Act {
    pub fn from_value(value: Value) -> Result<Self> {
        serde_json::from_value(value).context("invalid 9-slot LogLine Act")
    }

    pub fn to_value(&self) -> Value {
        serde_json::to_value(self).expect("Act is serializable")
    }

    pub fn to_proposed(&self) -> ProposedLogLineAct {
        ProposedLogLineAct {
            who: self.who.clone(),
            did: self.did.clone(),
            this: self.this_.clone(),
            confirmed_by: self.confirmed_by.clone(),
            if_ok: self.if_ok.clone(),
            if_doubt: self.if_doubt.clone(),
            if_not: self.if_not.clone(),
            status: self.status.clone(),
            metadata: self.metadata.clone(),
        }
    }

    /// Converts the structured 9-slot Act into the engine LogLine tuple.
    ///
    /// The `this` and `confirmed_by` slots stay structured in stored Acts, but the
    /// status engine accepts slot strings. Non-string slot values are flattened
    /// with the engine canonical JSON encoder (JCS-style sorted keys, compact
    /// arrays/objects) so LAB-ID/content-hash computation is reproducible across
    /// Register projection and runtime certification.
    pub fn to_engine_logline(&self) -> LogLine {
        LogLine::new(
            self.who.clone(),
            self.did.clone(),
            stable_slot_string(&self.this_),
            self.when.clone(),
            stable_slot_string(&self.confirmed_by),
            self.if_ok.clone(),
            self.if_doubt.clone(),
            self.if_not.clone(),
            self.status.clone(),
        )
    }

    pub fn strong_json(&self) -> Result<String> {
        if let Some(strong) = self.this_.get("strong_grammar") {
            return serde_json::to_string(strong).context("serialize embedded strong grammar");
        }
        if let Some(execute) = self.this_.get("execute") {
            let action = execute
                .get("action")
                .and_then(Value::as_str)
                .ok_or_else(|| anyhow!("this.execute.action must be a string"))?;
            let params = execute.get("params").cloned().unwrap_or_else(|| json!({}));
            return serde_json::to_string(
                &json!({"Execute": {"action": action, "params": params}}),
            )
            .context("serialize execute strong grammar");
        }
        serde_json::to_string(&json!({
            "Execute": {
                "action": format!("act.{}", self.did.replace([' ', '/', ':'], "_")),
                "params": {
                    "who": self.who,
                    "did": self.did,
                    "this": self.this_,
                    "when": self.when
                }
            }
        }))
        .context("serialize default act strong grammar")
    }
}

fn stable_slot_string(value: &Value) -> String {
    match value {
        Value::String(s) => s.clone(),
        other => canonical_json(other).expect("JSON value is canonically serializable"),
    }
}
