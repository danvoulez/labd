use constitutional_runtime::{
    DispatchOutcome, Dispatcher, EvidenceRecord, NodeId, OperationalCommand, RuntimeTarget,
};
use serde_json::{json, Value};
use std::{process::Command, sync::Mutex};

pub trait EvidenceCollectingDispatcher: Dispatcher {
    fn evidence(&self) -> Vec<EvidenceRecord>;
}

#[derive(Default)]
pub struct ShellProbeDispatcher {
    evidence: Mutex<Vec<EvidenceRecord>>,
}

impl ShellProbeDispatcher {
    pub fn evidence(&self) -> Vec<EvidenceRecord> {
        self.evidence
            .lock()
            .expect("evidence mutex poisoned")
            .clone()
    }

    fn push_exec_evidence(&self, node_id: &NodeId, success: bool, detail: Value) -> String {
        let evidence_ref = format!("labd://evidence/{}", node_id.0);
        self.evidence
            .lock()
            .expect("evidence mutex poisoned")
            .push(EvidenceRecord {
                kind: "exec.result".into(),
                payload_json: json!({
                    "node_id": node_id.0,
                    "success": success,
                    "output_ref": evidence_ref,
                    "detail": redact_secret_values(detail),
                }),
            });
        evidence_ref
    }
}

impl EvidenceCollectingDispatcher for ShellProbeDispatcher {
    fn evidence(&self) -> Vec<EvidenceRecord> {
        self.evidence()
    }
}

impl Dispatcher for ShellProbeDispatcher {
    fn dispatch(&self, node_id: &NodeId, command: &OperationalCommand) -> DispatchOutcome {
        if command.target_runtime != RuntimeTarget::OperationalGrammar {
            return DispatchOutcome::Blocked {
                reason: format!(
                    "no shell route for target_runtime {:?}",
                    command.target_runtime
                ),
            };
        }

        match (command.namespace.as_str(), command.verb.as_str()) {
            ("probe", "health") => run_ping_probe(self, node_id, command),
            ("cmd", _) | ("process", "execute") => run_shell_command(self, node_id, command),
            _ => DispatchOutcome::Blocked {
                reason: format!(
                    "no real dispatcher for {}.{} on {:?}",
                    command.namespace, command.verb, command.target_runtime
                ),
            },
        }
    }
}

fn run_ping_probe(
    dispatcher: &ShellProbeDispatcher,
    node_id: &NodeId,
    command: &OperationalCommand,
) -> DispatchOutcome {
    let target = command
        .args
        .get("address")
        .or_else(|| command.args.get("host"))
        .or_else(|| command.args.get("target"))
        .and_then(Value::as_str)
        .unwrap_or("127.0.0.1");
    let output = Command::new("ping").args(["-c", "3", target]).output();
    materialize_process_outcome(
        dispatcher,
        node_id,
        command,
        "ping",
        &["-c", "3", target],
        output,
    )
}

fn run_shell_command(
    dispatcher: &ShellProbeDispatcher,
    node_id: &NodeId,
    command: &OperationalCommand,
) -> DispatchOutcome {
    let Some(program) = command
        .args
        .get("program")
        .or_else(|| command.args.get("cmd"))
        .or_else(|| command.args.get("command"))
        .and_then(Value::as_str)
    else {
        return DispatchOutcome::Blocked {
            reason: "shell command requires program/cmd/command arg".into(),
        };
    };
    let output = Command::new(program).output();
    materialize_process_outcome(dispatcher, node_id, command, program, &[], output)
}

fn materialize_process_outcome(
    dispatcher: &ShellProbeDispatcher,
    node_id: &NodeId,
    command: &OperationalCommand,
    program: &str,
    args: &[&str],
    output: std::io::Result<std::process::Output>,
) -> DispatchOutcome {
    match output {
        Ok(output) => {
            let success = output.status.success();
            let detail = json!({
                "command": command,
                "substrate": "shell.real",
                "program": program,
                "args": args,
                "exit_code": output.status.code(),
                "stdout": String::from_utf8_lossy(&output.stdout),
                "stderr": String::from_utf8_lossy(&output.stderr),
            });
            let evidence_ref = dispatcher.push_exec_evidence(node_id, success, detail.clone());
            if success {
                DispatchOutcome::Success {
                    evidence_ref: Some(evidence_ref),
                    detail: Some(redact_secret_values(detail)),
                }
            } else {
                DispatchOutcome::Failure {
                    reason_code: "shell_exit_nonzero".into(),
                    detail: Some(redact_secret_values(detail).to_string()),
                    runtime_failure: None,
                }
            }
        }
        Err(error) => {
            let detail = json!({
                "command": command,
                "substrate": "shell.real",
                "program": program,
                "args": args,
                "error": error.to_string(),
            });
            dispatcher.push_exec_evidence(node_id, false, detail.clone());
            DispatchOutcome::Failure {
                reason_code: "shell_probe_unavailable".into(),
                detail: Some(redact_secret_values(detail).to_string()),
                runtime_failure: None,
            }
        }
    }
}

#[derive(Default)]
pub struct ProviderDispatcher;

impl Dispatcher for ProviderDispatcher {
    fn dispatch(&self, _node_id: &NodeId, command: &OperationalCommand) -> DispatchOutcome {
        DispatchOutcome::Blocked {
            reason: format!(
                "provider dispatcher requires a registered endpoint for {}.{}",
                command.namespace, command.verb
            ),
        }
    }
}

#[derive(Default)]
pub struct McpDispatcher;

impl Dispatcher for McpDispatcher {
    fn dispatch(&self, _node_id: &NodeId, command: &OperationalCommand) -> DispatchOutcome {
        DispatchOutcome::Blocked {
            reason: format!(
                "mcp dispatcher requires a registered tool for {}.{}",
                command.namespace, command.verb
            ),
        }
    }
}

#[cfg(test)]
#[derive(Default)]
pub struct SimulatedDispatcher {
    evidence: Mutex<Vec<EvidenceRecord>>,
}

#[cfg(test)]
impl SimulatedDispatcher {
    pub fn evidence(&self) -> Vec<EvidenceRecord> {
        self.evidence
            .lock()
            .expect("evidence mutex poisoned")
            .clone()
    }
}

#[cfg(test)]
impl EvidenceCollectingDispatcher for SimulatedDispatcher {
    fn evidence(&self) -> Vec<EvidenceRecord> {
        self.evidence()
    }
}

#[cfg(test)]
impl Dispatcher for SimulatedDispatcher {
    fn dispatch(&self, node_id: &NodeId, _command: &OperationalCommand) -> DispatchOutcome {
        let evidence_ref = format!("labd://dry-run/{}", node_id.0);
        self.evidence.lock().expect("evidence mutex poisoned").push(
            EvidenceRecord::from_execution_result(node_id, true, Some(&evidence_ref)),
        );
        DispatchOutcome::Success {
            evidence_ref: Some(evidence_ref),
            detail: Some(json!({"substrate": "dry_run.simulated"})),
        }
    }
}

pub fn redact_secret_values(value: Value) -> Value {
    match value {
        Value::Object(map) => Value::Object(
            map.into_iter()
                .map(|(key, value)| {
                    if looks_secret(&key) {
                        (key, Value::String("[REDACTED]".into()))
                    } else {
                        (key, redact_secret_values(value))
                    }
                })
                .collect(),
        ),
        Value::Array(values) => {
            Value::Array(values.into_iter().map(redact_secret_values).collect())
        }
        other => other,
    }
}

fn looks_secret(key: &str) -> bool {
    let lower = key.to_ascii_lowercase();
    lower.contains("secret")
        || lower.contains("token")
        || lower.contains("apikey")
        || lower.contains("api_key")
        || lower.contains("authorization")
        || lower.contains("password")
}
