use anyhow::{Context, Result};
use constitutional_runtime::{
    compile_strong_json_to_ir_graph, plan_ir_graph, AdmissibilityContext, AdmissionContext,
    AdmissionRuling, CapabilityManifest, CompiledOperationalPlan, IrGraph, OperationalProgram,
    PrimitiveName, StandardRuntimeLowerer,
};
use std::collections::BTreeSet;

use crate::act::Act;

#[derive(Clone, Debug)]
pub struct BridgeOutcome {
    pub admission: AdmissionRuling,
    pub strong_json: String,
    pub graph: IrGraph,
    pub plan: CompiledOperationalPlan,
}

pub fn admit_route_lower(act: &Act, admission_ctx: &AdmissionContext) -> Result<BridgeOutcome> {
    let proposed = act.to_proposed();
    let admission = constitutional_runtime::evaluate_admission(&proposed, admission_ctx);
    let strong_json = act.strong_json()?;
    let graph = compile_strong_json_to_ir_graph(&strong_json).context("strong grammar to IR")?;
    let plan = plan_ir_graph(
        graph.clone(),
        OperationalProgram::default(),
        &capability_manifests(admission_ctx),
        &AdmissibilityContext::default(),
        &StandardRuntimeLowerer,
    )
    .context("IR graph to lowered operational plan")?;
    Ok(BridgeOutcome {
        admission,
        strong_json,
        graph,
        plan,
    })
}

pub fn capability_manifests(admission_ctx: &AdmissionContext) -> Vec<CapabilityManifest> {
    let manifests: Vec<CapabilityManifest> = admission_ctx
        .gates
        .iter()
        .map(|gate| manifest_for_substrate(&gate.gate_id))
        .collect();
    if manifests.is_empty() {
        vec![manifest_for_substrate("unregistered.substrate")]
    } else {
        manifests
    }
}

fn manifest_for_substrate(substrate_id: &str) -> CapabilityManifest {
    CapabilityManifest {
        substrate_id: substrate_id.into(),
        substrate_version: env!("CARGO_PKG_VERSION").into(),
        supported_primitives: BTreeSet::from_iter([
            PrimitiveName::Observe,
            PrimitiveName::Collect,
            PrimitiveName::Fetch,
            PrimitiveName::Compress,
            PrimitiveName::Classify,
            PrimitiveName::Prioritize,
            PrimitiveName::Compare,
            PrimitiveName::Route,
            PrimitiveName::Schedule,
            PrimitiveName::Execute,
            PrimitiveName::Emit,
            PrimitiveName::Persist,
            PrimitiveName::Confirm,
            PrimitiveName::Cancel,
            PrimitiveName::Reconcile,
        ]),
        declared_guarantees: BTreeSet::from(["evidence.write".into()]),
        ..Default::default()
    }
}
