use anyhow::{Context, Result};
use constitutional_runtime::{AdmissionContext, Gate, Passport, Visa};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::{fs, path::Path};

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct RegisterProjection {
    #[serde(default)]
    pub passports: Vec<Passport>,
    #[serde(default)]
    pub visas: Vec<Visa>,
    #[serde(default)]
    pub gates: Vec<Gate>,
}

impl RegisterProjection {
    pub fn admission_context(&self, now: String) -> AdmissionContext {
        AdmissionContext {
            passports: self.passports.clone(),
            visas: self.visas.clone(),
            gates: self.gates.clone(),
            boundaries: vec![],
            now: Some(now),
        }
    }

    /// Loads a cached projection fixture only. The operational source of truth is
    /// admitted LogLine Acts in the spine; passport/visa/gate are in-memory
    /// admission views, never credential file types.
    pub fn from_path(path: impl AsRef<Path>) -> Result<Self> {
        let text = fs::read_to_string(path.as_ref()).with_context(|| {
            format!(
                "read cached register projection {}",
                path.as_ref().display()
            )
        })?;
        serde_json::from_str(&text).context("parse cached register projection")
    }

    pub fn from_acts(acts: &[Value]) -> Result<Self> {
        let mut projection = RegisterProjection::default();
        for act in acts {
            let did = act.get("did").and_then(Value::as_str).unwrap_or_default();
            let body = act.get("this").cloned().unwrap_or(Value::Null);
            match did {
                "register.passport" => projection.passports.push(serde_json::from_value(body)?),
                "register.visa" | "grant.visa" | "grant" => {
                    projection.visas.push(serde_json::from_value(body)?)
                }
                "register.gate" => projection.gates.push(serde_json::from_value(body)?),
                _ => {}
            }
        }
        Ok(projection)
    }
}

pub fn project_from_spine(
    _rest_v1_base: &str,
    _apikey: &str,
    _now: String,
) -> Result<RegisterProjection> {
    anyhow::bail!("project_from_spine requires the Supabase acts/receipts projection endpoint; cached files are not operational truth")
}
