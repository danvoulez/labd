use anyhow::{Context, Result};
use serde_json::Value;
use std::{fs, path::Path};
use time::OffsetDateTime;

use crate::{
    act::Act,
    register::RegisterProjection,
    runtime::{LabReceipt, LabRuntime},
};

pub fn tick_file(
    runtime: &LabRuntime,
    acts_path: impl AsRef<Path>,
    register: &RegisterProjection,
    now: &str,
) -> Result<Vec<LabReceipt>> {
    let text = fs::read_to_string(acts_path.as_ref())
        .with_context(|| format!("read acts {}", acts_path.as_ref().display()))?;
    let values: Vec<Value> = serde_json::from_str(&text).context("parse acts array")?;
    let ctx = register.admission_context(now.to_string());
    let mut receipts = Vec::new();
    for value in values {
        if is_due(&value, now) {
            let act = Act::from_value(value)?;
            receipts.push(runtime.run_act(&act, &ctx)?);
        }
    }
    Ok(receipts)
}

fn is_due(value: &Value, now: &str) -> bool {
    let when = value
        .get("when")
        .and_then(Value::as_str)
        .unwrap_or_default();
    if matches!(when, "*" | "any_time" | "due" | "now") {
        return true;
    }
    let Ok(when) = OffsetDateTime::parse(when, &time::format_description::well_known::Rfc3339)
    else {
        return false;
    };
    let Ok(now) = OffsetDateTime::parse(now, &time::format_description::well_known::Rfc3339) else {
        return false;
    };
    when <= now
}
