use anyhow::{Context, Result};
use clap::{Parser, Subcommand, ValueEnum};
use serde_json::Value;
use std::{fs, path::PathBuf};
use time::OffsetDateTime;

use labd::act::Act;
use labd::register::RegisterProjection;
use labd::runtime::LabRuntime;

#[derive(Clone, Debug, ValueEnum)]
enum EvidenceStoreChoice {
    Supabase,
    File,
}

#[derive(Parser)]
#[command(name = "labd", about = "One-process LogLine + constitutional runtime")]
struct Cli {
    #[arg(long, global = true)]
    canon: Option<PathBuf>,
    #[arg(long, global = true)]
    now: Option<String>,
    #[arg(long, global = true, default_value = "supabase")]
    evidence_store: EvidenceStoreChoice,
    #[arg(long, global = true)]
    dry_run: bool,
    #[command(subcommand)]
    cmd: Command,
}

#[derive(Subcommand)]
enum Command {
    Certify {
        act: PathBuf,
    },
    Admit {
        act: PathBuf,
        #[arg(long)]
        register: PathBuf,
    },
    Route {
        act: PathBuf,
        #[arg(long)]
        register: PathBuf,
    },
    Lower {
        act: PathBuf,
        #[arg(long)]
        register: PathBuf,
    },
    Close {
        act: PathBuf,
        #[arg(long)]
        register: PathBuf,
        #[arg(long)]
        scratch: Option<PathBuf>,
    },
    Evidence {
        act: PathBuf,
        #[arg(long)]
        register: PathBuf,
        #[arg(long)]
        scratch: Option<PathBuf>,
    },
    Tick {
        acts: PathBuf,
        #[arg(long)]
        register: PathBuf,
        #[arg(long)]
        scratch: Option<PathBuf>,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let now = cli.now.clone().unwrap_or_else(system_now_rfc3339);
    match cli.cmd {
        Command::Certify { act } => {
            let act = load_act(&act)?;
            let runtime = LabRuntime::certifier(cli.canon)?;
            print_json(&runtime.certify_act(&act)?)
        }
        Command::Admit { act, register } => {
            let act = load_act(&act)?;
            let register = RegisterProjection::from_path(register)?;
            let ctx = register.admission_context(now);
            print_json(&serde_json::to_value(
                constitutional_runtime::evaluate_admission(&act.to_proposed(), &ctx),
            )?)
        }
        Command::Route { act, register } | Command::Lower { act, register } => {
            let act = load_act(&act)?;
            let register = RegisterProjection::from_path(register)?;
            let bridged = labd::bridge::admit_route_lower(&act, &register.admission_context(now))?;
            print_json(&serde_json::to_value(&bridged.plan)?)
        }
        Command::Close {
            act,
            register,
            scratch,
        }
        | Command::Evidence {
            act,
            register,
            scratch,
        } => {
            let act = load_act(&act)?;
            let register = RegisterProjection::from_path(register)?;
            let runtime = build_runtime(cli.canon, cli.evidence_store, cli.dry_run, scratch)?;
            let receipt = runtime.run_act(&act, &register.admission_context(now))?;
            print_json(&serde_json::to_value(receipt)?)
        }
        Command::Tick {
            acts,
            register,
            scratch,
        } => {
            let register = RegisterProjection::from_path(register)?;
            let runtime = build_runtime(cli.canon, cli.evidence_store, cli.dry_run, scratch)?;
            let receipts = labd::clock::tick_file(&runtime, acts, &register, &now)?;
            print_json(&serde_json::to_value(receipts)?)
        }
    }
}

fn build_runtime(
    canon: Option<PathBuf>,
    store: EvidenceStoreChoice,
    dry_run: bool,
    scratch: Option<PathBuf>,
) -> Result<LabRuntime> {
    match (dry_run, store) {
        (true, EvidenceStoreChoice::File) | (true, EvidenceStoreChoice::Supabase) => {
            let scratch = scratch.context("--dry-run requires an explicit --scratch file; scratch files are non-authoritative")?;
            LabRuntime::dry_run_file(canon, scratch)
        }
        (false, EvidenceStoreChoice::Supabase) => LabRuntime::operational(canon),
        (false, EvidenceStoreChoice::File) => anyhow::bail!(
            "file evidence store is only allowed with --dry-run --scratch; operational persistence is the Supabase spine"
        ),
    }
}

fn system_now_rfc3339() -> String {
    OffsetDateTime::now_utc()
        .format(&time::format_description::well_known::Rfc3339)
        .expect("UTC time formats as RFC3339")
}

fn load_act(path: &PathBuf) -> Result<Act> {
    let text = fs::read_to_string(path).with_context(|| format!("read act {}", path.display()))?;
    let value: Value = serde_json::from_str(&text).context("parse act json")?;
    Act::from_value(value)
}

fn print_json(value: &Value) -> Result<()> {
    println!("{}", serde_json::to_string_pretty(value)?);
    Ok(())
}
