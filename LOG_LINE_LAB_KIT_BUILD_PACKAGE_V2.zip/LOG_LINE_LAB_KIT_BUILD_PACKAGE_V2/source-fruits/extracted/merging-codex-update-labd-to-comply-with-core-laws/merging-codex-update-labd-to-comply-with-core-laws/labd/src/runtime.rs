use anyhow::{anyhow, Context, Result};
use constitutional_runtime::{
    close_execution_evidence, execute_compiled_plan, AdmissionContext, AdmissionDecision,
    EvidenceRecord, EvidenceStore, ExecutionReport, FileEvidenceStore, SupabaseRestEvidenceStore,
};
use logline_status::{
    canonical_json, compute_envelope_hash, content_hash, tuple_hash, Canon, Operation,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    env,
    path::{Path, PathBuf},
};

use crate::{act::Act, bridge, substrate::ShellProbeDispatcher};

const DEFAULT_FROZEN_CANON_PATH: &str = "engine/source/logline.canon.json";
const EXPECTED_FROZEN_CANON_HASH: &str =
    "7ca6dd1e1101ad4a9fef6570cc97751c831cd977be33b3e6669c543fe82dde1d";

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LabReceipt {
    pub receipt_version: String,
    pub lab_id: String,
    pub admitted: bool,
    pub act: Value,
    pub admission: Value,
    pub strong_grammar: String,
    pub ir_graph: Value,
    pub execution: Value,
    pub evidence: Vec<EvidenceRecord>,
    pub engine: Value,
    pub hashes: Value,
    pub envelope_hash: String,
}

pub struct LabRuntime {
    canon: Canon,
    store: Box<dyn EvidenceStore>,
}

impl LabRuntime {
    pub fn new(canon: Canon, store: Box<dyn EvidenceStore>) -> Self {
        Self { canon, store }
    }

    pub fn certifier(canon_path: Option<PathBuf>) -> Result<Self> {
        let canon = load_frozen_canon(canon_path)?;
        Ok(Self::new(canon, Box::new(CertifyOnlyEvidenceStore)))
    }

    pub fn operational(canon_path: Option<PathBuf>) -> Result<Self> {
        let canon = load_frozen_canon(canon_path)?;
        let base = env::var("SUPABASE_REST_BASE")
            .context("SUPABASE_REST_BASE is required for operational spine persistence")?;
        let key = env::var("SUPABASE_KEY")
            .context("SUPABASE_KEY is required for operational spine persistence")?;
        Ok(Self::new(
            canon,
            Box::new(SupabaseRestEvidenceStore::new(
                base,
                "evidence_records",
                key,
            )),
        ))
    }

    pub fn dry_run_file(
        canon_path: Option<PathBuf>,
        evidence_path: impl AsRef<Path>,
    ) -> Result<Self> {
        let canon = load_frozen_canon(canon_path)?;
        Ok(Self::new(
            canon,
            Box::new(FileEvidenceStore::new(evidence_path)),
        ))
    }

    pub fn local(evidence_path: impl AsRef<Path>) -> Result<Self> {
        Self::dry_run_file(None, evidence_path)
    }

    pub fn certify_act(&self, act: &Act) -> Result<Value> {
        let engine_logline = act.to_engine_logline();
        let engine = logline_status::run(&self.canon, &engine_logline, Operation::Confirmar)
            .context("engine certify")?;
        let lab_id = act_lab_id(act)?;
        let mut receipt = json!({
            "receipt_version": "certification.v1",
            "lab_id": lab_id,
            "act": act.to_value(),
            "engine": engine,
        });
        let act_value = serde_json::to_value(act.to_engine_logline())?;
        let tuple = tuple_hash(&act_value)?;
        let content = content_hash(&receipt)?;
        receipt["hashes"] = json!({"tuple_hash": tuple, "content_hash": content});
        let envelope = compute_envelope_hash(&receipt)?;
        receipt["envelope_hash"] = json!(envelope);
        Ok(json!({
            "lab_id": receipt["lab_id"],
            "tuple_hash": receipt["hashes"]["tuple_hash"],
            "content_hash": receipt["hashes"]["content_hash"],
            "envelope_hash": receipt["envelope_hash"],
            "verdict": receipt["engine"].get("branch").cloned().or_else(|| receipt["engine"].get("selected_branch").cloned()).unwrap_or(Value::Null),
            "receipt": receipt,
        }))
    }

    pub fn run_act(&self, act: &Act, admission_ctx: &AdmissionContext) -> Result<LabReceipt> {
        let bridged = bridge::admit_route_lower(act, admission_ctx)?;
        let mut evidence = Vec::new();
        evidence.push(EvidenceRecord {
            kind: "admission.ruling".into(),
            payload_json: serde_json::to_value(&bridged.admission)?,
        });

        if bridged.admission.decision != AdmissionDecision::Yes {
            evidence.push(EvidenceRecord {
                kind: "admission.blocked".into(),
                payload_json: json!({
                    "admitted": false,
                    "decision": bridged.admission.decision,
                    "reason": "admission did not return yes",
                    "status": non_admitted_status(act),
                }),
            });
            close_execution_evidence(self.store.as_ref(), evidence.clone())?;
            return self.blocked_record(
                act,
                bridged.strong_json,
                serde_json::to_value(&bridged.graph)?,
                evidence,
            );
        }

        for node_plan in &bridged.plan.node_plans {
            evidence.push(EvidenceRecord::from_plan(
                &node_plan.node_id,
                &node_plan.lowering,
                &node_plan.command,
            ));
        }

        let dispatcher = ShellProbeDispatcher::default();
        let report = execute_compiled_plan(&bridged.plan, &dispatcher);
        evidence.extend(dispatcher.evidence());
        evidence.push(EvidenceRecord {
            kind: "execution.report".into(),
            payload_json: serde_json::to_value(&report)?,
        });
        for result in &report.results {
            evidence.push(EvidenceRecord::from_closure_status(
                &result.node_id,
                matches!(
                    result.outcome,
                    constitutional_runtime::NodeOutcome::Success { .. }
                ),
                serde_json::to_value(&result.outcome)?,
            ));
        }
        close_execution_evidence(self.store.as_ref(), evidence.clone())?;
        self.close_receipt(
            act,
            bridged.strong_json,
            serde_json::to_value(&bridged.graph)?,
            report,
            evidence,
        )
    }

    fn close_receipt(
        &self,
        act: &Act,
        strong_grammar: String,
        ir_graph: Value,
        report: ExecutionReport,
        evidence: Vec<EvidenceRecord>,
    ) -> Result<LabReceipt> {
        let engine_logline = act.to_engine_logline();
        let engine = logline_status::run(&self.canon, &engine_logline, Operation::Confirmar)
            .context("engine close")?;
        self.materialize_receipt(
            "receipt.v1",
            true,
            act,
            strong_grammar,
            ir_graph,
            json!(report),
            evidence,
            serde_json::to_value(engine)?,
        )
    }

    fn blocked_record(
        &self,
        act: &Act,
        strong_grammar: String,
        ir_graph: Value,
        evidence: Vec<EvidenceRecord>,
    ) -> Result<LabReceipt> {
        self.materialize_receipt(
            "blocked.ghost.v1",
            false,
            act,
            strong_grammar,
            ir_graph,
            Value::Null,
            evidence,
            json!({"verdict": non_admitted_status(act), "admitted": false}),
        )
    }

    fn materialize_receipt(
        &self,
        receipt_version: &str,
        admitted: bool,
        act: &Act,
        strong_grammar: String,
        ir_graph: Value,
        execution: Value,
        evidence: Vec<EvidenceRecord>,
        engine: Value,
    ) -> Result<LabReceipt> {
        let lab_id = act_lab_id(act)?;
        let mut receipt_value = json!({
            "receipt_version": receipt_version,
            "lab_id": lab_id,
            "admitted": admitted,
            "act": act.to_value(),
            "admission": evidence.iter().find(|r| r.kind == "admission.ruling").map(|r| r.payload_json.clone()),
            "strong_grammar": strong_grammar,
            "ir_graph": ir_graph,
            "execution": execution,
            "evidence": evidence,
            "engine": engine,
        });
        let act_value = serde_json::to_value(act.to_engine_logline())?;
        let tuple = tuple_hash(&act_value)?;
        let content = content_hash(&receipt_value)?;
        receipt_value["hashes"] = json!({
            "tuple_hash": tuple,
            "content_hash": content,
        });
        let envelope = compute_envelope_hash(&receipt_value)?;
        receipt_value["envelope_hash"] = json!(envelope);
        serde_json::from_value(receipt_value).context("build lab receipt")
    }
}

pub fn act_lab_id(act: &Act) -> Result<String> {
    let engine_logline = serde_json::to_value(act.to_engine_logline())?;
    content_hash(&engine_logline).context("compute Act LAB-ID")
}

pub fn load_frozen_canon(explicit_path: Option<PathBuf>) -> Result<Canon> {
    let path = resolve_canon_path(explicit_path);
    if !path.exists() {
        return Err(anyhow!(
            "frozen canon not found at {}; pass --canon or set LOGLINE_CANON",
            path.display()
        ));
    }
    let text = std::fs::read_to_string(&path)
        .with_context(|| format!("read frozen canon {}", path.display()))?;
    let canon_value: Value = serde_json::from_str(&text).context("parse canon for guard")?;
    let hash = sha256_hex(canonical_json(&canon_value)?.as_bytes());
    if hash != EXPECTED_FROZEN_CANON_HASH {
        return Err(anyhow!(
            "canon guard refused {}; expected {}, got {}",
            path.display(),
            EXPECTED_FROZEN_CANON_HASH,
            hash
        ));
    }
    Canon::from_json_path(path).context("load frozen LogLine canon")
}

fn resolve_canon_path(explicit_path: Option<PathBuf>) -> PathBuf {
    explicit_path
        .or_else(|| env::var_os("LOGLINE_CANON").map(PathBuf::from))
        .unwrap_or_else(default_frozen_canon_path)
}

fn default_frozen_canon_path() -> PathBuf {
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest.join("..").join(DEFAULT_FROZEN_CANON_PATH)
}

fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    digest.iter().map(|b| format!("{b:02x}")).collect()
}

fn non_admitted_status(act: &Act) -> String {
    if act.if_not != "*" {
        act.if_not.clone()
    } else {
        act.if_doubt.clone()
    }
}

struct CertifyOnlyEvidenceStore;

impl EvidenceStore for CertifyOnlyEvidenceStore {
    fn write_record(
        &self,
        _record: EvidenceRecord,
    ) -> Result<(), constitutional_runtime::EvidenceStoreError> {
        Ok(())
    }
}
