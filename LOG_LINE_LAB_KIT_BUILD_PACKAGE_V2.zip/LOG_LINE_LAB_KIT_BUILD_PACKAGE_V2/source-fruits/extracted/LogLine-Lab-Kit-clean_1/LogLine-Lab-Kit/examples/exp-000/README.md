# EXP-000 fixture

This fixture starts the first Lab probe:

```txt
Can a LogLine Lab load the canonical stack?
```

Use `workorder.json` with `logline-lab hermes-dry-run` first. It intentionally touches no world.
