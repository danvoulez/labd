#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${PREFIX:-$HOME/.local}"
cd "$ROOT"
cargo build --release -p logline-lab-cli
mkdir -p "$PREFIX/bin"
cp target/release/logline-lab "$PREFIX/bin/logline-lab"
printf 'installed %s\n' "$PREFIX/bin/logline-lab"
printf 'add to PATH if needed: export PATH="%s/bin:$PATH"\n' "$PREFIX"
