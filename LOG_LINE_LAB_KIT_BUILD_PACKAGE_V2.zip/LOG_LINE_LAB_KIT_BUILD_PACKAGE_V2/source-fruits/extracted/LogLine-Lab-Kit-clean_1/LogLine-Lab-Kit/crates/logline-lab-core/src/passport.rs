use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct PassportProjection {
    pub passport_ref: String,
    pub source_act_ref: String,
    pub subject: String,
    pub subject_type: String,
    pub projected_at: String,
    pub status: String,
}
