use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;
use time::{format_description::well_known::Rfc3339, OffsetDateTime};

use logline_status::{content_hash, tuple_hash};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct LogLineAct {
    pub who: String,
    pub did: String,
    pub this: String,
    pub when: String,
    pub confirmed_by: String,
    pub if_ok: String,
    pub if_doubt: String,
    pub if_not: String,
    pub status: String,
}

impl LogLineAct {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        who: impl Into<String>,
        did: impl Into<String>,
        this: impl Into<String>,
        when: impl Into<String>,
        confirmed_by: impl Into<String>,
        if_ok: impl Into<String>,
        if_doubt: impl Into<String>,
        if_not: impl Into<String>,
        status: impl Into<String>,
    ) -> Self {
        Self {
            who: who.into(),
            did: did.into(),
            this: this.into(),
            when: when.into(),
            confirmed_by: confirmed_by.into(),
            if_ok: if_ok.into(),
            if_doubt: if_doubt.into(),
            if_not: if_not.into(),
            status: status.into(),
        }
    }

    pub fn missing_slots(&self) -> Vec<&'static str> {
        let mut out = Vec::new();
        if self.who.trim().is_empty() {
            out.push("who");
        }
        if self.did.trim().is_empty() {
            out.push("did");
        }
        if self.this.trim().is_empty() {
            out.push("this");
        }
        if self.when.trim().is_empty() {
            out.push("when");
        }
        if self.confirmed_by.trim().is_empty() {
            out.push("confirmed_by");
        }
        if self.if_ok.trim().is_empty() {
            out.push("if_ok");
        }
        if self.if_doubt.trim().is_empty() {
            out.push("if_doubt");
        }
        if self.if_not.trim().is_empty() {
            out.push("if_not");
        }
        if self.status.trim().is_empty() {
            out.push("status");
        }
        out
    }

    pub fn to_value(&self) -> Value {
        serde_json::to_value(self).expect("LogLineAct serializes")
    }

    pub fn to_receipt(&self) -> Result<Receipt, logline_status::ReceiptEncodingError> {
        Receipt::from_act(self)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ReceiptHashes {
    pub tuple_hash: String,
    pub content_hash: String,
    pub algorithm: String,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Receipt {
    pub id: String,
    pub receipt_version: String,
    pub who: String,
    pub did: String,
    pub this: String,
    pub when: String,
    pub confirmed_by: String,
    pub if_ok: String,
    pub if_doubt: String,
    pub if_not: String,
    pub status: String,
    pub hashes: ReceiptHashes,
    pub json_canonicalization: String,
    #[serde(flatten)]
    pub aux: BTreeMap<String, Value>,
}

impl Receipt {
    pub fn from_act(act: &LogLineAct) -> Result<Self, logline_status::ReceiptEncodingError> {
        let mut receipt = Self {
            id: String::new(),
            receipt_version: "logline.receipt.v0".to_string(),
            who: act.who.clone(),
            did: act.did.clone(),
            this: act.this.clone(),
            when: act.when.clone(),
            confirmed_by: act.confirmed_by.clone(),
            if_ok: act.if_ok.clone(),
            if_doubt: act.if_doubt.clone(),
            if_not: act.if_not.clone(),
            status: act.status.clone(),
            hashes: ReceiptHashes {
                tuple_hash: String::new(),
                content_hash: String::new(),
                algorithm: "sha256".to_string(),
            },
            json_canonicalization: "jcs-rfc8785".to_string(),
            aux: BTreeMap::new(),
        };
        receipt.seal()?;
        Ok(receipt)
    }

    pub fn seal(&mut self) -> Result<(), logline_status::ReceiptEncodingError> {
        let value = serde_json::to_value(&*self).expect("Receipt serializes");
        let tuple = tuple_hash(&value)?;
        let content = content_hash(&value)?;
        self.hashes.tuple_hash = tuple;
        self.hashes.content_hash = content.clone();
        self.id = content;
        Ok(())
    }

    pub fn verify(&self) -> Result<bool, logline_status::ReceiptEncodingError> {
        if self.aux.contains_key("result")
            || self.aux.contains_key("evidence")
            || self.aux.contains_key("transport")
        {
            return Ok(false);
        }
        let value = serde_json::to_value(self).expect("Receipt serializes");
        let expected_tuple = tuple_hash(&value)?;
        let expected_content = content_hash(&value)?;
        Ok(self.hashes.tuple_hash == expected_tuple
            && self.hashes.content_hash == expected_content
            && self.id == expected_content
            && self.receipt_version == "logline.receipt.v0"
            && self.hashes.algorithm == "sha256"
            && self.json_canonicalization == "jcs-rfc8785")
    }

    pub fn to_value(&self) -> Value {
        serde_json::to_value(self).expect("Receipt serializes")
    }
}

pub fn seal_receipt_value(mut value: Value) -> Result<Value, logline_status::ReceiptEncodingError> {
    let Value::Object(obj) = &mut value else {
        return Err(logline_status::ReceiptEncodingError::ReceiptMustBeObject);
    };
    obj.insert(
        "receipt_version".to_string(),
        Value::String("logline.receipt.v0".to_string()),
    );
    obj.insert(
        "json_canonicalization".to_string(),
        Value::String("jcs-rfc8785".to_string()),
    );
    obj.insert("id".to_string(), Value::String(String::new()));
    obj.insert(
        "hashes".to_string(),
        serde_json::json!({
            "tuple_hash": "",
            "content_hash": "",
            "algorithm": "sha256"
        }),
    );
    let th = tuple_hash(&value)?;
    let ch = content_hash(&value)?;
    let Value::Object(obj) = &mut value else {
        unreachable!()
    };
    obj.insert("id".to_string(), Value::String(ch.clone()));
    obj.insert(
        "hashes".to_string(),
        serde_json::json!({
            "tuple_hash": th,
            "content_hash": ch,
            "algorithm": "sha256"
        }),
    );
    Ok(value)
}

pub fn verify_receipt_value(value: &Value) -> Result<bool, logline_status::ReceiptEncodingError> {
    let Value::Object(obj) = value else {
        return Err(logline_status::ReceiptEncodingError::ReceiptMustBeObject);
    };
    for forbidden in ["result", "evidence", "transport"] {
        if obj.contains_key(forbidden) {
            return Ok(false);
        }
    }
    let Some(Value::String(id)) = obj.get("id") else {
        return Ok(false);
    };
    let Some(Value::Object(hashes)) = obj.get("hashes") else {
        return Ok(false);
    };
    let Some(Value::String(tuple)) = hashes.get("tuple_hash") else {
        return Ok(false);
    };
    let Some(Value::String(content)) = hashes.get("content_hash") else {
        return Ok(false);
    };
    let expected_tuple = tuple_hash(value)?;
    let expected_content = content_hash(value)?;
    Ok(tuple == &expected_tuple && content == &expected_content && id == &expected_content)
}

pub fn now_rfc3339() -> String {
    OffsetDateTime::now_utc()
        .format(&Rfc3339)
        .unwrap_or_else(|_| "1970-01-01T00:00:00Z".to_string())
}
