use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct VisaProjection {
    pub visa_ref: String,
    pub source_act_ref: String,
    pub subject_passport: String,
    pub issuer: String,
    #[serde(default)]
    pub capabilities: Vec<String>,
    pub scope: String,
    #[serde(default)]
    pub constraints: Vec<String>,
    pub audience: String,
    pub expiry: String,
    pub status: String,
}
