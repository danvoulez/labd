use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ProjectionKind {
    CurrentState,
    GhostRegistry,
    EvidenceRegistry,
    ReceiptRegistry,
    RuntimeRegistry,
    ExperimentRegistry,
    Report,
    StandardAdapter,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct ProjectionRecord {
    pub projection_id: String,
    pub kind: ProjectionKind,
    pub source_refs: Vec<String>,
    pub projected_at: String,
    pub payload: Value,
}
