use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum IntervalStatus {
    Open,
    Simulated,
    Observed,
    Closed,
    Ghosted,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct IntervalRecord {
    pub interval_id: String,
    pub start_boundary_act: String,
    pub finish_boundary_act: Option<String>,
    #[serde(default)]
    pub candidate_acts: Vec<String>,
    #[serde(default)]
    pub observations: Vec<String>,
    #[serde(default)]
    pub evidence_refs: Vec<String>,
    #[serde(default)]
    pub ghost_refs: Vec<String>,
    #[serde(default)]
    pub receipt_refs: Vec<String>,
    pub status: IntervalStatus,
}
