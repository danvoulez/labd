use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DispatchPacketType {
    Inspection,
    Mutation,
    Code,
    Verification,
    Intelligence,
    Research,
    Publication,
    Communication,
    Executable,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HermesMode {
    ReadOnly,
    DryRun,
    Apply,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DispatchPacket {
    pub dispatch_version: String,
    pub packet_id: String,
    pub correlation_id: String,
    pub created_at: String,
    pub created_by: String,
    pub process_id: String,
    pub organ: String,
    pub office: String,
    pub packet_type: DispatchPacketType,
    pub authority_level: String,
    pub objective: String,
    #[serde(default)]
    pub input_sources: Vec<String>,
    pub proposed_action: String,
    #[serde(default)]
    pub expected_evidence: Vec<String>,
    pub rollback_or_rectify: String,
    pub required_human_check: String,
    #[serde(default)]
    pub ghosts: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct HermesWorkorder {
    pub workorder_version: String,
    pub workorder_id: String,
    pub correlation_id: String,
    pub source_dispatch_packet: String,
    pub requested_by: String,
    pub target_lab: String,
    pub process_id: String,
    pub authority_level: String,
    pub mode: HermesMode,
    #[serde(default)]
    pub allowed_actions: Vec<String>,
    #[serde(default)]
    pub forbidden_actions: Vec<String>,
    #[serde(default)]
    pub inputs: Vec<Value>,
    #[serde(default)]
    pub expected_outputs: Vec<String>,
    #[serde(default)]
    pub evidence_required: Vec<String>,
    pub artifact_policy: String,
    pub secret_policy: String,
    pub timeout_seconds: u64,
    pub rollback_or_rectify: String,
    pub receipt_profile: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionStatus {
    Observed,
    Failed,
    Inconclusive,
    Ghost,
    Blocked,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct ExecutionReport {
    pub report_version: String,
    pub workorder_id: String,
    pub target_lab: String,
    pub started_at: String,
    pub finished_at: String,
    pub status: ExecutionStatus,
    #[serde(default)]
    pub commands_run: Vec<String>,
    #[serde(default)]
    pub artifacts: Vec<String>,
    pub stdout_ref: Option<String>,
    pub stderr_ref: Option<String>,
    #[serde(default)]
    pub hashes: Vec<String>,
    pub secret_redacted: bool,
    #[serde(default)]
    pub observations: Vec<String>,
    #[serde(default)]
    pub ghosts: Vec<String>,
    pub next_act: String,
}
