use serde::{Deserialize, Serialize};

use crate::{now_rfc3339, LogLineAct};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClockDiscipline {
    pub clock_id: String,
    pub lab_id: String,
    pub rhythm: String,
    #[serde(default)]
    pub may: Vec<String>,
    #[serde(default)]
    pub may_not: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ClockTick {
    pub tick_id: String,
    pub lab_id: String,
    pub emitted_at: String,
    #[serde(default)]
    pub checks: Vec<String>,
    pub act: LogLineAct,
}

impl ClockTick {
    pub fn manual(lab_id: impl Into<String>, sequence: impl Into<String>) -> Self {
        let lab_id = lab_id.into();
        let emitted_at = now_rfc3339();
        let tick_id = format!("tick.{}.{}", lab_id, sequence.into());
        let act = LogLineAct::new(
            "logline-lab-clock",
            "tick",
            format!("lab:{}", lab_id),
            emitted_at.clone(),
            "local_clock_observation",
            "project_clock_tick",
            "open_clock_ghost",
            "reject_tick",
            "observed",
        );
        Self {
            tick_id,
            lab_id,
            emitted_at,
            checks: vec![
                "ghosts".to_string(),
                "workorders".to_string(),
                "runtime_registry".to_string(),
            ],
            act,
        }
    }
}
