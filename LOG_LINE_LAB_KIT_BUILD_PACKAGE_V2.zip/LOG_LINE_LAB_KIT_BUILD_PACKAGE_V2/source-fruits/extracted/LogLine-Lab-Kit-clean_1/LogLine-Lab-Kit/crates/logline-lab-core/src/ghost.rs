use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GhostStatus {
    Open,
    Carried,
    Narrowed,
    Closed,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct GhostRecord {
    pub ghost_id: String,
    pub missing: String,
    pub why_it_matters: String,
    #[serde(default)]
    pub blocks: Vec<String>,
    pub owner: String,
    pub next_act: String,
    pub opened_at: String,
    pub status: GhostStatus,
}
