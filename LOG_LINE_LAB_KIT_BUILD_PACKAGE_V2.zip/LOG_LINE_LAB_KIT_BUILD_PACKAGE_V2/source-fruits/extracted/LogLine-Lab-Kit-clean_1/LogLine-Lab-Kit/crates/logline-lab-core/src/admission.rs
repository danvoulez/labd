use serde::{Deserialize, Serialize};
use serde_json::json;

use constitutional_runtime::{
    evaluate_admission, AdmissionContext, AdmissionRuling, ProposedLogLineAct,
};

use crate::LogLineAct;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LabAdmission {
    pub act: LogLineAct,
    pub ruling: AdmissionRuling,
}

pub fn act_to_proposed(act: &LogLineAct) -> ProposedLogLineAct {
    ProposedLogLineAct {
        who: act.who.clone(),
        did: act.did.clone(),
        this: json!(act.this),
        confirmed_by: json!(act.confirmed_by),
        if_ok: act.if_ok.clone(),
        if_doubt: act.if_doubt.clone(),
        if_not: act.if_not.clone(),
        status: act.status.clone(),
        metadata: Some(json!({ "when": act.when })),
    }
}

pub fn admit_lab_act(act: &LogLineAct, ctx: &AdmissionContext) -> LabAdmission {
    let proposed = act_to_proposed(act);
    let ruling = evaluate_admission(&proposed, ctx);
    LabAdmission {
        act: act.clone(),
        ruling,
    }
}
