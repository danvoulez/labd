use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RuntimeEnvelope {
    pub runtime_id: String,
    pub engine_id: String,
    pub run_id: String,
    pub admission_status: String,
    pub emitted_at: String,
    pub observed_at: String,
    pub tuple_hash: String,
    pub content_hash: String,
    #[serde(default)]
    pub previous_act_refs: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RuntimeRegistryEntry {
    pub runtime_id: String,
    pub runtime_entity_ref: String,
    pub engine_entity_ref: String,
    pub lab_id: String,
    pub status: String,
    #[serde(default)]
    pub capabilities: Vec<String>,
    #[serde(default)]
    pub accepted_dids: Vec<String>,
    #[serde(default)]
    pub evidence_policy: Vec<String>,
    #[serde(default)]
    pub authority_policy: Vec<String>,
    pub last_seen_at: String,
    pub passport_act_ref: String,
    pub latest_act_ref: String,
}
