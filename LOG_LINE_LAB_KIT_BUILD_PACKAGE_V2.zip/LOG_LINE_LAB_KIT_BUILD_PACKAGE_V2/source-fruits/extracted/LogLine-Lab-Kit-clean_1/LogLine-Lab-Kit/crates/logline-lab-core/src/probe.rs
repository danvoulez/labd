use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ProbeStatus {
    Planned,
    Running,
    Observed,
    Inconclusive,
    Failed,
    Ghosted,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ProbeRecord {
    pub probe_id: String,
    pub claim_under_test: String,
    pub method: String,
    pub runtime_or_actor: String,
    #[serde(default)]
    pub inputs: Vec<String>,
    pub expected_observation: String,
    pub evidence_path: String,
    pub doubt_path: String,
    pub failure_path: String,
    pub status: ProbeStatus,
}
