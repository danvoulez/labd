use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EvidenceKind {
    RuntimeOutput,
    ArtifactHash,
    ManualWitness,
    SignedDocument,
    ModelOutputDeclaredLimits,
    SimulationResult,
    ConformanceTest,
    TransactionTrace,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct EvidenceRecord {
    pub evidence_id: String,
    pub kind: EvidenceKind,
    pub source: String,
    pub runtime_or_witness: String,
    pub observed_at: String,
    #[serde(default)]
    pub artifact_refs: Vec<String>,
    #[serde(default)]
    pub hashes: Vec<String>,
    pub redaction_status: String,
    pub scope: String,
    pub limits: String,
}
