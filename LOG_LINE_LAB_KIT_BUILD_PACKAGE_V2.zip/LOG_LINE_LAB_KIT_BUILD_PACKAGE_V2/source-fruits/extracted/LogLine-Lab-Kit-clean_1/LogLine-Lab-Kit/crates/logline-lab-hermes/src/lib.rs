#![forbid(unsafe_code)]

use logline_lab_core::{
    now_rfc3339, ExecutionReport, ExecutionStatus, HermesMode, HermesWorkorder,
};

pub trait HermesRunner {
    fn execute(&self, workorder: &HermesWorkorder) -> ExecutionReport;
}

/// A lawful first Hermes: it never touches the world.
/// It reports the workorder boundary as observed and blocks apply mode.
pub struct DryRunHermes;

impl HermesRunner for DryRunHermes {
    fn execute(&self, workorder: &HermesWorkorder) -> ExecutionReport {
        let started_at = now_rfc3339();
        let mut ghosts = Vec::new();
        let mut observations = vec![
            "workorder_received".to_string(),
            "no_world_touch".to_string(),
            "secret_values_not_requested".to_string(),
        ];
        let status = match &workorder.mode {
            HermesMode::Apply => {
                ghosts.push("apply-mode-blocked-by-dry-run-hermes".to_string());
                ExecutionStatus::Blocked
            }
            HermesMode::ReadOnly | HermesMode::DryRun => {
                observations.push("dry_run_boundary_preserved".to_string());
                ExecutionStatus::Observed
            }
        };
        let finished_at = now_rfc3339();
        ExecutionReport {
            report_version: "hermes.execution_report.v0".to_string(),
            workorder_id: workorder.workorder_id.clone(),
            target_lab: workorder.target_lab.clone(),
            started_at,
            finished_at,
            status,
            commands_run: Vec::new(),
            artifacts: Vec::new(),
            stdout_ref: None,
            stderr_ref: None,
            hashes: Vec::new(),
            secret_redacted: true,
            observations,
            ghosts,
            next_act: "project_execution_report_or_open_ghost".to_string(),
        }
    }
}
