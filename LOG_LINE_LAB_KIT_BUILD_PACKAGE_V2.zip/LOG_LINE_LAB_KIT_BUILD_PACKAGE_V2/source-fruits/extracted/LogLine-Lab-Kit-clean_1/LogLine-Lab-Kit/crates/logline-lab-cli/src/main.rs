#![forbid(unsafe_code)]

use anyhow::Context;
use clap::{Parser, Subcommand};
use constitutional_runtime::AdmissionContext;
use logline_lab_core::{
    admit_lab_act, now_rfc3339, seal_receipt_value, verify_receipt_value, ClockTick,
    DispatchPacket, DispatchPacketType, GhostRecord, GhostStatus, HermesMode,
    HermesWorkorder, LabManifest, LogLineAct,
};
use logline_lab_hermes::{DryRunHermes, HermesRunner};
use logline_lab_local_sql::{ActRow, LocalLedger};
use logline_lab_outbox::OutboxSync;
use logline_lab_supabase::SupabaseSpine;
use serde_json::json;
use std::fs;
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "logline-lab")]
#[command(about = "Rust-first LogLine Lab kit CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Init {
        path: PathBuf,
        name: String,
        steward: String,
    },
    EmitAct {
        path: PathBuf,
        who: String,
        did: String,
        this: String,
        #[arg(long)]
        when: Option<String>,
        #[arg(long = "confirmed-by")]
        confirmed_by: String,
        #[arg(long = "if-ok")]
        if_ok: String,
        #[arg(long = "if-doubt")]
        if_doubt: String,
        #[arg(long = "if-not")]
        if_not: String,
        status: String,
    },
    SealReceipt {
        input: PathBuf,
        output: Option<PathBuf>,
    },
    VerifyReceipt {
        input: PathBuf,
    },
    Admit {
        act: PathBuf,
        context: Option<PathBuf>,
    },
    Ghost {
        path: PathBuf,
        id: String,
        missing: String,
        #[arg(long, default_value = "unscoped")]
        why: String,
        #[arg(long)]
        blocks: Vec<String>,
        #[arg(long, default_value = "dan")]
        owner: String,
        #[arg(long = "next-act", default_value = "name_next_probe")]
        next_act: String,
    },
    Workorder {
        path: PathBuf,
        id: String,
        process: String,
        #[arg(long = "target-lab")]
        target_lab: String,
        #[arg(long, value_parser = ["read_only", "dry_run", "apply"])]
        mode: String,
        objective: String,
    },
    HermesDryRun {
        path: PathBuf,
        workorder: PathBuf,
    },
    ClockTick {
        path: PathBuf,
        #[arg(long = "lab-id", default_value = "local-lab")]
        lab_id: String,
    },
    Report {
        path: PathBuf,
    },
    /// List outbox entries awaiting delivery to the remote spine.
    Outbox {
        path: PathBuf,
        #[arg(long, default_value_t = 100)]
        limit: usize,
    },
    /// Drain the local outbox into the remote Supabase spine (needs DATABASE_URL).
    Sync {
        path: PathBuf,
        #[arg(long, default_value_t = 1000)]
        max: usize,
    },
}

/// The local SQLite ledger lives at `<lab home>/lab.db`.
fn ledger_path(home: &std::path::Path) -> PathBuf {
    home.join("lab.db")
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Init {
            path,
            name,
            steward,
        } => {
            fs::create_dir_all(&path)?;
            // Truth lives in the local SQLite ledger, not in files.
            let ledger_path = ledger_path(&path);
            LocalLedger::open(&ledger_path)?;
            // The manifest is declaration/config, not ledger truth — kept as a file.
            let manifest = LabManifest::minimal(name, steward);
            let manifest_path = path.join("lab_manifest.json");
            fs::write(&manifest_path, serde_json::to_vec_pretty(&manifest)?)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "ledger": ledger_path.display().to_string(),
                    "manifest": manifest_path.display().to_string()
                }))?
            );
        }
        Commands::EmitAct {
            path,
            who,
            did,
            this,
            when,
            confirmed_by,
            if_ok,
            if_doubt,
            if_not,
            status,
        } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let act = LogLineAct::new(
                who,
                did,
                this,
                when.unwrap_or_else(now_rfc3339),
                confirmed_by,
                if_ok,
                if_doubt,
                if_not,
                status,
            );
            // Seal the canonical receipt to obtain conformance-grade hashes, then
            // write the act + its outbox event to the local ledger in one tx.
            let receipt = act.to_receipt()?;
            let row = ActRow {
                id: receipt.id.clone(),
                who: act.who.clone(),
                did: act.did.clone(),
                this: act.this.clone(),
                when_ts: act.when.clone(),
                confirmed_by: act.confirmed_by.clone(),
                if_ok: act.if_ok.clone(),
                if_doubt: act.if_doubt.clone(),
                if_not: act.if_not.clone(),
                status: act.status.clone(),
                tuple_hash: Some(receipt.hashes.tuple_hash.clone()),
                content_hash: Some(receipt.hashes.content_hash.clone()),
            };
            let entry = ledger.append_act(&row)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "id": receipt.id,
                    "content_hash": receipt.hashes.content_hash,
                    "tuple_hash": receipt.hashes.tuple_hash,
                    "outbox_seq": entry.seq,
                    "outbox_status": entry.status,
                    "claim_limits": "act recorded in local ledger and queued for outbox; \
                        not yet delivered to ops.logline_acts; not a remote receipt"
                }))?
            );
        }
        Commands::SealReceipt { input, output } => {
            let value: serde_json::Value =
                serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            let sealed = seal_receipt_value(value)?;
            let data = serde_json::to_vec_pretty(&sealed)?;
            if let Some(output) = output {
                fs::write(&output, data)?;
                println!("{}", output.display());
            } else {
                println!("{}", String::from_utf8(data)?);
            }
        }
        Commands::VerifyReceipt { input } => {
            let value: serde_json::Value =
                serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({"valid": verify_receipt_value(&value)?}))?
            );
        }
        Commands::Admit { act, context } => {
            let act: LogLineAct = serde_json::from_slice(&fs::read(&act).context("read act")?)?;
            let ctx: AdmissionContext = match context {
                Some(path) => {
                    serde_json::from_slice(&fs::read(&path).context("read admission context")?)?
                }
                None => AdmissionContext::default(),
            };
            let admission = admit_lab_act(&act, &ctx);
            println!("{}", serde_json::to_string_pretty(&admission)?);
        }
        Commands::Ghost {
            path,
            id,
            missing,
            why,
            blocks,
            owner,
            next_act,
        } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let ghost = GhostRecord {
                ghost_id: id.clone(),
                missing: missing.clone(),
                why_it_matters: why,
                blocks,
                owner,
                next_act,
                opened_at: now_rfc3339(),
                status: GhostStatus::Open,
            };
            let payload = serde_json::to_string(&ghost)?;
            ledger.record_ghost(&id, &missing, &payload, "open")?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({"ghost_id": id, "status": "open"}))?
            );
        }
        Commands::Workorder {
            path: _,
            id,
            process,
            target_lab,
            mode,
            objective,
        } => {
            let mode = match mode.as_str() {
                "read_only" => HermesMode::ReadOnly,
                "dry_run" => HermesMode::DryRun,
                "apply" => HermesMode::Apply,
                _ => unreachable!(),
            };
            let dispatch = DispatchPacket {
                dispatch_version: "minilab.dispatch.v0".to_string(),
                packet_id: format!("dispatch.{}", id),
                correlation_id: id.clone(),
                created_at: now_rfc3339(),
                created_by: "logline-lab-cli".to_string(),
                process_id: process.clone(),
                organ: "LAB".to_string(),
                office: "LAB Reporter".to_string(),
                packet_type: DispatchPacketType::Verification,
                authority_level: "read_only".to_string(),
                objective: objective.clone(),
                input_sources: vec!["vendor/logline-foundation".to_string()],
                proposed_action: "prepare Hermes dry-run workorder".to_string(),
                expected_evidence: vec!["execution_report".to_string()],
                rollback_or_rectify: "none_for_dry_run".to_string(),
                required_human_check: "none_for_read_only".to_string(),
                ghosts: Vec::new(),
            };
            let workorder = HermesWorkorder {
                workorder_version: "hermes.workorder.v0".to_string(),
                workorder_id: id.clone(),
                correlation_id: id.clone(),
                source_dispatch_packet: dispatch.packet_id.clone(),
                requested_by: "logline-lab-cli".to_string(),
                target_lab,
                process_id: process,
                authority_level: "read_only".to_string(),
                mode,
                allowed_actions: vec![
                    "observe".to_string(),
                    "hash".to_string(),
                    "report".to_string(),
                ],
                forbidden_actions: vec![
                    "provider_mutation".to_string(),
                    "db_semantic_write".to_string(),
                    "secret_value_read".to_string(),
                ],
                inputs: vec![json!({"objective": objective})],
                expected_outputs: vec!["execution_report".to_string()],
                evidence_required: vec!["timestamp".to_string(), "redaction_status".to_string()],
                artifact_policy: "content_address_outputs_when_any".to_string(),
                secret_policy: "secret_names_only_no_values".to_string(),
                timeout_seconds: 60,
                rollback_or_rectify: "not_applicable_for_dry_run".to_string(),
                receipt_profile: "none_until_evidence_review".to_string(),
            };
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "dispatch": dispatch,
                    "workorder": workorder,
                    "claim_limits": "proposal printed to stdout; no file-truth write; emit an act to record consequence"
                }))?
            );
        }
        Commands::HermesDryRun { path: _, workorder } => {
            let workorder: HermesWorkorder =
                serde_json::from_slice(&fs::read(&workorder).context("read workorder")?)?;
            let report = DryRunHermes.execute(&workorder);
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
        Commands::ClockTick { path, lab_id } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let tick = ClockTick::manual(lab_id, "manual");
            let receipt = tick.act.to_receipt()?;
            let row = ActRow {
                id: receipt.id.clone(),
                who: tick.act.who.clone(),
                did: tick.act.did.clone(),
                this: tick.act.this.clone(),
                when_ts: tick.act.when.clone(),
                confirmed_by: tick.act.confirmed_by.clone(),
                if_ok: tick.act.if_ok.clone(),
                if_doubt: tick.act.if_doubt.clone(),
                if_not: tick.act.if_not.clone(),
                status: tick.act.status.clone(),
                tuple_hash: Some(receipt.hashes.tuple_hash.clone()),
                content_hash: Some(receipt.hashes.content_hash.clone()),
            };
            let entry = ledger.append_act(&row)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "tick_id": tick.tick_id,
                    "act_id": receipt.id,
                    "outbox_seq": entry.seq,
                    "claim_limits": "clock tick recorded as a local act and queued for outbox; not remote-confirmed"
                }))?
            );
        }
        Commands::Report { path } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let report = ledger.report()?;
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
        Commands::Outbox { path, limit } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let pending = ledger.pending_outbox(limit)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "count": pending.len(),
                    "pending": pending,
                    "claim_limits": "entries awaiting delivery to ops.logline_acts; \
                        run `sync` to push them"
                }))?
            );
        }
        Commands::Sync { path, max } => {
            let ledger = LocalLedger::open(ledger_path(&path))?;
            let mut spine = match SupabaseSpine::from_env() {
                Ok(s) => s,
                Err(e) => {
                    eprintln!("connect error: {e}");
                    let mut src = e.source();
                    while let Some(s) = src {
                        eprintln!("  caused by: {s}");
                        src = s.source();
                    }
                    return Err(anyhow::anyhow!("supabase connect failed"));
                }
            };
            let report =
                OutboxSync::drain(&ledger, &mut spine, max).map_err(|e| anyhow::anyhow!("{e}"))?;
            let remote_acts = spine.act_count().map_err(|e| anyhow::anyhow!("{e}"))?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "pending_before": report.pending,
                    "shipped": report.shipped,
                    "failed": report.failed,
                    "remote_acts_now": remote_acts,
                    "claim_limits": "shipped = acts pushed via ops.ingest_logline_act \
                        (idempotent on content_hash); failed entries stay pending, not dropped"
                }))?
            );
        }
    }
    Ok(())
}
