//! CLI integration test: the `logline-lab` binary writes truth to the local
//! ledger (the storage rule), not to files. Drives the real built binary end-to-end:
//!
//! ```txt
//! init  ->  emit-act  ->  ghost  ->  outbox  ->  report
//! ```
//!
//! Asserts both that the truth path runs on the ledger and that the report makes
//! no broad claim (no remote confirmation).

use std::process::Command;

const BIN: &str = env!("CARGO_BIN_EXE_logline-lab");

fn run(args: &[&str]) -> String {
    let out = Command::new(BIN)
        .args(args)
        .output()
        .expect("spawn logline-lab");
    assert!(
        out.status.success(),
        "command {:?} failed (status {:?}): {}",
        args,
        out.status.code(),
        String::from_utf8_lossy(&out.stderr)
    );
    String::from_utf8(out.stdout).expect("utf8 stdout")
}

#[test]
fn cli_truth_path_runs_on_the_ledger() {
    let dir = tempfile::tempdir().unwrap();
    let home = dir.path().to_str().unwrap();

    // init creates the SQLite ledger (truth), plus a manifest file (config).
    run(&["init", home, "santo-andre", "dan"]);
    assert!(
        dir.path().join("lab.db").exists(),
        "init must create the SQLite ledger"
    );

    // emit-act writes act + outbox event to the ledger and returns canonical hashes.
    let emitted = run(&[
        "emit-act",
        home,
        "dan",
        "declare_lab",
        "santo-andre",
        "observed",
        "--confirmed-by",
        "manual",
        "--if-ok",
        "project_manifest",
        "--if-doubt",
        "open_ghost",
        "--if-not",
        "reject",
    ]);
    assert!(
        emitted.contains("content_hash"),
        "emit-act must report a content hash: {emitted}"
    );
    assert!(
        emitted.contains("\"outbox_status\": \"pending\""),
        "the act must be queued pending in the outbox: {emitted}"
    );

    // ghost records into the ledger.
    run(&["ghost", home, "ghost.cli.test", "missing-evidence"]);

    // outbox surfaces exactly one pending delivery.
    let outbox = run(&["outbox", home]);
    assert!(
        outbox.contains("\"count\": 1"),
        "exactly one pending outbox entry: {outbox}"
    );

    // report projects local state and refuses any remote/broad claim.
    let report = run(&["report", home]);
    assert!(report.contains("\"acts\": 1"), "report acts: {report}");
    assert!(
        report.contains("\"outbox_pending\": 1"),
        "report pending: {report}"
    );
    assert!(
        report.contains("\"ghosts_open\": 1"),
        "report ghosts: {report}"
    );
    assert!(
        report.contains("\"remote_confirmed\": false"),
        "report must not claim remote truth: {report}"
    );
    assert!(
        report.contains("not remote-confirmed"),
        "report must state its scope limits: {report}"
    );
}
