#![forbid(unsafe_code)]

use anyhow::Context;
use logline_lab_core::ClockTick;
use std::env;

fn main() -> anyhow::Result<()> {
    let lab_id = env::args()
        .nth(1)
        .unwrap_or_else(|| "local-lab".to_string());
    let tick = ClockTick::manual(lab_id, "standalone");
    let out = serde_json::to_string_pretty(&tick).context("serialize tick")?;
    println!("{out}");
    Ok(())
}
