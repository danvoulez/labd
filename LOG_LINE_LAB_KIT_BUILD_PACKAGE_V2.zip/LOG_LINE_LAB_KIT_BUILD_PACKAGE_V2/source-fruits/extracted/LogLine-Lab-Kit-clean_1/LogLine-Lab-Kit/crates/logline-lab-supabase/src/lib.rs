#![forbid(unsafe_code)]

//! Supabase spine driver: push local acts into `ops.logline_acts` through the
//! audited, idempotent `ops.ingest_logline_act(jsonb)` boundary.
//!
//! TLS rule: certificate verification is required. For Supabase poolers signed by
//! a project CA, set `LOGLINE_LAB_SUPABASE_CA_CERT` to a PEM file containing that
//! CA certificate. There is no unsafe "accept any certificate" fallback.

use base64::Engine;
use postgres::Client;
use rustls::pki_types::CertificateDer;
use rustls::RootCertStore;
use serde_json::Value;
use std::env;
use std::fs;

pub type BoxErr = Box<dyn std::error::Error + Send + Sync>;

/// Adopted migrations, relative to the workspace root.
pub const MIGRATIONS_DIR: &str = "ops/supabase/migrations";

fn certs_from_pem(bytes: &[u8]) -> Result<Vec<CertificateDer<'static>>, BoxErr> {
    let text = std::str::from_utf8(bytes)?;
    let mut out = Vec::new();
    let mut rest = text;
    const BEGIN: &str = "-----BEGIN CERTIFICATE-----";
    const END: &str = "-----END CERTIFICATE-----";
    while let Some(start) = rest.find(BEGIN) {
        let after_begin = &rest[start + BEGIN.len()..];
        let Some(end) = after_begin.find(END) else {
            return Err("certificate PEM has BEGIN without END".into());
        };
        let body: String = after_begin[..end]
            .chars()
            .filter(|ch| !ch.is_whitespace())
            .collect();
        let der = base64::engine::general_purpose::STANDARD.decode(body)?;
        out.push(CertificateDer::from(der));
        rest = &after_begin[end + END.len()..];
    }
    if out.is_empty() {
        return Err("no PEM certificate blocks found".into());
    }
    Ok(out)
}

fn root_store_from_env() -> Result<RootCertStore, BoxErr> {
    let path = env::var("LOGLINE_LAB_SUPABASE_CA_CERT").map_err(|_| {
        "LOGLINE_LAB_SUPABASE_CA_CERT is required; refusing Supabase TLS without certificate verification"
    })?;
    let bytes = fs::read(&path)?;
    let certs = certs_from_pem(&bytes)?;
    let mut roots = RootCertStore::empty();
    let mut added = 0usize;
    for cert in certs {
        roots.add(cert)?;
        added += 1;
    }
    if added == 0 {
        return Err("no CA certificates loaded".into());
    }
    Ok(roots)
}

pub struct SupabaseSpine {
    client: Client,
}

impl SupabaseSpine {
    /// Connect using an explicit Postgres URL and verified rustls TLS.
    pub fn connect(database_url: &str) -> Result<Self, BoxErr> {
        let provider = std::sync::Arc::new(rustls::crypto::ring::default_provider());
        let config = rustls::ClientConfig::builder_with_provider(provider)
            .with_safe_default_protocol_versions()?
            .with_root_certificates(root_store_from_env()?)
            .with_no_client_auth();
        let tls = tokio_postgres_rustls::MakeRustlsConnect::new(config);
        let client = Client::connect(database_url, tls)?;
        Ok(Self { client })
    }

    /// Connect from `DATABASE_URL`.
    pub fn from_env() -> Result<Self, BoxErr> {
        let url = env::var("DATABASE_URL")?;
        Self::connect(&url)
    }

    /// Push one local act payload through the idempotent spine function.
    pub fn ingest_act(&mut self, payload: &Value) -> Result<String, BoxErr> {
        let row = self.client.query_one(
            "select ops.ingest_logline_act($1::jsonb)::text",
            &[payload],
        )?;
        Ok(row.get::<_, String>(0))
    }

    /// Count current remote acts in the spine.
    pub fn act_count(&mut self) -> Result<i64, BoxErr> {
        let row = self
            .client
            .query_one("select count(*)::bigint from ops.logline_acts", &[])?;
        Ok(row.get(0))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pem_parser_reads_certificate_blocks() {
        let pem = b"-----BEGIN CERTIFICATE-----\nAQID\n-----END CERTIFICATE-----\n";
        let certs = certs_from_pem(pem).unwrap();
        assert_eq!(certs.len(), 1);
        assert_eq!(certs[0].as_ref(), &[1, 2, 3]);
    }
}
