# LogLine Lab Kit

A LogLine Lab is a practice kit for studying LogLine itself: its acts, engines, clocks, projections, ghosts, evidence, receipts, intervals, runtimes, and workorders.

This distribution does not redefine the LogLine canon. The canon is carried under `docs/canon/` and `vendor/logline-foundation/`. The kit supplies the installable Lab surface around it: a Rust CLI, local ledger, outbox, Supabase spine adapter, primitives, examples, templates, and guides.

```txt
LogLine Foundation  -> canon and grammar
Developer Community -> shared practice
LogLine Lab         -> installable practice kit
Santo Andre Lab     -> first opinionated instance/example
minilab.work        -> Dan's later control plane boundary
```

## What this kit is

- a CLI and runtime practice kit;
- a local-first way to emit nine-slot LogLine acts;
- a ledger path that records local acts in SQLite and queues consequences through an outbox;
- a Supabase spine adapter for `ops.logline_acts`;
- a package of primitives and templates for labs, probes, ghosts, receipts, runtimes, intervals, projectors, clocks, and workorders;
- a study surface for what happens when LogLine moves through software, agents, contracts, databases, simulations, people, and reality.

## What this kit is not

- not a dashboard;
- not an AI agent framework;
- not a pharmaceutical/HIV lab;
- not a transcript of an LLM conversation;
- not a second canon;
- not a file-truth system.

## Storage rule

```txt
local ledger       = SQLite at <lab-home>/lab.db
local consequences = outbox table in the same transaction
remote spine       = ops.logline_acts through Supabase ingest
files              = config, examples, templates, or temporary export only
```

A local act is not a remote receipt. A local report must say its own boundary.

## Install

From this directory:

```bash
./install.sh
```

The script builds the CLI in release mode and installs `logline-lab` to `${HOME}/.local/bin` by default.

Manual equivalent:

```bash
cargo build --release -p logline-lab-cli
mkdir -p "$HOME/.local/bin"
cp target/release/logline-lab "$HOME/.local/bin/logline-lab"
```

## First local run

```bash
logline-lab init lab-home santo-andre dan

logline-lab emit-act lab-home dan declare_lab santo-andre observed \
  --confirmed-by manual \
  --if-ok project_manifest \
  --if-doubt open_ghost \
  --if-not reject

logline-lab outbox lab-home
logline-lab report lab-home
```

Expected boundary: `report` projects local state only. Pending outbox entries are not remote truth.

## Remote spine sync

`sync` pushes pending local acts to the Supabase spine through `ops.ingest_logline_act(jsonb)`:

```bash
export DATABASE_URL='postgres://...'
export LOGLINE_LAB_SUPABASE_CA_CERT='/absolute/path/to/supabase-ca.pem'
logline-lab sync lab-home
```

TLS verification is required. There is no unsafe `accept any certificate` fallback.

## Public kit contents

```txt
README.md
install.sh
Cargo.toml / Cargo.lock / rust-toolchain.toml
crates/logline-lab-core
crates/logline-lab-cli
crates/logline-lab-clock
crates/logline-lab-hermes
crates/logline-lab-local-sql
crates/logline-lab-outbox
crates/logline-lab-supabase
crates/logline-lab-labd
crates/logline-lab-artifacts
docs/canon
docs/contracts
docs/guides
docs/experiments
examples
templates
vendor/logline-foundation
ops/supabase/migrations
```

We Trust and Build with LogLine.
