# Package manifest

Included:

- Rust workspace for LogLine Lab CLI and crates
- Canon and contract documents
- Guides, experiments, examples, templates
- Vendored LogLine Foundation references
- Supabase migrations under `ops/supabase/migrations`

Excluded from this distribution:

- ChatGPT/LLM transcripts
- agent settings
- generated inventories / fusion plans
- build target directories
- duplicate scaffold trees
- macOS metadata

Authority boundary:

- `docs/canon/` carries canon text.
- Code and tests define executable behavior.
- Transcripts are not project authority and are not shipped.
