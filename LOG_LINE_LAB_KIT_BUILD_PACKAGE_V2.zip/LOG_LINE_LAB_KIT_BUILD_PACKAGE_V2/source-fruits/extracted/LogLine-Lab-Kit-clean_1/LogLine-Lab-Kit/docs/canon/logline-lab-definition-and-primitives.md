# LogLine Lab — Definition, Scope, Primitives, and Evidence Discipline

**Status:** founding definition / canon candidate  
**Layer:** LogLine Lab public kit and practice primitive  
**Purpose:** freeze what a LogLine Lab is before implementation, scale, branding, or local deployment obscure the concept  
**Parent:** LogLine Foundation, unchanged  
**Children:** local labs, Santo André Laboratory, Dan/minilab.work overlay, community labs, domain-specific labs  
**Motto:** We Trust and Build with LogLine.

---

## 0. Founding Sentence

A **LogLine Lab** is a living laboratory kit for studying LogLine itself and building with LogLine under real conditions.

It gives people a way to load the LogLine canon, declare local practice, register runtimes, emit acts, run probes, project worlds, preserve ghosts, prepare receipts, and study what happens when LogLine moves through software, AI, contracts, simulations, databases, agents, people, and reality.

A LogLine Lab does not prescribe scale, budget, programming language, cloud provider, or research agenda.

It provides primitives.

Each lab adds infrastructure according to its own resources, risks, interests, jurisdiction, and ambition.

---

## 1. Public Position

```txt
LogLine Foundation is the grammar.
LogLine Lab is the practice kit.
A local lab is a declared instantiation.
```

A LogLine Lab is not the Foundation.

A LogLine Lab is not a product category.

A LogLine Lab is not a dashboard.

A LogLine Lab is not an AI agent framework.

A LogLine Lab is not a database schema.

A LogLine Lab is not a single runtime.

A LogLine Lab is not Dan's private infrastructure.

A LogLine Lab is a kit for creating a place where LogLine can be studied, run, projected, tested, doubted, and built with.

---

## 2. Non-Amendment Rule

A LogLine Lab does not silently change LogLine canon.

If the Lab introduces operational discipline not present in LogLine Foundation, it must declare that discipline as Lab practice, local practice, or experimental practice.

Allowed:

```txt
This lab requires runtime envelopes.
This lab projects passports from register_entity acts.
This lab projects visas from issue_visa acts.
This lab uses Supabase as projection substrate.
This lab runs a 24/7 AI clock.
This lab studies interval semantics.
```

Forbidden:

```txt
Claiming local lab rules are Foundation canon.
Hiding operational assumptions inside infrastructure.
Treating a database projection as parent truth.
Treating a runtime convention as universal LogLine law.
```

A LogLine Lab may produce discoveries that later become upstream proposals.

Until accepted upstream, they remain Lab practice or local overlay.

---

## 3. What a LogLine Lab Studies

A LogLine Lab studies **LogLine itself in motion**.

It studies:

```txt
acts
engines
runtimes
runtime envelopes
content-addressed identity
composition
projections
receipts
ghosts
probes
intervals
simulations
real runs
contracts
AI translation into acts
self-parsing
self-bootstrap
what runs natively above software
```

It may also use LogLine to study other domains, but that is secondary.

Primary research object:

```txt
LogLine as a compact act grammar moving through engines, runtimes, projections, procedures, humans, AI, and reality.
```

---

## 4. What a LogLine Lab Does

A LogLine Lab performs six basic functions.

### 4.1 Load

It loads LogLine canon and any declared practice profiles.

```txt
load canon
load conformance
load engine
load local practice
load runtime registry
load projectors
```

### 4.2 Declare

It declares its local practice.

```txt
lab name
purpose
jurisdiction
clock discipline
runtimes
projectors
ghost policy
receipt policy
proof policy
evidence policy
```

### 4.3 Observe

It observes language, systems, models, contracts, computations, simulations, and human decisions as potential LogLine material.

Observation does not equal proof.

Observation becomes proof only when admitted, referenced, and projected through an appropriate evidence path.

### 4.4 Emit

It emits LogLine Acts and candidate acts.

Acts may represent:

```txt
claims
questions
probes
runtime results
decisions
bindings
permissions
contracts
experiments
receipts
ghosts
state changes
reports
```

### 4.5 Project

It projects acts into useful read models.

Examples:

```txt
registry
runtimes
visas
passports
evidence
receipts
ghosts
experiments
audit views
reports
standards adapters
```

Projection gives domain meaning.

Projection is not semantic source.

### 4.6 Learn

It studies what happened.

Learning may produce:

```txt
new probes
new projectors
new runtimes
new ghosts
new receipts
new local rules
new upstream proposals
new failures worth preserving
```

---

## 5. What a LogLine Lab Does Not Do

A LogLine Lab does not prescribe:

```txt
scale
budget
cloud provider
programming language
database engine
AI model vendor
hardware profile
research topic
business domain
social form
public/private posture
```

A LogLine Lab does not require a corporation, foundation, university, lab building, GPU cluster, or formal institution.

A LogLine Lab may be:

```txt
a personal lab
a research lab
a company lab
a civic lab
a classroom lab
a contract lab
a simulation lab
a local AI lab
a governance lab
a software lab
a physical machine lab
a public-interest lab
```

The Lab gives primitives.

The operator chooses scale.

---

## 6. Core Primitive: LogLine Act

Every semantic movement in a LogLine Lab should be representable as a LogLine Act.

Canonical semantic shape:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

The nine slots are the compact backbone.

They preserve:

```txt
agent
action
object/material/claim
time
confirmation path
success route
doubt route
failure route
epistemic or operational state
```

A LogLine Lab may use additional envelopes, projections, indexes, tables, files, reports, and artifacts.

These do not replace the act.

---

## 7. Static Atom, Dynamic Translation

LogLine is small and static.

Current LLMs make it newly practical because they can translate natural language into the nine-slot act grammar with low semantic loss.

The translation is not lossless.

It has loss comparable to translation between natural languages, not the severe loss of forcing living intention into a static paper form by hand.

LogLine does not eliminate ambiguity.

It gives ambiguity a route:

```txt
if_doubt
```

What cannot honestly be frozen as certainty is preserved as doubt, probe, ghost, or unresolved state.

---

## 8. Core Primitive: Runtime Envelope

A LogLine Lab may require every admitted or observed act to carry a runtime envelope.

The envelope is not a tenth semantic slot.

The envelope is provenance.

Minimum conceptual envelope:

```yaml
runtime_id:
engine_id:
run_id:
admission_status:
emitted_at:
observed_at:
tuple_hash:
content_hash:
previous_act_refs: []
```

Rule:

```txt
The act is content.
The envelope is provenance.
```

The act says what happened.

The envelope says where, how, by which runtime, and under which admission/observation path the act entered the Lab.

---

## 9. Core Primitive: Runtime Registry

A LogLine Lab should maintain a projected runtime registry.

The runtime registry describes what a runtime is, what it can emit, what it can admit, what it can observe, and what kinds of acts/projections it is associated with.

Conceptual fields:

```yaml
runtime_id:
runtime_entity_ref:
engine_entity_ref:
lab_id:
status:
capabilities: []
accepted_dids: []
projection_hints: {}
evidence_policy: {}
authority_policy: {}
last_seen_at:
passport_act_ref:
latest_act_ref:
```

Rule:

```txt
The runtime registry is capability.
```

Domain meaning is interpreted through:

```txt
did + this + runtime_id + runtime registry + projector rules
```

---

## 10. Core Primitive: Projection

The semantic database is LogLine.

Tables, views, APIs, dashboards, reports, adapters, indexes, and standard mappings are projections.

```txt
The database is LogLine.
The tables are projections.
```

A projection may be:

```txt
local
private
public
domain-specific
query-optimized
UI-oriented
standard-compatible
compliance-oriented
experimental
disposable
rebuildable
```

A projection may map LogLine Acts into world-known standards when useful.

Examples:

```txt
W3C PROV
OpenTelemetry
RO-Crate
FHIR
GS1 / EPCIS
ActivityPub
OpenAPI / JSON Schema
accounting ledgers
inventory systems
custom domain schemas
```

LogLine does not need to replace world standards.

LogLine can wrap them.

Rule:

```txt
LogLine is the write model.
Standards are projection models.
```

---

## 11. Core Primitive: Ghost

A ghost is preserved absence.

A ghost records what cannot yet be honestly proven, closed, executed, admitted, projected, or decided.

A ghost is not failure.

A ghost is the Lab refusing to lie.

Ghosts may represent missing:

```txt
evidence
runtime
source
signature
permission
receipt path
projection rule
input
witness
reproducibility
conformance
implementation
semantic clarity
```

A ghost should name:

```txt
what is missing
why it matters
what it blocks
who/what owns the next act
what would close or narrow it
```

---

## 12. Core Primitive: Probe

A probe is a bounded attempt to touch reality, computation, or evidence.

A probe may be manual, runtime-driven, AI-assisted, simulated, computational, physical, contractual, or social.

A probe must preserve:

```txt
claim under test
method
runtime or actor
inputs
expected observation
evidence path
doubt path
failure path
```

A probe does not guarantee closure.

A probe produces observation, evidence, ghost, or next probe.

---

## 13. Core Primitive: Evidence

Evidence is a referenceable observation that supports or weakens a claim.

Evidence may come from:

```txt
runtime output
artifact hash
sensor observation
manual witness
signed document
model output under declared limits
simulation result
conformance test
external standard report
transaction trace
contract performance record
```

Evidence is not automatically receipt.

Evidence supports closure only within declared scope.

Evidence should preserve:

```txt
source
runtime or witness
observed_at
artifact refs
hashes when possible
redaction status
scope
limits
```

---

## 14. Core Primitive: Receipt

A receipt is scoped closure projected from admitted acts and evidence.

A receipt is not a native magical object.

It is a LogLine-shaped closure accepted by a receipt projector or review process.

A receipt should say:

```txt
what claim or interval it closes
what evidence supports it
what scope is closed
what scope is not closed
what ghosts remain
what runtime or reviewer admitted closure
```

Forbidden receipt behavior:

```txt
closing broad claims from narrow evidence
calling runtime success proof of system success
calling model output evidence by itself
claiming future guarantee from past observation
hiding ghosts
```

---

## 15. Core Primitive: Passport

A passport is a projection of an admitted identity act.

Typical source act:

```txt
did = register_entity
```

A passport may represent:

```txt
human
agent
LLM office
computer
LAB
engine
runtime
service
OAuth client
MCP tool
app
artifact
jurisdiction
institution
```

The institutional identity anchor is content-addressed.

```txt
passport_ref = act://sha256:<register_entity_act_hash>
```

A table row may store the projection.

The act is the identity source.

---

## 16. Core Primitive: Visa

A visa is a projection of an admitted permission act composed over a passport.

Typical source act:

```txt
did = issue_visa
```

A visa declares:

```txt
subject passport
issuer
capabilities
scope
constraints
audience
expiry
revocation or supersession path
```

A visa is not execution.

A visa is permission.

Execution still requires a relevant process, runtime, workorder, envelope, and evidence path.

---

## 17. Core Primitive: Workorder

A workorder is a projected execution unit.

It is not free language.

It is not authority by itself.

It is a bounded act or act-derived packet that tells a registered runtime what may be attempted under declared scope.

A workorder should define:

```txt
objective
target runtime or LAB
mode
allowed actions
forbidden actions
inputs
expected outputs
evidence requirements
secret policy
rollback or rectify path
receipt path
```

A LogLine Lab may use Hermes or any other runtime to execute workorders.

The runtime is replaceable.

The act discipline is not.

---

## 18. Core Primitive: Clock

A LogLine Lab becomes alive when it has a clock.

The clock gives rhythm to observation, routing, probing, reporting, ghost review, and state projection.

A clock may be manual, scheduled, worker-driven, AI-assisted, or fully automated.

A clock may:

```txt
emit tick acts
check stale ghosts
review runtime heartbeat
prepare state reports
suggest probes
queue dispatch candidates
prepare receipts for review
produce daily and weekly reports
```

A clock may not:

```txt
authorize protected action silently
erase ghosts
close receipts without evidence
mutate external systems without admitted workorders
publish without authority
pretend motion is truth
```

Rule:

```txt
A Lab without a clock is a folder with ambition.
```

---

## 19. Core Primitive: Interval

A LogLine interval is a bounded act field between two boundary acts.

```txt
start boundary act
finish boundary act
```

Inside the interval may exist:

```txt
candidate acts
simulation paths
real runtime runs
observations
evidence
ghosts
receipts
projections
reports
next acts
```

A simulation is a possible path through an interval.

A real run is a path emitted or observed by a registered runtime with envelope provenance.

A result act is not an ending.

It may become input to a future interval.

---

## 20. Core Primitive: Composition

LogLine composition is not Lego-like mechanical symmetry.

It is closer to polar chemistry.

Every act has the same backbone, but different polarity.

```txt
nine slots = common backbone
did + this = side chain
confirmed_by = evidence binding
runtime envelope = environment
prior refs = composition history
projection = observed function
```

Acts bind differently depending on role.

Examples:

```txt
passport acts bind to visa acts
visa acts bind to workorder acts
workorder acts bind to runtime result acts
runtime result acts bind to evidence projections
evidence acts bind to receipt acts
ghost acts bind to next probe acts
```

Composition is directional, contextual, and history-bearing.

---

## 21. Reproducibility

In LogLine, reproducibility is not merely rerunning code.

Reproducibility means the ability to recover and continue the same act-shaped history:

```txt
intention
runtime
evidence
projection
closure
doubt
next experiment
```

Reproducibility includes:

```txt
content reproducibility
provenance reproducibility
projection reproducibility
runtime reproducibility when possible
meaning reproducibility
scientific reproducibility
```

Formula:

```txt
reproducibility =
  content addressability
+ runtime provenance
+ referenced inputs
+ deterministic projection
+ explicit doubt paths
+ composable next acts
```

If full runtime reproducibility is impossible, the Lab preserves the original observation and names the missing reproducibility as a ghost.

---

## 22. Self-Parsing and Self-Bootstrap

LogLine can become self-parsing and self-bootstrapping because its procedure remains inside the grammar.

The consequence slots:

```txt
if_ok
if_doubt
if_not
```

allow acts to route next acts.

A procedure can be represented as a sequence or graph of LogLine Acts.

The system can use LogLine Acts to:

```txt
register its own runtime
declare its own projector
issue its own visa
open its own probe
record its own evidence
carry its own ghost
emit its own receipt
```

It does not bootstrap from nothing.

It bootstraps from a seed:

```txt
nine-slot grammar
engine
hash/admission rule
runtime envelope practice if required
```

After that, the act graph can describe the machine that reads the act graph.

---

## 23. Above Software Thesis

When software can rewrite software, runtime is no longer the highest layer of meaning.

AI can generate scripts.

Scripts can mutate runtimes.

Runtimes can emit tools.

Tools can alter state.

State can alter prompts.

Prompts can alter future code.

This requires a layer above ordinary software.

LogLine names that layer.

```txt
Software executes.
AI proposes and mutates.
LogLine governs the act.
```

A LogLine Lab studies what runs natively above software:

```txt
law
proof
transcript
atom graph
runtime provenance
worker boundaries
manager planes
jurisdiction
signature
economics of work
physical boundaries
responsibility
```

---

## 24. Relationship to AI

LogLine feels native to current AI because AI is unusually strong at:

```txt
pattern recognition
classification
structure extraction
summarization
comparison
routing
candidate generation
```

LogLine gives that ability a compact act target.

```txt
AI finds patterns.
LogLine lets them enter history.
```

AI output is candidate material.

It may assist:

```txt
extracting acts
classifying ghosts
summarizing intervals
suggesting probes
preparing receipts
comparing projections
```

It may not, by itself:

```txt
be authority
be evidence
close receipt
erase ghost
execute protected action
promote canon
```

---

## 25. Relationship to Contracts

LogLine is native to contracts because contracts are made of:

```txt
parties
acts
obligations
conditions
confirmation paths
success consequences
doubt/dispute paths
breach/remedy paths
status
```

A contract can be projected as an act graph:

```txt
obligation act
performance act
confirmation act
doubt act
breach act
remedy act
receipt act
ghost act
```

LogLine does not replace contracts.

It wraps obligations, performance, evidence, and consequence.

---

## 26. Relationship to Science

LogLine does not replace scientific method.

It provides a portable act atom for cumulative practice.

A scientific or experimental cycle may be represented as:

```txt
claim
probe
runtime observation
evidence
receipt or ghost
next claim
```

The same shape repeats.

Results become inputs.

Ghosts become probes.

Receipts become governance.

Experiments become new practice.

---

## 27. Relationship to Standards

A LogLine Lab does not compete with specialized standards or methods.

It wraps them.

```txt
We do not compete with Monte Carlo.
We wrap Monte Carlo in LogLine.
```

The same applies to:

```txt
FHIR
OpenTelemetry
W3C PROV
RO-Crate
GS1 / EPCIS
ActivityPub
accounting standards
simulation standards
contract formats
domain schemas
```

LogLine provides the act/provenance/composition layer beneath standards.

Standards can be projection dialects.

---

## 28. Minimal Lab Capacities

A minimal LogLine Lab needs only a few capacities.

### Required

```txt
access to LogLine canon
ability to write/read LogLine Acts
some admission/validation process
some storage for acts
some way to reference prior acts
some way to preserve ghosts
some way to report state
```

### Strongly Recommended

```txt
content addressing
runtime envelopes
runtime registry
projectors
clock discipline
evidence registry
receipt review process
conformance tests
manifest file
```

### Optional

```txt
LLMs
local models
Hermes-like worker
Supabase/Postgres
SQLite
Git repository
web UI
MCP tools
OAuth
hardware LABs
sensor systems
simulation engines
public website
community review
```

A Lab can start manually.

Automation is not required for legitimacy.

Automation increases scale, not truth.

---

## 29. Minimal Lab Manifest

A LogLine Lab should eventually declare a manifest.

Conceptual shape:

```yaml
logline_lab_manifest:
  manifest_version: 1

  lab:
    name:
    steward:
    purpose:
    public_status: private | public | mixed

  loads:
    foundation:
    practice_profiles: []
    local_overlay:

  primitives:
    runtime_envelope_required:
    content_addressing_required:
    ghost_policy:
    receipt_policy:

  runtimes: []
  projectors: []
  clocks: []
  evidence_paths: []
  proof_paths: []
  ghost_registry:
  receipt_registry:

  constraints:
    scale:
    budget:
    allowed_tools:
    forbidden_actions:
```

The manifest declares practice.

It does not create canon.

---

## 30. Evidence and Proof Discipline

A LogLine Lab should distinguish:

```txt
claim
candidate
observation
evidence
proof process
receipt
ghost
```

A claim says something may be true.

A candidate is a proposed act.

An observation is contact with something.

Evidence is referenceable observation.

A proof process is a structured path for deciding admissibility or closure.

A receipt is scoped closure.

A ghost is preserved unresolved state.

Forbidden collapses:

```txt
model output = evidence
runtime success = receipt
database row = truth
projection = canon
confidence = proof
execution = closure
absence = failure
```

---

## 31. Scale Rule

A LogLine Lab must not prescribe scale.

The same primitives should work for:

```txt
one person and a folder
one person and a database
a small research group
a private company
a public community
a school
a city project
a contract network
a machine fleet
an AI lab
```

Small labs may operate manually.

Medium labs may automate projections and clocks.

Large labs may run multiple runtimes, standards adapters, and public conformance.

The Lab definition must remain independent of infrastructure scale.

---

## 32. Language Rule

A LogLine Lab must not establish a single running language.

It may be implemented in:

```txt
Rust
TypeScript
Python
SQL
Bash
Go
Elixir
Java
Clojure
or any future runtime
```

The important constraint is not language.

The important constraint is:

```txt
Can the system emit, preserve, project, and study LogLine-shaped acts?
```

---

## 33. Public Kit Contents

A public LogLine Lab kit should eventually include:

```txt
README
lab manifest template
act examples
invalid act examples
runtime envelope template
runtime registry template
ghost registry template
receipt template
probe template
interval template
projector examples
clock discipline template
conformance instructions
standards adapter examples
first Lab Report template
```

It should be possible to start small and grow without changing the core idea.

---

## 34. Recommended Study Benches

A LogLine Lab may define benches.

### Dialogue Observatory

Studies conversations as intervals where concepts become acts.

### Runtime Observatory

Studies what engines and runtimes emit, admit, reject, ghost, or project.

### Projector Lab

Studies how acts become worlds.

### Composition Lab

Studies act polarity, act folding, and act entanglement.

### Interval Workbench

Studies start/finish boundaries, simulations, real runs, and result acts.

### Contract Bench

Studies obligations, performance, breach, remedy, and receipt.

### Simulation Bench

Studies Monte Carlo and other simulation engines as wrapped LogLine runs.

### Standards Adapter Bench

Studies how LogLine projects into external standards.

### Ghost Review Bench

Studies preserved absence and unresolved claims.

### Receipt Bench

Studies scoped closure.

---

## 35. First Lab: Santo André Laboratory

Santo André Laboratory may be the first public LogLine Lab.

It is not the definition of all labs.

It is the first face, reference practice, and research theater.

Possible positioning:

```txt
Santo André Laboratory
The first LogLine Lab.

A clocked laboratory for studying LogLine in motion:
acts, engines, runtimes, projections, ghosts, receipts, intervals,
and what runs natively above software.
```

Santo André may publish:

```txt
experiments
receipts
ghosts
misuse studies
runtime autopsies
projection studies
interval studies
lab reports
upstream proposals
```

---

## 36. Local Deployments

A local deployment is not the Lab concept itself.

Examples:

```txt
Santo André Laboratory
Dan/minilab.work
community lab
company lab
research group lab
classroom lab
```

Each deployment declares:

```txt
what it loads
what it studies
what it runs
what it projects
what it ghosts
what it publishes
what it keeps private
```

---

## 37. Acceptance Criteria for Something Calling Itself a LogLine Lab

A system may call itself a LogLine Lab if it can honestly show:

```txt
1. It loads or references LogLine canon.
2. It emits or preserves LogLine Acts.
3. It distinguishes acts from projections.
4. It has a ghost discipline.
5. It has an evidence/proof discipline.
6. It can declare local practice.
7. It can name its runtimes or human procedures.
8. It can produce at least one report of what it studied or built.
9. It does not claim local practice as Foundation canon.
```

A stronger Lab can also show:

```txt
runtime envelopes
content addressing
projectors
clock discipline
receipt registry
standards adapters
conformance checks
public experiments
```

---

## 38. Open Ghosts

```txt
logline-lab-definition-not-promoted
lab-manifest-schema-unformalized
runtime-envelope-practice-unformalized
runtime-registry-projector-unimplemented
ghost-registry-template-unimplemented
receipt-template-unimplemented
interval-semantics-unformalized
act-entanglement-term-risk
self-bootstrap-semantics-unformalized
standards-adapter-map-unimplemented
santo-andre-first-lab-manifest-missing
lab-clock-implementation-missing
```

---

## 39. Final Formulation

```txt
A LogLine Lab freezes a place where LogLine can be studied and built with.

It does not prescribe scale.
It does not prescribe language.
It does not prescribe budget.
It does not prescribe domain.

It gives primitives:
acts, envelopes, runtimes, projections, ghosts, probes, evidence, receipts,
intervals, clocks, manifests, and local practice.

From those primitives, each lab adds infrastructure at its own scale,
under its own constraints,
for its own questions.

The purpose is not to make another framework.
The purpose is to let the world discover what LogLine can become.
```

---

## 40. Signature

```txt
We Trust and Build with LogLine.
```

