# Canon Grounding

This kit is grounded in the repos extracted from `logline-foundation-canonical-repos.zip`.

## Existing stack used

| Source | Role in this kit |
|---|---|
| `canon` | Canon mold, especially `logline.receipt.v0`. |
| `conformance` | Proof suite, schemas, vectors, and receipt hash rules. |
| `engine` | Rust implementation of the nine-slot LogLine body and receipt hashing helpers. |
| `constitutional-runtime` | Rust admission, policy, capability, evidence, planning, and execution boundary. |
| `governance` | Change process; the Lab does not silently amend canon. |
| `ethics-is-efficient` | Existing Rust JCS/SHA-256/receipt implementation reference and TDLN bounded policy shape. |
| `what-runs-natively-above-software` | Constitutional architecture for gates, proof runtime, storage, worker ABI, manager plane, jurisdiction, and horizon of the real. |

## Fixed rules carried forward

```txt
canon defines
conformance proves
engine implements
governance evolves
```

```txt
Natural language never executes.
Only structured acts / IR / admitted workorders cross runtime boundaries.
```

```txt
Receipts beat stories.
Evidence supports closure but does not equal closure.
```

```txt
Hermes receives workorders, not wishes.
```

```txt
Local Lab practice does not silently become Foundation canon.
```

## Kit-level additions

The Lab Kit adds practice primitives around the canonical stack:

```txt
lab manifest
runtime envelope
runtime registry
ghost registry
probe record
evidence record
receipt draft / sealed receipt
passport projection
visa projection
workorder
clock tick
interval
first lab report
```

These are Lab practice objects. They are not upstream canon unless later promoted through governance.
