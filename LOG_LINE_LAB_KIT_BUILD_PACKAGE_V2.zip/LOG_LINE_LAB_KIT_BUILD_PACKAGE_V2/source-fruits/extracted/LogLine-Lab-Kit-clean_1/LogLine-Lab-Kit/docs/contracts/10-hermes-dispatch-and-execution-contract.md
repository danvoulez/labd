# 10 — Hermes Dispatch and Execution Contract

## Purpose

This document defines the seam where Lab work leaves interpretation and may become execution.

```txt
Process Catalog
-> Vertical Runtime Doctrine
-> Dispatch Packet
-> Authority classification
-> Hermes Workorder
-> LAB execution
-> Execution Report
-> Evidence Record
-> Receipt Candidate or Ghost
-> Current State projection
```

## Canonical sentence

```txt
Hermes executes only admitted workorders:
dispatch packets describe work,
Constitutional Runtime admits shape,
Authority gates consequence,
Dan or the responsible signer approves protected scope,
Hermes runs on LABs,
evidence returns,
receipts close narrowly,
and ghosts preserve what cannot honestly close.
```

## Execution law

```txt
Hermes receives workorders, not wishes.
```

Forbidden path:

```txt
chat message -> Hermes command -> claimed completion
```

Correct path:

```txt
intent -> process -> dispatch packet -> runtime admission -> authority classification -> Hermes workorder -> LAB execution -> evidence packet -> receipt/ghost/projection
```

## First lawful implementation

The included `logline-lab-hermes` crate implements `DryRunHermes`.

It may:

```txt
accept read_only and dry_run workorders
report the boundary as observed
preserve secret redaction status
return execution_report.v0
```

It may not:

```txt
touch external systems
run shell commands
mutate providers
write semantic DB state
close receipts
approve protected actions
```

## Workorder fields

See `templates/workorder.json` and `crates/logline-lab-core/src/workorder.rs`.

Minimum workorder:

```txt
workorder_version
workorder_id
correlation_id
source_dispatch_packet
requested_by
target_lab
process_id
authority_level
mode
allowed_actions
forbidden_actions
inputs
expected_outputs
evidence_required
artifact_policy
secret_policy
timeout_seconds
rollback_or_rectify
receipt_profile
```
