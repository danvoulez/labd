# 09 — Vertical Runtime Doctrine

## Canonical sentence

```txt
LogLine Lab happens through operator-mediated constitutional runtime:
offices interpret intent,
processes lower intent into LogLine candidates,
local cognition may assist below authority,
Constitutional Runtime admits or ghosts,
Authority gates consequence,
Hermes executes admitted work,
evidence returns,
receipts close narrowly,
and projections update state.
```

## Vertical law

```txt
Processes are not checklists.
Processes are constitutional trajectories.
```

Every consequential process declares:

```txt
which organ owns it
which office conducts it
which sources govern it
whether local cognition is allowed
what candidate act is produced
what admission boundary applies
what authority class applies
whether dispatch is required
whether Hermes may execute
what evidence must return
what may close
what must remain ghost
where state projects
```

## Forbidden collapses

```txt
operator output = truth
model output = admitted act
process step = authority
dispatch packet = execution
Hermes run = receipt
LAB identity = permission
runtime observation = closure
projection = canon
report = proof
```

## Runtime line

```txt
Intent -> Office -> Process -> Act -> Admission -> Dispatch -> Hermes -> Evidence -> Receipt/Ghost -> Projection
```
