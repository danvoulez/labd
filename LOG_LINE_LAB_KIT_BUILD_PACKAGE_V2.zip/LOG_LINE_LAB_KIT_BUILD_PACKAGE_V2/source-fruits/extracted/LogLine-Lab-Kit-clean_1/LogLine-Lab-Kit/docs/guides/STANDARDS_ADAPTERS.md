# Standards Adapter Notes

A LogLine Lab does not compete with domain standards. It wraps them.

Possible projection dialects:

```txt
W3C PROV
OpenTelemetry
RO-Crate
FHIR
GS1 / EPCIS
ActivityPub
OpenAPI / JSON Schema
accounting ledgers
custom domain schemas
```

Rule:

```txt
LogLine is the write model.
Standards are projection models.
```

This kit includes a minimal W3C PROV-shaped example under `examples/standards/w3c_prov_projection.json`.
