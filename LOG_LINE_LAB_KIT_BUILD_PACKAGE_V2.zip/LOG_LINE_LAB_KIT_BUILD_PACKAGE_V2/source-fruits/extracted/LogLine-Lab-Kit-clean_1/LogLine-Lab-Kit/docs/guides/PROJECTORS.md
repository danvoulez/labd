# Projectors

A projector is a read model derived from LogLine-shaped material.

```txt
Projection gives domain meaning.
Projection is not semantic source.
```

Initial projector families:

```txt
current_state
ghost_registry
evidence_registry
receipt_registry
runtime_registry
experiment_registry
standards_adapter
```

A projector must preserve source refs and claim limits. It must not create canon, authority, or closure by rendering a view.

See `templates/projector_definition.json` and `examples/projectors/current_state_projector.rs`.
