# LogLine Lab Clock

```txt
A Lab without a clock is a folder with ambition.
```

The clock creates rhythm. It does not become authority.

## May

```txt
emit tick acts
check stale ghosts
prepare reports
queue dispatch candidates
check runtime heartbeat
prepare next probes
```

## May not

```txt
approve protected actions
close receipts silently
mutate providers
erase ghosts
invent evidence
```

The included `logline-lab-clock` binary emits a manual tick report. More automatic clocks should still emit LogLine Acts and preserve ghosts.
