# Build and local operation

## Requirements

- Rust toolchain compatible with `rust-toolchain.toml`
- Cargo
- Optional: Supabase/Postgres URL for remote spine sync

## Build

```bash
cargo build --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --release -p logline-lab-cli
```

## Install CLI

```bash
./install.sh
```

## Local ledger flow

```bash
logline-lab init lab-home santo-andre dan

logline-lab emit-act lab-home dan declare_lab santo-andre observed \
  --confirmed-by manual \
  --if-ok project_manifest \
  --if-doubt open_ghost \
  --if-not reject

logline-lab ghost lab-home ghost.example missing-evidence
logline-lab outbox lab-home
logline-lab report lab-home
```

## Remote spine flow

```bash
export DATABASE_URL='postgres://...'
export LOGLINE_LAB_SUPABASE_CA_CERT='/absolute/path/to/supabase-ca.pem'
logline-lab sync lab-home
```

The local ledger never claims remote truth. `sync` is the boundary that attempts delivery to `ops.logline_acts`.
