# Build status

This file records local verification commands for the distribution.

A valid release receipt for this kit is the output of:

```bash
cargo fmt --check
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --release -p logline-lab-cli
```

No document in this kit may claim those commands passed unless the command output exists for that exact package state.

Remote Supabase sync is a separate receipt. It requires `DATABASE_URL`, a trusted Supabase CA certificate path in `LOGLINE_LAB_SUPABASE_CA_CERT`, and a successful `logline-lab sync <lab-home>` run.
