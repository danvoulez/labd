# Conformance Guide

The Lab Kit does not own conformance. It consumes conformance.

The vendored conformance repo defines:

```txt
schemas
valid vectors
invalid vectors
hash profiles
reference verifier
```

Receipt rule used by this kit:

```txt
tuple_hash = sha256(jcs(pick nine slots))
content_hash = sha256(jcs(receipt except id and hashes))
envelope_hash = sha256(jcs({content, transport}))
```

The Lab core uses the vendored Rust engine's `logline-status` receipt helpers for `tuple_hash`, `content_hash`, and canonical JSON.

## Lab obligation

A Lab may say it emits receipts only when emitted receipts pass conformance.

A Lab may not say a runtime observation is a receipt.
