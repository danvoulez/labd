# EXP-000 — Can a LogLine Lab load the canonical stack?

## Claim

A minimal LogLine Lab can load the canonical stack, register its sources, emit acts, preserve ghosts, and prepare scoped receipts without inventing a new canon.

## Inputs

```txt
vendor/logline-foundation/canon
vendor/logline-foundation/conformance
vendor/logline-foundation/engine
vendor/logline-foundation/constitutional-runtime
vendor/logline-foundation/governance
vendor/logline-foundation/ethics-is-efficient
vendor/logline-foundation/what-runs-natively-above-software
```

## Procedure

```txt
1. Register each repo as a source.
2. Register each Rust crate as a runtime/capability candidate.
3. Emit one Lab manifest.
4. Emit one act.
5. Seal one receipt.
6. Open ghosts for missing build/runtime proof.
7. Produce first Lab Report.
```

## Success criteria

```txt
Lab manifest exists.
At least one LogLine Act exists.
At least one sealed receipt exists.
At least one ghost exists.
Hermes dry-run returns execution_report.v0.
No broad claim is closed from narrow evidence.
```

## Known ghosts

```txt
cargo-runtime-unavailable-in-current-environment
rust-conformance-verifier-not-yet-implemented
formal-projector-map-unimplemented
live-hermes-runner-not-yet-implemented
```
