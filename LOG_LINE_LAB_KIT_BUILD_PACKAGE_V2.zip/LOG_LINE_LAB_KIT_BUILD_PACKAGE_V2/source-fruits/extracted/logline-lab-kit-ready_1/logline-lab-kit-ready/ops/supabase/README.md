# Supabase spine (ops/)

Adopted from `LAB-KIT-main/supabase/migrations` (inventory: ADOPT). Lab practice.

Semantic truth = `ops.logline_acts`. Everything else (`evidence.*`, `receipts.*`,
`workorders.*`, `registry.*`, `audit.*`) is a derived SQL view. See ADR-0002.

Migrations 0001–0010 define the spine, registry, audit views, observability,
evidence/receipt/workorder projections, authz, projector functions, and RLS.

`0011`–`0013` extend the spine to the full ADR-0002 model (see
`docs/inventory/supabase-schema-review.md` for the runtime receipts):

- `0011_ingest_idempotent_immutable.sql` — content-hash unique index, append-only
  trigger, and the audited `ops.ingest_logline_act(jsonb)` boundary.
  **Verified on stock Postgres 16.**
- `0012_dead_letters.sql` — append-only `ops.dead_letters` store ("no infinite
  retry"). **Verified on stock Postgres 16.**
- `0013_queues_pgmq.sql` — pgmq consequence queues (`q_lab_outbox`, `q_workorders`,
  `q_receipts`, `q_projection_rebuild`, `q_artifact_cleanup`) + `pg_cron`.
  **Written, NOT verified** — needs the real Supabase instance (those extensions
  aren't in stock Postgres). Ghost: `queue-layer-runtime-unverified`.

Still open (not written): the queue **workers** that drain the queues, and the
pg_cron schedules (intentionally not created before a worker exists — a no-op
schedule would be plastic). Ghost: `queue-workers-unimplemented`.
