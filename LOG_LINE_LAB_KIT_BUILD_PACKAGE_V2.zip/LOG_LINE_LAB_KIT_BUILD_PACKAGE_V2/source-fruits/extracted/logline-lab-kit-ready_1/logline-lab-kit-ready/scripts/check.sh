#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "== cargo fmt --check =="
cargo fmt --check

echo "== cargo check --workspace =="
cargo check --workspace

echo "== cargo test --workspace =="
cargo test --workspace

echo "== cargo clippy --workspace --all-targets -- -D warnings =="
cargo clippy --workspace --all-targets -- -D warnings

echo "== cargo build --workspace =="
cargo build --workspace

echo "== cli --help =="
cargo run -q -p logline-lab-cli -- --help

echo "== conformance suite =="
(cd vendor/logline-foundation/conformance && node tools/verify-receipt.mjs --suite)
