#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$HOME/.local/bin"
cp "$ROOT/bin/logline-lab" "$HOME/.local/bin/logline-lab"
chmod +x "$HOME/.local/bin/logline-lab"
echo "Installed: $HOME/.local/bin/logline-lab"
echo "Make sure ~/.local/bin is on PATH."
