#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ROOT/bin/logline-lab"
if [[ ! -x "$BIN" ]]; then
  BIN="cargo run -q -p logline-lab-cli --"
fi
: "${DATABASE_URL:?DATABASE_URL is required. Run under Doppler or export DATABASE_URL.}"
LAB_HOME="$ROOT/_run/remote-sync-lab"
rm -rf "$LAB_HOME"
mkdir -p "$ROOT/_run"

echo "== init =="
$BIN init "$LAB_HOME" santo-andre dan

echo "== emit-act =="
$BIN emit-act "$LAB_HOME" dan test_remote_outbox_sync santo-andre observed \
  --confirmed-by local_cli \
  --if-ok sync_to_supabase \
  --if-doubt keep_outbox_pending \
  --if-not open_sync_ghost

echo "== sync =="
$BIN sync "$LAB_HOME" --max 10

echo "== report =="
$BIN report "$LAB_HOME"
