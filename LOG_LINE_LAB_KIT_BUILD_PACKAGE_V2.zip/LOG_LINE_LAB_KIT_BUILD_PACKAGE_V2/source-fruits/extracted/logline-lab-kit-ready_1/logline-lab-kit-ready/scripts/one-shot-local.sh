#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ROOT/bin/logline-lab"
if [[ ! -x "$BIN" ]]; then
  BIN="cargo run -q -p logline-lab-cli --"
fi
LAB_HOME="$ROOT/_run/local-lab"
rm -rf "$LAB_HOME"
mkdir -p "$ROOT/_run"

echo "== init =="
$BIN init "$LAB_HOME" santo-andre dan

echo "== emit-act =="
$BIN emit-act "$LAB_HOME" dan declare_lab santo-andre observed \
  --confirmed-by manual \
  --if-ok project_manifest \
  --if-doubt open_ghost \
  --if-not reject

echo "== ghost =="
$BIN ghost "$LAB_HOME" ghost.local.demo missing-remote-sync \
  --why "Remote sync was intentionally not run in the local one-shot." \
  --next-act "run one-shot-remote-sync under Doppler when ready"

echo "== outbox =="
$BIN outbox "$LAB_HOME"

echo "== report =="
$BIN report "$LAB_HOME"

echo "== files =="
find "$LAB_HOME" -maxdepth 2 -type f -print
