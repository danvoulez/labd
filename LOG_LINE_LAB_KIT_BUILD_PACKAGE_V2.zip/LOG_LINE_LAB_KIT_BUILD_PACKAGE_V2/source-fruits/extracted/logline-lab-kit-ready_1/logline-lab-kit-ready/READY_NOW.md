# READY NOW — LogLine Lab Kit

This package contains a runnable LogLine Lab Kit snapshot.

It includes:

- Rust workspace source.
- Vendored LogLine Foundation stack.
- Local SQLite ledger + outbox truth path.
- Supabase spine migrations under `ops/supabase/migrations`.
- A prebuilt **macOS arm64** binary at `bin/logline-lab`.
- Local one-shot scripts under `scripts/`.

## What is ready

The local Lab path is ready:

```txt
init -> emit-act -> local SQLite ledger -> outbox -> ghost/report
```

The remote path is wired in code through `sync`, but requires `DATABASE_URL` from your secret provider:

```txt
local outbox -> ops.ingest_logline_act -> Supabase ops.logline_acts
```

## Fastest local run

From this folder on an Apple Silicon Mac:

```bash
./scripts/one-shot-local.sh
```

It creates `_run/local-lab`, emits one LogLine Act, opens one Ghost, lists the outbox, and prints a local report.

## Remote sync run

Use only with credentials loaded from Doppler/env, never pasted into files:

```bash
DATABASE_URL='postgres://...' ./scripts/one-shot-remote-sync.sh
```

Preferred:

```bash
doppler run --project santo-andre --config dev -- ./scripts/one-shot-remote-sync.sh
```

## Hard boundaries

- Semantic writes are acts.
- Local operational ledger is SQLite.
- Remote spine is Supabase `ops.logline_acts`.
- Files are not truth.
- Secrets are not in this package.
- Supabase credentials must come from env/Doppler.

## Caveat

I could not run `cargo` inside this ChatGPT container because Rust is not installed here. This archive includes the macOS arm64 binary already present in your uploaded build, plus source and scripts. On your Mac, run `./scripts/check.sh` for the full receipt sweep.
