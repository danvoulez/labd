use serde::{de::DeserializeOwned, Serialize};
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, thiserror::Error)]
pub enum LabStoreError {
    #[error("io error: {0}")]
    Io(#[from] io::Error),
    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
}

#[derive(Clone, Debug)]
pub struct FileLabStore {
    pub root: PathBuf,
}

impl FileLabStore {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    pub fn init_layout(&self) -> Result<(), LabStoreError> {
        for dir in [
            "acts",
            "receipts",
            "ghosts",
            "evidence",
            "workorders",
            "reports",
            "runtime-registry",
            "projections",
            "intervals",
            "probes",
        ] {
            fs::create_dir_all(self.root.join(dir))?;
        }
        Ok(())
    }

    pub fn path(&self, subdir: &str, id: &str) -> PathBuf {
        self.root
            .join(subdir)
            .join(format!("{}.json", sanitize_id(id)))
    }

    pub fn write_json<T: Serialize>(
        &self,
        subdir: &str,
        id: &str,
        value: &T,
    ) -> Result<PathBuf, LabStoreError> {
        self.init_layout()?;
        let path = self.path(subdir, id);
        let bytes = serde_json::to_vec_pretty(value)?;
        fs::write(&path, bytes)?;
        Ok(path)
    }

    pub fn read_json<T: DeserializeOwned>(
        &self,
        path: impl AsRef<Path>,
    ) -> Result<T, LabStoreError> {
        let bytes = fs::read(path)?;
        Ok(serde_json::from_slice(&bytes)?)
    }
}

pub fn sanitize_id(id: &str) -> String {
    id.chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_' | '.') {
                ch
            } else {
                '_'
            }
        })
        .collect()
}
