#![forbid(unsafe_code)]

//! Temporary artifact spool (ADR-0002).
//!
//! Files here are **never truth** — only spool/cache/export. The hard rule is
//! enforced in code: nothing survives past [`TTL_SECONDS`] (24h). The Supabase
//! `q_artifact_cleanup` queue will drive [`ArtifactSpool::gc`] on a schedule.

use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime};

/// Hard TTL from ADR-0002: no artifact older than 24h.
pub const TTL_SECONDS: u64 = 86_400;

pub struct ArtifactSpool {
    root: PathBuf,
}

impl ArtifactSpool {
    /// Open (creating if absent) a spool directory.
    pub fn new(root: impl Into<PathBuf>) -> io::Result<Self> {
        let root = root.into();
        fs::create_dir_all(&root)?;
        Ok(Self { root })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Write a spooled artifact and return its path.
    pub fn put(&self, name: &str, bytes: &[u8]) -> io::Result<PathBuf> {
        let path = self.root.join(name);
        fs::write(&path, bytes)?;
        Ok(path)
    }

    /// Delete every spooled file whose age relative to `now` exceeds
    /// [`TTL_SECONDS`]. Returns the deleted paths. `now` is a parameter so the
    /// rule is deterministically testable and the cleanup queue can pass a clock.
    pub fn gc(&self, now: SystemTime) -> io::Result<Vec<PathBuf>> {
        let ttl = Duration::from_secs(TTL_SECONDS);
        let mut deleted = Vec::new();
        for entry in fs::read_dir(&self.root)? {
            let entry = entry?;
            let path = entry.path();
            if !path.is_file() {
                continue;
            }
            let modified = entry.metadata()?.modified()?;
            if let Ok(age) = now.duration_since(modified) {
                if age > ttl {
                    fs::remove_file(&path)?;
                    deleted.push(path);
                }
            }
        }
        Ok(deleted)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gc_keeps_fresh_and_deletes_expired() {
        let dir = tempfile::tempdir().unwrap();
        let spool = ArtifactSpool::new(dir.path()).unwrap();
        let path = spool.put("export.json", b"{}").unwrap();
        assert!(path.exists());

        // Fresh: a gc at "now" deletes nothing.
        assert!(spool.gc(SystemTime::now()).unwrap().is_empty());
        assert!(path.exists());

        // A gc clocked past the TTL treats the file as expired and removes it.
        let past_ttl = SystemTime::now() + Duration::from_secs(TTL_SECONDS + 3600);
        let deleted = spool.gc(past_ttl).unwrap();
        assert_eq!(deleted.len(), 1);
        assert!(!path.exists());
    }
}
