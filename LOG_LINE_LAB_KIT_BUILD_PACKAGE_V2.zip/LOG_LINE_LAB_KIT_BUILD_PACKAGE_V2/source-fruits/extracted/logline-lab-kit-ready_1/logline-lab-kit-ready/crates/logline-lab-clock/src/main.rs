#![forbid(unsafe_code)]

use anyhow::Context;
use logline_lab_core::{ClockTick, FileLabStore};

fn main() -> anyhow::Result<()> {
    let root = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "lab-home".to_string());
    let lab_id = std::env::args()
        .nth(2)
        .unwrap_or_else(|| "local-lab".to_string());
    let store = FileLabStore::new(root);
    let tick = ClockTick::manual(lab_id, "manual");
    let path = store
        .write_json("reports", &tick.tick_id, &tick)
        .context("write clock tick")?;
    println!("{}", path.display());
    Ok(())
}
