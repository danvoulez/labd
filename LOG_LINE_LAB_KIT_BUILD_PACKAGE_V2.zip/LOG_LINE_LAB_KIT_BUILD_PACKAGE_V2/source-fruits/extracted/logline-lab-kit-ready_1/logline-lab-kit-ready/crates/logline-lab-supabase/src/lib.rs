#![forbid(unsafe_code)]

//! Supabase spine driver (ADR-0002 / migration 0011): push local acts into
//! `ops.logline_acts` through the audited, idempotent `ops.ingest_logline_act(jsonb)`
//! boundary. Synchronous Postgres client over rustls TLS.
//!
//! TLS note: macOS Secure Transport rejects Supabase's pooler cert (validity period
//! exceeds Apple's cap), and the pooler is signed by Supabase's own CA (not a public
//! root). So we use rustls with **encryption but no chain verification** — the same
//! posture as libpq `sslmode=require`, which is what was used to verify this spine.
//! KNOWN LIMITATION: no MITM authentication. Upgrade to verify-full by bundling the
//! Supabase CA cert (ghost: `supabase-tls-no-verify`).

use postgres::Client;
use rustls::client::danger::{HandshakeSignatureValid, ServerCertVerified, ServerCertVerifier};
use rustls::crypto::CryptoProvider;
use rustls::pki_types::{CertificateDer, ServerName, UnixTime};
use rustls::{DigitallySignedStruct, SignatureScheme};
use serde_json::Value;
use std::sync::Arc;

pub type BoxErr = Box<dyn std::error::Error + Send + Sync>;

/// Adopted migrations, relative to the workspace root.
pub const MIGRATIONS_DIR: &str = "ops/supabase/migrations";

/// Encrypt-but-don't-verify cert checker == libpq `sslmode=require`. See module note.
#[derive(Debug)]
struct NoCertVerify(Arc<CryptoProvider>);

impl ServerCertVerifier for NoCertVerify {
    fn verify_server_cert(
        &self,
        _end_entity: &CertificateDer<'_>,
        _intermediates: &[CertificateDer<'_>],
        _server_name: &ServerName<'_>,
        _ocsp: &[u8],
        _now: UnixTime,
    ) -> Result<ServerCertVerified, rustls::Error> {
        Ok(ServerCertVerified::assertion())
    }
    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }
    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }
    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        self.0.signature_verification_algorithms.supported_schemes()
    }
}

pub struct SupabaseSpine {
    client: Client,
}

impl SupabaseSpine {
    /// Connect using an explicit Postgres URL (Supabase pooler; rustls TLS).
    pub fn connect(database_url: &str) -> Result<Self, BoxErr> {
        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let config = rustls::ClientConfig::builder_with_provider(provider.clone())
            .with_safe_default_protocol_versions()?
            .dangerous()
            .with_custom_certificate_verifier(Arc::new(NoCertVerify(provider)))
            .with_no_client_auth();
        let tls = tokio_postgres_rustls::MakeRustlsConnect::new(config);
        let client = Client::connect(database_url, tls)?;
        Ok(Self { client })
    }

    /// Connect using `DATABASE_URL` from the environment
    /// (e.g. injected by `doppler run --project santo-andre --config dev -- ...`).
    pub fn from_env() -> Result<Self, BoxErr> {
        let url = std::env::var("DATABASE_URL").map_err(|_| {
            "DATABASE_URL not set — run under: \
             doppler run --project santo-andre --config dev -- <cmd>"
        })?;
        Self::connect(&url)
    }

    /// Connectivity probe.
    pub fn check(&mut self) -> Result<(), BoxErr> {
        self.client.simple_query("select 1")?;
        Ok(())
    }

    /// Push one act payload into the spine via the audited, idempotent ingest
    /// boundary (dedupe on `content_hash`). Returns the act id (uuid as text).
    pub fn ingest_act(&mut self, payload: &Value) -> Result<String, BoxErr> {
        let row = self.client.query_one(
            "select id::text from ops.ingest_logline_act($1::jsonb)",
            &[payload],
        )?;
        let id: String = row.get(0);
        Ok(id)
    }

    /// Count of acts currently in the remote spine.
    pub fn act_count(&mut self) -> Result<i64, BoxErr> {
        let row = self
            .client
            .query_one("select count(*)::bigint from ops.logline_acts", &[])?;
        Ok(row.get(0))
    }
}
