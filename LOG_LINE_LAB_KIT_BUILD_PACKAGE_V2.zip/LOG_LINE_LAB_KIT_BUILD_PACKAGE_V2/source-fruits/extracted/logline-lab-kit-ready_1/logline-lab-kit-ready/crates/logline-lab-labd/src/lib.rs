#![forbid(unsafe_code)]

//! labd — the Lab's HTTP/API surface (ADR-0002). It writes to the local SQL
//! ledger or to Supabase, and **never treats files as truth**.
//!
//! STUB — no axum server yet. [`serve`] returns a Ghost instead of binding a
//! socket, so a stub can never be mistaken for a running daemon.

/// Structured absence: what is missing for honest closure.
#[derive(Debug)]
pub struct Ghost {
    pub ghost_id: &'static str,
    pub missing: &'static str,
}

/// Start the labd server on `bind`. Unimplemented.
pub fn serve(_bind: &str) -> Result<(), Ghost> {
    Err(Ghost {
        ghost_id: "labd-http-surface-unimplemented",
        missing: "axum router + local-sql / supabase write wiring",
    })
}
