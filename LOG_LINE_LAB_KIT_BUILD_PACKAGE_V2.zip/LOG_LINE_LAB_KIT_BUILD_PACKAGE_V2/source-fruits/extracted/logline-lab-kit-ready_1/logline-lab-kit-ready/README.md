# LogLine Lab Kit — Rust Distribution

A Rust-first LogLine Lab starter kit assembled from the canonical repos included in the uploaded zip.

This kit does **not** redefine LogLine canon. It loads and vendors the canonical stack, then adds the Lab layer: manifests, runtime envelopes, ghosts, probes, evidence records, workorders, receipts, clocks, reports, and Rust operators for the first local laboratory.

```txt
LogLine Foundation = grammar / canon
LogLine engine     = Rust implementation of the nine-slot body
Conformance        = proof that engines obey
Constitutional Runtime = admission / policy / capability / evidence boundary
LogLine Lab        = practice kit
Hermes             = execution hand for admitted workorders
```

## Rust-first decision

The critical path is Rust:

```txt
crates/logline-lab-core     # primitives and receipt/admission helpers
crates/logline-lab-hermes   # Hermes workorder execution contract, dry-run only by default
crates/logline-lab-clock    # Lab pulse/tick act producer
crates/logline-lab-cli      # CLI for init, act, receipt, ghost, workorder, report
```

The vendored repos stay under `vendor/logline-foundation/` as sources and path dependencies where appropriate.

## Canonical repos vendored

```txt
vendor/logline-foundation/canon
vendor/logline-foundation/conformance
vendor/logline-foundation/engine
vendor/logline-foundation/constitutional-runtime
vendor/logline-foundation/governance
vendor/logline-foundation/ethics-is-efficient
vendor/logline-foundation/what-runs-natively-above-software
```

## Commands

Truth lives in a local SQLite ledger at `<lab home>/lab.db` (ADR-0002), not in
per-type JSON files. `init`, `emit-act`, `ghost`, `report`, and `outbox` operate
on that ledger:

```bash
cargo run -p logline-lab-cli -- init lab-home santo-andre dan
cargo run -p logline-lab-cli -- emit-act lab-home dan declare_lab santo-andre observed \
  --confirmed-by manual --if-ok project_manifest --if-doubt open_ghost --if-not reject
cargo run -p logline-lab-cli -- ghost lab-home ghost.example missing-evidence
cargo run -p logline-lab-cli -- outbox lab-home   # pending deliveries to the remote spine
cargo run -p logline-lab-cli -- report lab-home   # local state projection (never claims remote truth)
```

`emit-act` seals the canonical receipt hashes (engine/conformance path) and writes
the act plus its outbox event in one transaction. No receipt is "closed" locally —
that is a remote consequence (see ADR-0002).

Hermes/dispatch/clock are intentionally dry-run and, for now, **transitional**:
they still write to the file store and move onto the queue when the Supabase
spine lands (`workorder`, `hermes-dry-run`, `clock-tick`).

## Build status

Verified on 2026-05-29 in a Rust environment: `cargo fmt/check/test/clippy/build`
pass, the conformance suite reports `21 passed, 0 failed`, and the CLI flow runs
end-to-end on the ledger. (The original assembly environment had no `cargo`/`rustc`;
that build ghost is now closed. See `docs/guides/BUILD_STATUS.md` and
`docs/decisions/0002-storage-model.md`.)

## Public kit contents included

The kit includes the required public Lab pieces:

```txt
README
lab manifest template
act examples
invalid act examples
runtime envelope template
runtime registry template
ghost registry template
receipt template
probe template
interval template
projector examples
clock discipline
conformance instructions
standards adapter notes
first Lab Report template
```

## First experiment

See `docs/experiments/EXP-000-load-canonical-stack.md`.

```txt
EXP-000 — Can a LogLine Lab load the canonical stack?
```

The correct first proof is not deployment. It is whether the Lab can load canon, identify engines, emit acts, preserve ghosts, prepare receipts, and report what it has actually observed.
