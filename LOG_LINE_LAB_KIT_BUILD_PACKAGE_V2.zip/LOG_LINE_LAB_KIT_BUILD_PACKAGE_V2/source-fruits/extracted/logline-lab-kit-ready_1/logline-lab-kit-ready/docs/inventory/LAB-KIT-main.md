# Inventory — LAB-KIT-main

> **Status:** Lab practice document, not Foundation canon.
> **Generated:** 2026-05-29, against the extracted `LAB-KIT-main` tree (kept under `_inbox/LAB-KIT-main/` for reference during fusion).
> **Purpose:** Classify every item of the operational blueprint (`LAB-KIT-main`) for absorption into the validated Rust base (`logline_lab_kit_rust`, now this workspace root). Per the fusion plan §Fase 2.

## Classification legend

| Class | Meaning |
|-------|---------|
| **ADOPT** | Bring in largely as-is; high value, low conflict. |
| **ADAPT** | Bring in but reshape to fit the Rust-first base / canonical types. |
| **DEDUPE** | Overlaps an existing Rust-base artifact; reconcile, do not double. |
| **SPLIT** | Monolithic; must be broken into crates/modules. |
| **ARCHIVE** | Keep for reference, not on the critical path. |
| **REJECT** | Do not carry forward in current form. |
| **GHOST** | Absorbing this exposes missing evidence/decision; record a ghost. |

---

## Verified base state (this workspace, real receipts — 2026-05-29)

These gates were **run in this session**, not assumed (the kit's own `docs/guides/BUILD_STATUS.md` had recorded `ghost: cargo-runtime-unavailable-in-current-environment` — cargo was never run when the kit was assembled):

| Gate | Result |
|------|--------|
| `cargo fmt --check` | exit 0 (after applying `cargo fmt` + fixing `exclude`) |
| `cargo check --workspace` | exit 0 |
| `cargo test --workspace` | exit 0 — **but 0 tests** (vacuous; lab crates have no tests yet) |
| `cargo clippy --workspace --all-targets -- -D warnings` | exit 0 |
| `cargo build --workspace` | exit 0 |
| `cargo run -p logline-lab-cli -- --help` | exit 0 (10 subcommands) |
| `node vendor/.../conformance/tools/verify-receipt.mjs --suite` | **21 passed, 0 failed** |

Two base fixes were required to reach green and are themselves Lab practice:
1. `Cargo.toml`: `exclude = ["vendor/**"]` → `exclude = ["vendor"]` (Cargo `exclude` takes literal path prefixes, not globs; the glob matched nothing, pulling vendored engine crates into the root workspace and breaking `url` inheritance).
2. `cargo fmt` applied to normalize one unformatted import block in `logline-lab-hermes`.

---

## Item-by-item classification

### Supabase spine — **ADOPT**
`supabase/migrations/0001..0010`. Design matches the plan invariant exactly: a single semantic-truth table `ops.logline_acts` (9 slots as columns + `runtime_envelope`, `tuple_hash`, `content_hash`, `evidence_state`, `promotion_state`), with **everything else as derived SQL views** — `evidence.*`, `receipts.*`, `workorders.*`, `registry.*`, `audit.*`. Includes CHECK constraints enforcing canon (receipt candidates require `evidence_refs`; execution reports require `secret_redacted`), GIN index on `this`, and RLS (`0010`) blocking direct public access.
- **Target:** `ops/supabase/migrations/` (per plan Fase 4).
- **Note:** This is the single highest-value asset in LAB-KIT-main.

### JSON schemas — **ADAPT** (+ GHOST: schema↔Rust-type parity)
`schemas/*.json` (10): `logline-act`, `receipt-candidate`, `evidence`, `ghost`, `dispatch-packet`, `hermes-workorder`, `execution-report`, `lab-manifest`, `promotion-control`, `runtime-envelope`.
- High value as canonical Lab contracts. **But** they are not yet cross-checked against the `logline-lab-core` Rust structs (`LogLineAct`, `HermesWorkorder`, `DispatchPacket`, `GhostRecord`, `LabManifest`, …). Drift is possible.
- **GHOST `schema-rust-type-parity`:** no probe yet proves the Rust types serialize to documents these schemas accept.

### Rust `src/` (monolith) — mixed
`LAB-KIT-main` is a **single crate** (`logline-lab-kit`, 2,253 LoC) using `axum`, `tokio`, `tokio-postgres`, `jsonschema`, `uuid`, `chrono`, `serde_yaml`, `config`, `dotenvy`. The Rust base is instead a multi-crate workspace. Per file:

| File | LoC | Class | Disposition |
|------|-----|-------|-------------|
| `src/main.rs` | 1015 | **SPLIT** | Break apart; logic belongs in crates below. |
| `src/cli.rs` | 267 | **DEDUPE** | Reconcile against base `logline-lab-cli` (clap). Base CLI is canonical. |
| `src/commands.rs` | 234 | **ADAPT** | `doctor` + `report` logic → seed `doctor`/`report` (plan Fase 7). |
| `src/db.rs` | 180 | **ADAPT** | `tokio-postgres` layer → seed `crates/logline-lab-supabase`. |
| `src/labd.rs` | 151 | **ADAPT** | axum server, ~13 routes → seed `crates/logline-lab-labd` (plan Fase 9). |
| `src/model.rs` | 115 | **DEDUPE** | `LabManifest` differs from base (`semantic_write_spine`, `projection_surface`, `canon_refs`, `hooks`, `benches`). Reconcile. |
| `src/hooks.rs` | 93 | **ADOPT** | Hook engine — capability not in base. New. |
| `src/packets.rs` | 50 | **DEDUPE** | Overlaps base dispatch/workorder packet construction. |
| `src/io.rs` | 31 | **DEDUPE** | Trivial fs helpers; base has `FileLabStore`. |
| `src/hash.rs` | 30 | **DEDUPE** | `sha256:`-prefixed canonical hash. Must match conformance hash profile. |
| `src/schema.rs` | 17 | **ADAPT** | `jsonschema` validation helper — pairs with the schemas above. |

LAB-KIT-main's own crate has **5 passing-by-design unit tests** (manifest spine, receipt-requires-evidence, sha256 prefix, key-order-invariant hash, act-schema-rejects-missing-slots). These are good seeds for the base's missing tests.

### Operational config — **ADOPT**
- `manifests/*.yaml` (lab + santo-andre examples) — **ADOPT**.
- `profiles/*.practice.v0.yaml` — **ADOPT**.
- `hooks/default/*.yaml` (3: verification-plan, require-evidence-refs, require-claim-refs) — **ADOPT** (pairs with `src/hooks.rs`).
- `clock/schedules/*.yaml` — **ADAPT** (base already has `logline-lab-clock`).
- `reports/templates/*.md` (7) — **ADOPT**.
- `.env.example` (SUPABASE_DB_URL etc.) — **ADOPT**.
- `canon/{conformance,foundation}.refs.yaml` — **ADAPT** (reference pointers; verify against vendored versions, do not let them shadow canon).

### Docs — **ADAPT** (+ GHOST: docs promise unimplemented commands)
`docs/00..14` (overview, install, supabase-spine, cli, labd, manifest, projectors, ghosts, evidence, receipts, clock, hooks, dispatch-and-hermes, study-benches, frontends).
- Strong operational narrative. Merge into `docs/`, labeled **Lab practice**.
- **GHOST `cli-docs-promise-unimplemented-commands`:** these docs describe `labd serve`, `supabase check/migrate`, `goal`, `loop`, `simplify` — commands the canonical base CLI does **not** yet expose. Docs must not claim commands that don't exist.

### Benches — **ARCHIVE** (until needed)
`benches/` (11 study environments). Off the critical path for v0.2. Revisit at v0.5+.

### Examples — **ADAPT**
`examples/{minimal-lab,monte-carlo-wrapper,santo-andre,contract-obligation,ai-to-act-translation}`. `santo-andre` overlaps a base example — dedupe.

### Reject / archive outright
- `Cargo.toml` (single-crate monolith) — **REJECT** as-is; harvest its dependency list into the new crates.
- `ChatGPT-Minilab e LogLine (1).md` — **ARCHIVE** (conversation transcript).
- `README.md` — **ARCHIVE/ADAPT** (base README is canonical).
- `LICENSE` (MIT) — **note:** base is `MIT OR Apache-2.0`; reconcile licensing, don't silently narrow.
- `Cargo.lock` — **REJECT** (regenerated by workspace).

---

## Ghosts opened by this inventory

| Ghost | Missing | Blocks |
|-------|---------|--------|
| `lab-kit-main-unbuilt` | No build/test receipt for LAB-KIT-main in any environment (plan calls it "scaffold operacional ainda não provado"). | Trusting any LAB-KIT-main Rust code without compiling it in-tree. |
| `storage-model-reconciliation` | Decision: base stores per-type JSON files (`FileLabStore` → acts/receipts/ghosts/...); Supabase stores **one acts-spine + derived views**. The fusion must pick the canonical model (or define the mapping). | Wiring `logline-lab-supabase` without double-truth. |
| `schema-rust-type-parity` | No probe proves `logline-lab-core` structs satisfy the 10 JSON schemas. | Treating schemas as enforced contracts. |
| `cli-docs-promise-unimplemented-commands` | Docs describe `labd`, `supabase`, `goal`, `loop`, `simplify`; base CLI lacks them. | Publishing docs as accurate. |
| `home-cargo-workspace-interference` | A pre-existing, unrelated `/Users/ubl-ops/Cargo.toml` workspace (logline-core/tdln-*/atomic-*) breaks `cargo fmt --all` (path-dep traversal). Not ours. | Using `cargo fmt --all`; use plain `cargo fmt`. |

## Suggested next fusion order (plan Fase 3–6), bounded

1. Add empty crates `logline-lab-supabase`, `logline-lab-labd` to the workspace (compile as stubs first).
2. Move `supabase/migrations` → `ops/supabase/migrations` (ADOPT, no logic change).
3. Resolve `storage-model-reconciliation` ghost **before** porting `db.rs`.
4. Port `db.rs` → `logline-lab-supabase`; `labd.rs` → `logline-lab-labd`.
5. Port `hooks.rs` + `hooks/default/*.yaml` (new capability).
6. Reconcile `model.rs`/`hash.rs`/schemas against `logline-lab-core` (close `schema-rust-type-parity`).
7. Write `tests/lab_flow.rs` end-to-end (closes the vacuous-test gap), then re-run all gates.
