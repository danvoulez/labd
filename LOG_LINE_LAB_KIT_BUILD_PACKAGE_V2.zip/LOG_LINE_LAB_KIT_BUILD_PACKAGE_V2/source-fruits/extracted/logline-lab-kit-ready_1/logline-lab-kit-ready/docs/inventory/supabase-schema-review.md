# Supabase schema review

> Lab practice. 2026-05-29. Scope: review the spine migrations for ideality and
> extend them to the ADR-0002 model. Greenfield (no data), training.

## What was verified (real receipts, ephemeral Postgres 16, local)

The migrations had **never been run** before (the `lab-kit-main-unbuilt` ghost).
They now have a runtime receipt:

- `0001–0010` apply cleanly → `ops.logline_acts` + `ops.schema_migrations`, and the
  derived view schemas `evidence` (4), `receipts` (5), `workorders` (3), `audit` (5),
  `lab_observability` (5), `authz` (1), plus `registry` tables. 23 views total.
- `0011–0012` apply cleanly and pass **behavioral** probes:
  - idempotent ingest: `ingest_logline_act(payload)` called twice with the same
    `content_hash` → 1 row.
  - append-only: `UPDATE`/`DELETE` on `ops.logline_acts` are blocked (with a row present).
  - slot validation: ingest with missing `who` is rejected.
  - engine slot round-trip: `this`/`confirmed_by` (flat strings in the engine model)
    store as jsonb scalars (`"santo-andre"`, `"manual"`) — no forcing into objects.
- `0013` (pgmq/pg_cron) is **NOT** verified — those extensions aren't in stock
  Postgres. Ghost: `queue-layer-runtime-unverified`.

Validation method: `initdb` ephemeral cluster, apply migrations with `ON_ERROR_STOP`,
run behavioral SQL. No remote DB was mutated.

## Ideality assessment of the original `0001–0010`

**Strong, keep as-is:**
- Single semantic-truth table (`ops.logline_acts`); everything else is a derived
  SQL view. This is the right shape and matches ADR-0002's "remote truth = spine".
- Canon enforced at the DB edge: CHECK constraints require `evidence_refs` for
  `prepare_receipt_candidate` and `secret_redacted` for `report_execution_result`.
- GIN index on `this`; btree on `when`/`did`/`status`.
- RLS deny-all (`0010`) — no direct public access; writes must go through a
  privileged path.

**Gaps fixed in `0011–0013`:**
1. **No idempotency key.** `content_hash` was nullable and non-unique, so the same
   act delivered twice would create two rows — breaking the local outbox's
   "no double send". → `0011` adds a unique index on `content_hash` and an
   idempotent ingest.
2. **No sanctioned write path.** With RLS deny-all there was no defined way in.
   → `0011` adds `ops.ingest_logline_act(jsonb)` `SECURITY DEFINER` — the single
   audited boundary (matches the `DATABASE_ALLOW_OPS_LOGINE_ACT_INSERT` governance flag).
3. **Mutable ledger.** Acts/receipts are supposed to be immutable. → `0011`/`0012`
   add append-only triggers on `ops.logline_acts` and `ops.dead_letters`.
4. **No dead-letter store.** ADR-0002's "no infinite retry → dead_letter + ghost"
   had nowhere to land. → `0012` adds `ops.dead_letters`.
5. **No queue layer.** The whole consequence model was absent. → `0013` creates the
   pgmq queues (`q_lab_outbox`, `q_workorders`, `q_receipts`, `q_projection_rebuild`,
   `q_artifact_cleanup`).

## Reconciliation notes (decisions taken)

- **Slot model:** the vendored engine treats the 9 slots as flat strings; the spine
  models `this`/`confirmed_by`/`if_ok`/`if_doubt`/`if_not` as `jsonb`. These are
  compatible because a string is valid jsonb; `ingest_logline_act` passes slots
  through unchanged. Canon (flat strings) is **not** altered. This concretely
  resolves part of the `schema-rust-type-parity` ghost.
- **Hash format:** the engine emits bare 64-char hex (e.g. `7a26f48d…`), not the
  `sha256:`-prefixed form used by `LAB-KIT-main/src/hash.rs`. The spine stores bare
  hex to match conformance. Do not reintroduce the prefix.
- **Schema name:** the spine lives in schema `ops`. Reference attempt #45
  (Doppler `minilab-work`) uses schema `minilab`. Kept `ops` (clear operational
  namespace); greenfield, so no migration cost. Divergence noted, not blocking.

## Could not do (ghosts)

- `reference-schema-unreadable` — #45's `minilab` schema exists but is not reachable
  read-only: PostgREST rejects it (`Invalid schema: minilab`, not in exposed schemas),
  `public` is empty, and there is no DB password (only the REST service key). Reading
  it would need schema exposure or a management token — admin mutations declined on the
  locked dry-run project. So this review compares against the *local-sql ledger + ADR-0002*,
  not against #45's actual tables.
- `queue-layer-runtime-unverified` — `0013` (pgmq/pg_cron) needs the real Supabase
  instance to verify.
- `queue-workers-unimplemented` — no worker drains the queues yet; pg_cron schedules
  intentionally not created (a no-op schedule would be plastic).
- The Rust `logline-lab-supabase` / `logline-lab-outbox` remote wiring is still stubbed
  — this sprint was schema-only (per the steer). The schema + `ingest_logline_act` are
  now a verified target for that wiring.

## Authority posture (why no remote mutation happened)

Doppler `minilab-work` / `minilab-all-3-computers` is fully locked for writes:
`MINILAB_DRY_RUN=true`, `MINILAB_SAFE_MODE=true`, `MINILAB_EXECUTION_MODE=draft_only`,
`SUPABASE_ALLOW_MIGRATIONS=false`, `MINILAB_ALLOW_SUPABASE_MUTATION=false`,
`DATABASE_ALLOW_OPS_LOGINE_ACT_INSERT=false`, `HUMAN_APPROVAL_REQUIRED_FOR_DB_WRITE=true`.
The schema work was therefore done and verified entirely on a local ephemeral Postgres.
