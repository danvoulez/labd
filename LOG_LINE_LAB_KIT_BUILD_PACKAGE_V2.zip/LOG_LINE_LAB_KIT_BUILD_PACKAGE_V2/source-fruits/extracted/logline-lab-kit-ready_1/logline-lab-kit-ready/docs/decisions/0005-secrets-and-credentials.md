# ADR-0005 — Secrets & credentials

## Status

Accepted — 2026-05-29. Lab practice.

## Decision

**Packages may reference secret providers, but never carry secrets.**

Good (a package declares where secrets come from):

```yaml
secrets:
  provider: doppler
  project: santo-andre
  config: dev
```

Forbidden (a package embedding a secret):

```yaml
database_url: postgres://postgres:REAL-PASSWORD@host/db
```

## Credential abstraction (no hidden lock-in)

Credential providers are pluggable: `env`, `.env`, **Doppler**, Vault, … Doppler is the
first supported provider (the `santo-andre` Doppler project / `dev` config holds the live
spine creds, verified working), but it must be **one provider among several**, not a
dependency — the same anti-vendor-lock discipline applied to Supabase.

## Operational consequence (do this)

Credentials that appeared in **plaintext** in a working session/transcript must be
**rotated** at the source: the `santoandre.database` Postgres password and the
`sb_secret_…` key. They currently live in Doppler `santo-andre/dev`; rotate at Supabase and
update Doppler. The package model makes rotation cheap — packages reference Doppler, so no
package changes when keys rotate.
