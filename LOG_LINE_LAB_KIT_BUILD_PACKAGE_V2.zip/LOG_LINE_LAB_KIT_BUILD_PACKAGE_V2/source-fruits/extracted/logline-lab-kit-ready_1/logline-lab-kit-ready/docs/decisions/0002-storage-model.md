# ADR-0002 — Storage model: local SQL ledger + outbox + Supabase queue/spine

> Closes the open ghost `storage-model-reconciliation` (see `docs/inventory/LAB-KIT-main.md`).
> Lab practice, not Foundation canon.

## Status

DECIDED — 2026-05-29.

## Decision

There is no single store. There are four roles with one truth gradient:

```txt
local truth  = local SQL ledger        (high-throughput ingest, low latency, WAL)
queue truth  = pending consequences    (local outbox -> Supabase queues)
remote truth = ops.logline_acts        (the durable spine + derived projections)
file truth   = none                    (spool/cache/export only; dies in 24h)
```

Flow:

```txt
1. act arrives
2. write to local_sql.logline_acts
3. write event to local_sql.outbox (same transaction)
4. outbox sync pushes to Supabase q_lab_outbox (idempotency keys)
5. Supabase writes/validates ops.logline_acts
6. consequences enqueue: q_workorders / q_receipts / q_projection_rebuild
7. worker processes
8. success -> receipt
9. transient failure -> bounded retry
10. semantic failure -> ghost + dead_letter
11. temp artifacts -> q_artifact_cleanup
12. cleanup deletes files older than 24h
```

## Hard rules

- No file as the local truth mode.
- No async effect outside the queue.
- No silent drop (outbox guarantees delivery).
- No infinite retry (retries are bounded; exhaustion -> dead_letter + ghost).
- No release while a ghost blocks proof.
- No artifact older than 24h (TTL = 86 400 s, hardcoded).

## Crate decomposition

```txt
crates/logline-lab-local-sql   local SQLite (WAL): logline_acts, receipts, ghosts, artifacts, outbox
crates/logline-lab-outbox      reads local outbox, pushes to Supabase, idempotency + retry state
crates/logline-lab-supabase    migrations, ops.logline_acts, pgmq queues, pg_cron cleanup, dead letters
crates/logline-lab-labd        HTTP/API surface; writes to local SQL or Supabase, never files-as-truth
crates/logline-lab-artifacts   temporary file spool, TTL = 86 400 s hardcoded
```

## Local engine choice

Local SQL = **SQLite in WAL mode** (`rusqlite`, `bundled` feature), reversible Lab-practice default:
no server to run, embeddable, testable in CI, matches the "high-throughput + WAL" requirement.
Local-Postgres remains an option behind the same `LocalLedger` interface if a deployment needs it.

## Consequence for the existing base

`logline-lab-core::FileLabStore` (per-type JSON files) is **demoted**: it is no longer a truth
store. It survives only as a transitional convenience for the current CLI and will be migrated onto
`logline-lab-local-sql`. Recorded as follow-up ghost `filelabstore-demotion`.
