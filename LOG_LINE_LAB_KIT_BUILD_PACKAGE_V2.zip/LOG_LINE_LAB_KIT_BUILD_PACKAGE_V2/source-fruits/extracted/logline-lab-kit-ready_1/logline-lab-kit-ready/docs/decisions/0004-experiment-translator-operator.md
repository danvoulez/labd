# ADR-0004 — Experiment model, Translator, Operator

## Status

Framework Accepted — 2026-05-29. Several sub-decisions OPEN (below). Lab practice.

## Core insight

An **Experiment is the Ghost Record loop at macro scale.** A single act runs
`candidate → evidence → receipt | ghost` (`declared → … → verified`). An experiment is the
same shape one level up:

```
hypothesis → loop (acts with evidence modes) → observations → receipt | ghost
```

So the "pre-defined scientific method" is **not bolted on** — it is the same LogLine
grammar scaled up. The rigor is free; "simple" falls out because the human only fills the
brick's slots, never designs a method. The Experiment is the missing top-of-stack
primitive, sitting above the act-ledger. It is the unit of study.

## The six slots

1. **Hypothesis** — what we're testing (the experiment's `did`). Must be neutralized of
   the desired conclusion before freezing.
2. **Canon** — the mechanism/intervention under study + the invariants that stay fixed.
3. **Hooks** — the knobs the loop may turn.
4. **Loop dynamics** — what changes each iteration; `if_ok` / `if_doubt` / `if_not`. This
   is the decision slot and the **bridge** between authored and computed.
5. **Clock** — cadence on lab-schedule; the 24/7 distribution.
6. **Substrate / scale** — which real machine/package the Operator acts on.

### Declared vs Derived (this is what keeps it simple)

- **Declared** (the human authors): Hypothesis, Canon, Hooks.
- **Derived** (the Translator computes): Clock (from statistical power = effect size ÷
  noise ÷ data-rate) and Substrate/scale (from implied load = loops × cadence ×
  concurrency × act-volume).
- Slot 4 bridges: it consumes the derivation.

The human configures ~three things; the Translator computes the rest. That is the
"lose 5 minutes, get an elite method" promise, kept honest by construction.

## Roles

- **Translator** — freezes fuzzy intention into professional LogLine structure. It must:
  de-bias the question, force a testable claim, freeze canon, identify hooks, derive clock
  and substrate, refuse vague closure, and judge two fitnesses:
  - **Primitive fitness** — are we using the LogLine brick correctly? (canonical failure:
    a spreadsheet treated as a ledger).
  - **Infra fitness** — does the ground support the ambition? **Bidirectional**: Mars on a
    Mac mini is an under-provisioning ghost; the SpaceX package for a toy test is an
    over-provisioning ghost. The infra verdict is **derived** from Slots 1–5, not guessed.
- **Operator** — runs the real machine. It does not imagine results. The Operator is what
  separates the system from a crystal ball; the receipts are the proof the confidence was
  earned.

## Hello-world (public)

Not "emit an act" (too technical). It is:

> Bring one question from your own field. Freeze it into an experiment. Watch one loop run.
> See what becomes evidence, ghost, or receipt.

## Why an LLM gets confident-and-right about LogLine (the thesis)

LogLine hands the model a typed, append-only, receipt-bearing world where every claim must
land as act / evidence / receipt or it ghosts. The model physically cannot produce plastic
closure without the structure exposing it. The confidence is earned by the substrate, not
performed. **LogLine lets an LLM stop pretending.**

## OPEN sub-decisions (not closed — do not pretend otherwise)

- **Baseline / control** (upstream; blocks the v0.1 spec): is the intervention-under-test a
  *toggle-internal* baseline (interleaved on/off loops — clean control, but violates
  "always through the ledger" if that's canon) or *external/historical* (preserves canon,
  noisier comparison)? The walkthrough proved the six slots have **no explicit baseline
  concept** — this is a missing slot/rule, not a clarification.
- Is the intervention-under-test always a **hook** (leaning yes)?
- Is six slots right, or does the Canon↔Hooks boundary need splitting?
- Is infra-fitness the Translator's judgment, or a small **capacity function** it calls
  (the latter is more receipt-able)?
- Exact derivation formulas for Clock (statistical power) and Substrate (implied load).

## Validation status

The "drop my LLM-coder costs" walkthrough was run by hand as a design probe (a Claim's
probe, not a runtime receipt). The frame held but bent in three places (bias in the
question; mechanism-vs-effect split between Canon and Hypothesis; missing baseline/control).
Bending-revealed-simpler is the opposite of plastic. Three amendments pending the baseline
decision before the Translator system prompt is written.
