# ADR-0001 — Rust-first LogLine Lab Kit

## Decision

The LogLine Lab Kit is Rust-first.

The critical implementation path is Rust crates and Rust binaries:

```txt
logline-lab-core
logline-lab-hermes
logline-lab-clock
logline-lab-cli
```

Non-Rust material may exist only as canonical source, conformance vector, historical note, template, or adapter reference.

## Reason

The uploaded canonical repos already contain Rust engines and Rust constitutional runtime machinery. The Lab Kit should assemble those engines instead of inventing a parallel runtime.

## Consequence

- `engine` is vendored and used for receipt hashing / canonical receipt behavior.
- `constitutional-runtime` is vendored and used for admission.
- Hermes starts as a Rust trait and dry-run runner.
- The Lab clock starts as a Rust binary.
- JS tooling in conformance remains upstream reference material, not the Lab runtime.

## Non-goal

This does not claim Rust is required for every possible LogLine Lab. It says this distribution is Rust-first because the current canonical engines in the zip are Rust and the user required Rust for this build.
