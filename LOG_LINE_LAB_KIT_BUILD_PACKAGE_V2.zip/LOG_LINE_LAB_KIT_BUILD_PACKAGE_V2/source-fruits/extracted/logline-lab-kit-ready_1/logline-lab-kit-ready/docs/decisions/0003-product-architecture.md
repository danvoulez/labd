# ADR-0003 — Product architecture: engine · canon · packages

## Status

Accepted — 2026-05-29. Lab practice.

## Decision

LogLine Lab is a **three-layer** product, installed like Claude Code (one command),
with opinion pushed strictly outward into packages.

1. **Engine** (`logline-lab`, the binary). Domain-agnostic and unopinionated. It knows
   acts, ledger semantics, the lifecycle (admission → evidence → receipt → ghost), the
   profile abstraction, and nothing else. It knows nothing about Santo André, Supabase,
   pgmq, thresholds, or any domain doctrine. This is the constitution — the invariants
   that cannot be forked.

2. **Bootstrap** (`logline-lab init`). Turns an empty directory into a valid, running,
   empty lab. **SQLite-first**, zero infra, works the moment it's installed (like `claude`
   working on first run). Writes the lab manifest, core schema, default profile.

3. **Packages**. The "open to add stuff" layer, and the **only** place opinion is allowed
   to live. A package carries: schema extensions, registry seed data, a chosen profile +
   its config, golden config values (thresholds, evidence policies), conformance tests,
   and **references to secrets — never secrets** (see ADR-0005).

## Two orthogonal axes (must stay separate)

- **Profile** answers *"what backend / capability?"* — local SQLite, Postgres, Supabase,
  AWS. A capability choice (ledger, queue, projections).
- **Package** answers *"what doctrine / domain / opinion?"* — Santo André, AWS package,
  SpaceX package, legal-contract package.

A package may *select and configure* a profile, but vendor specifics (pgmq, pg_cron, edge
functions, RLS, realtime) **never leak down into the engine**. They live in the package's
profile bundle, opt-in by construction.

## Scale is something you load, never something you rebuild

The same primitive grammar and the same commands run from a Mac mini to Mars. Only the
package/profile under them changes. Scale is loaded, not rebuilt.

## Consequences

- The Supabase migrations built this week (incl. `0013` pgmq/pg_cron) belong in the
  **`santo-andre` package**, not in core. Core ships only the portable floor (SQLite +
  generic Postgres).
- **Santo André is the reference/golden package, not a fork** (supersedes the earlier
  "instance via profile" framing). It is both the production lab and the kit's flagship
  example.
- **Flagship reproducibility milestone:** `logline-lab init && logline-lab add santo-andre
  && logline-lab up` reproduces the spine currently stood up by hand. Until that works,
  Santo André is hand-built, not kit-built — a claim, not a fact.

## Open (not decided here)

- Package format + distribution (git URL / registry / local path) — deliberately deferred;
  let the real Santo André package pull the format out rather than designing it abstractly.
- Tier-0 (SQLite) queue semantics — pgmq is Supabase-only, SKIP-LOCKED is generic Postgres,
  SQLite has neither. The local "queue" is likely a single-process polling/outbox table,
  named honestly as the local profile's implementation (not pretended to be pgmq).
