# Build Guide

## Expected build

```bash
cargo fmt --all
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
cargo run -p logline-lab-cli -- --help
```

## First local run

The CLI takes `path`, `who`, `did`, `this`, `status` as **positional** arguments
(the consequence slots are flags). Verified against the built binary on 2026-05-30.

```bash
cargo run -p logline-lab-cli -- init lab-home santo-andre dan
cargo run -p logline-lab-cli -- emit-act lab-home dan declare_lab santo-andre observed \
  --confirmed-by manual --if-ok project_manifest --if-doubt open_ghost --if-not reject
cargo run -p logline-lab-cli -- clock-tick lab-home --lab-id santo-andre
cargo run -p logline-lab-cli -- report lab-home
```

## Verify vendored engine separately

```bash
cd vendor/logline-foundation/engine
cargo test --workspace
```

## Verify constitutional runtime separately

```bash
cd vendor/logline-foundation/constitutional-runtime
cargo test
```

## Run conformance reference suite

The upstream conformance repo currently ships a JS reference verifier. The Lab runtime is Rust-first, but the upstream suite remains a canonical source of proof vectors.

```bash
cd vendor/logline-foundation/conformance
node tools/verify-receipt.mjs --suite
```

A Rust verifier is a good next Lab target.
