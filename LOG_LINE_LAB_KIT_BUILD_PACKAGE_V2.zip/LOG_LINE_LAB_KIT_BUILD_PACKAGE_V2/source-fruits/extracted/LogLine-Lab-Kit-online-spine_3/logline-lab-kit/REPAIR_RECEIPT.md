# Repair Receipt — Online Spine / No File Storage

## Input

Original user upload:

```txt
/mnt/data/Archive(1).zip
```

Working base:

```txt
lab-kit/
```

## Hard constraints applied

```txt
LogLine Act official = online SQL database.
SQLite = provisional/high-frequency/cache/outbox only.
Filesystem = not official storage.
JSON/JSONL = not official ledger.
```

## Changed

```txt
README.md
  Rewritten around the actual Lab Kit context: Supabase/Postgres spine, CLI/labd, projectors, ghosts, evidence, receipts, clock, hooks, dispatch, Hermes boundary.

crates/logline-lab-cli/src/main.rs
  emit-act/init/ghost now write to online spine through SupabaseSpine.
  workorder/hermes/clock print JSON to stdout, not file storage.
  seal-receipt no longer writes output files.
  report reads online spine.
  SQLite commands are labeled provisional cache/outbox only.

crates/logline-lab-core/src/lib.rs
crates/logline-lab-core/src/storage.rs
  Removed FileLabStore from public core and removed the file-store implementation.

crates/logline-lab-clock/src/main.rs
  Removed file write; prints clock tick JSON to stdout.

crates/logline-lab-supabase/src/lib.rs
  Removed NoCertVerify/TLS-disabled path.
  Requires DATABASE_URL and LOGLINE_LAB_SUPABASE_CA_CERT.

crates/logline-lab-local-sql/src/lib.rs
  Reworded from local truth/ledger to provisional SQLite cache/outbox.
  Removed artifacts table / artifact TTL from local SQLite schema.

ops/supabase/README.md
  Rewritten as online SQL spine docs.

templates/lab_manifest.json
examples/santo-andre/lab_manifest.json
templates/projector_definition.json
templates/probe.json
  Removed filesystem/JSON storage semantics; points to online spine/projections.

docs/guides/BUILD.md
docs/guides/BUILD_STATUS.md
docs/guides/CLOCK.md
docs/spec/LOG_LINE_LAB_KIT_PROJECT.md
  Added explicit storage boundary.
```

## Removed from installable package

```txt
.claude/
sources/
_inbox/
target/
__MACOSX/
.DS_Store
KIT_MANIFEST.json
docs/decisions/
docs/inventory/
crates/logline-lab-artifacts/
lab-home/
```

## Not claimed

This environment has no cargo/rustc. Therefore this package is not claimed as compiled/tested/green.

```txt
runtime verified here: no
cargo check here: no
cargo test here: no
```

## Required next probes in Rust environment

```bash
cargo fmt --check
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --workspace
```
