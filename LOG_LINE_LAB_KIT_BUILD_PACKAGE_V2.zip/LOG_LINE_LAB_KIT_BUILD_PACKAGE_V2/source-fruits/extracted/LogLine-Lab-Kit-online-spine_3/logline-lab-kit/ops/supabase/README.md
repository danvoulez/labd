# Online SQL spine

Official LogLine Act persistence for the Lab Kit is the online SQL/Postgres/Supabase spine:

```txt
ops.logline_acts
```

Everything else (`evidence.*`, `receipts.*`, `workorders.*`, `registry.*`, `audit.*`, `lab_observability.*`) is a derived projection, registry, queue, view, or operational surface.

## Migrations

```txt
0001_ops_logline_acts.sql              base act spine
0002_registry.sql                      registry projections
0003_audit_views.sql                   audit views
0004_lab_observability.sql             observability projections
0005_evidence.sql                      evidence projections
0006_receipts.sql                      receipt projections
0007_workorders.sql                    workorder projections
0008_authz.sql                         authz surfaces
0009_functions_projectors.sql          projector functions
0010_rls_safe_reads.sql                safe read policies
0011_ingest_idempotent_immutable.sql   append-only + audited ingest boundary
0012_dead_letters.sql                  bounded failure / no silent drop
0013_queues_pgmq.sql                   queue layer, requires Supabase extensions
```

## Hard storage boundary

```txt
LogLine Acts official: ops.logline_acts online.
SQLite: provisional/high-frequency/cache/outbox only.
Filesystem/JSON/JSONL: not official storage.
```

`ops.ingest_logline_act(jsonb)` is the sanctioned ingest boundary for semantic writes.
