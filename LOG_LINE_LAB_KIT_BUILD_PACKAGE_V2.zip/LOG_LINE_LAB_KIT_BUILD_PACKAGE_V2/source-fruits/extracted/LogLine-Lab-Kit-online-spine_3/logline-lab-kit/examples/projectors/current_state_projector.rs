//! Minimal example projector sketch.
//! This is intentionally not wired into the core crate yet.
//! It shows the correct posture: projection renders state and preserves source refs.

use serde::Serialize;

#[derive(Debug, Serialize)]
struct CurrentStateProjection<'a> {
    projection_id: &'a str,
    generated_at: &'a str,
    source_refs: Vec<&'a str>,
    claim_limits: &'a str,
    open_ghosts: Vec<&'a str>,
}

fn main() {
    let projection = CurrentStateProjection {
        projection_id: "current_state.example",
        generated_at: "2026-05-28T00:00:00Z",
        source_refs: vec!["online_spine:ops.logline_acts", "projection:lab_observability.ghosts", "projection:receipts.*"],
        claim_limits: "projection only; not canon; not proof; not closure",
        open_ghosts: vec!["cargo-runtime-unavailable-in-current-environment"],
    };
    println!("{}", serde_json::to_string_pretty(&projection).unwrap());
}
