# LogLine Lab Kit — Project Formalization

This document formalizes only the project scope already present in the Lab Kit context.

## Product

The LogLine Lab Kit is the installable operational kit for instantiating a real LogLine Lab.

It provides: canon loader, online act spine, CLI, labd, manifest, runtime registry, projectors, ghost registry, evidence registry, receipt preparation, lab clock, mandatory hooks, dispatch/workorder boundary, reports, conformance hooks, and study benches.

## Hard database rule

```txt
LogLine Acts go to the online SQL spine.
The spine is ops.logline_acts.
SQLite is provisional/high-frequency/cache/outbox only.
Filesystem and JSON/JSONL are not official storage.
```

## Non-product material

Transcripts, agent settings, inbox/fusion material, build artifacts, and inventories are not part of the installable product.

## Non-goals v0

No frontend requirement, no full Hermes apply mode, no full passkey windows, no multi-user SaaS, no arbitrary DB adapters, no complete public deployment, and no LLM provider assumption.
