# Clock

The Lab clock can emit a tick object. The clock itself is not authority and does not close receipts.

In this repaired package, clock commands print JSON to stdout. Official persistence of a clock tick requires emitting a LogLine Act to the online SQL spine:

```txt
ops.logline_acts
```

No clock output is official when stored in filesystem/JSON/JSONL.
