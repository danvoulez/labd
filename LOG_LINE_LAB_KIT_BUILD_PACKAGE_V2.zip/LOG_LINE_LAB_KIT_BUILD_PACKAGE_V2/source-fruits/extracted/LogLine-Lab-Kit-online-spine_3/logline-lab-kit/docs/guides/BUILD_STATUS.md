# Build Status

This package was repaired in an environment where Rust/Cargo execution was not available.

Do not claim:

```txt
compiled
tested
green
validated
ready
```

without running the probes in a Rust environment.

## Required probes

```bash
cargo fmt --check
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --workspace
```

## Storage/consequence boundary

Official LogLine Acts must be written to the online SQL spine:

```txt
ops.logline_acts
```

SQLite is only provisional/high-frequency/cache/outbox. Filesystem/JSON/JSONL is not official storage.
