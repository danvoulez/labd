# Build Guide

## Prerequisites

```txt
Rust toolchain matching rust-toolchain.toml
DATABASE_URL for online Postgres/Supabase spine operations
LOGLINE_LAB_SUPABASE_CA_CERT pointing to a PEM CA bundle for verified TLS
```

## Build probes

```bash
cargo fmt --check
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --workspace
```

## Official storage rule

The build does not prove official state. Official semantic writes are LogLine Acts inserted into:

```txt
ops.logline_acts
```

SQLite is provisional cache/outbox only. Filesystem/JSON/JSONL is not official Lab storage.
