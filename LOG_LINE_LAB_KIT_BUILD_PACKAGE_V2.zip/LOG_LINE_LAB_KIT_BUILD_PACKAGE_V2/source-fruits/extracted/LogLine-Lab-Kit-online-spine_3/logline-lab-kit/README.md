# LogLine Lab Kit

**Status:** package repair aligned to the Lab Kit context.

**Name:** LogLine Lab Kit  
**Function:** operational kit for instantiating a real LogLine Lab  
**First target instance:** Santo André Laboratory  
**Optional UI:** minilab.work  
**Hard rule:** LogLine Acts go to the online SQL spine. Period.

This kit is not a frontend, dashboard, transcript, ChatGPT project, Claude plan, or minilab.work. It is the installable operational kit for a LogLine Lab.

## Non-negotiable storage rule

```txt
Official semantic write: ops.logline_acts in online SQL/Postgres/Supabase.
SQLite: provisional/high-frequency cache/outbox only.
Filesystem: no official storage.
JSON/JSONL: no official ledger.
```

Forbidden as official Lab storage:

```txt
local JSON ledger
filesystem current-state ledger
frontend store as operational source
mock state promoted to truth
direct semantic writes into projection tables
receipt without evidence
runtime success as closure
```

## What the kit provides

```txt
canon loader
Supabase/Postgres act spine
CLI
labd
manifest
runtime registry
projectors
ghost registry
evidence registry
receipt preparation
lab clock
mandatory hooks
process/dispatch contracts
Hermes workorder boundary
report generation
conformance hooks
study benches
```

## Layer boundary

```txt
LogLine Foundation = grammar / canon
LogLine Lab Kit   = operational kit
Lab Instance      = Santo André Laboratory or another local lab
Local Overlay     = Dan/minilab.work/policy/machines/identity/UX
Frontend          = optional cockpit only
```

The Lab Kit must run without frontend. `minilab.work` may consume the kit; it is not the kit.

## Current Rust package shape

This package is Rust-first in the uploaded archive. The implementation has been repaired so that official act emission goes to the online spine:

```txt
crates/logline-lab-cli        CLI
crates/logline-lab-supabase   online SQL spine driver
crates/logline-lab-labd       API surface
crates/logline-lab-local-sql  provisional SQLite cache/outbox only
crates/logline-lab-outbox     provisional cache -> online spine sync
crates/logline-lab-core       primitives, no file store export
crates/logline-lab-hermes     dry-run execution boundary
crates/logline-lab-clock      clock tick producer to stdout
ops/supabase/migrations       online schema / projections / ingest boundary
```

## Online spine

The spine is:

```txt
ops.logline_acts
```

The schema lives in:

```txt
ops/supabase/migrations/0001_ops_logline_acts.sql
ops/supabase/migrations/0011_ingest_idempotent_immutable.sql
```

`ops.ingest_logline_act(jsonb)` is the sanctioned online ingest boundary.

## CLI examples

These commands require:

```txt
DATABASE_URL
LOGLINE_LAB_SUPABASE_CA_CERT
```

`LOGLINE_LAB_SUPABASE_CA_CERT` must point to a PEM CA bundle. TLS verification is required; no `NoCertVerify` path remains in the Supabase driver.

```bash
cargo run -p logline-lab-cli -- report .

cargo run -p logline-lab-cli -- init . santo-andre-laboratory dan

cargo run -p logline-lab-cli -- emit-act . dan instantiate_logline_lab santo-andre-laboratory \
  --confirmed-by operator:dan \
  --if-ok project_registry_and_observability \
  --if-doubt open_lab_instantiation_ghost \
  --if-not reject_invalid_lab_instantiation \
  declared
```

`workorder`, `hermes-dry-run`, and `clock-tick` print JSON to stdout. They do not write official files.

## Provisional SQLite cache/outbox

SQLite is allowed only for provisional/high-frequency cache/outbox. It is not official act storage.

```bash
cargo run -p logline-lab-cli -- outbox .
cargo run -p logline-lab-cli -- sync .
```

Any row in the provisional SQLite cache must be delivered to `ops.logline_acts` before it can be treated as official.

## Acceptance criteria from the context

The Lab Kit v0 is acceptable when:

```txt
1. logline-lab init runs.
2. Supabase migrations create ops.logline_acts.
3. No semantic write goes anywhere except ops.logline_acts.
4. At least one Lab instance is registered by LogLine Act.
5. At least one ghost is opened by LogLine Act.
6. audit.v_mobile_today or equivalent reads a real Supabase projection.
7. logline-lab status/report returns state from Supabase.
8. logline-lab ghost list returns projected ghosts.
9. logline-lab act emit inserts a nine-slot act.
10. doctor detects missing schemas/projections.
11. Receipts do not close without evidence refs.
12. Hermes workorders do not exist without dispatch/admission boundary.
13. Frontends are optional.
14. minilab.work can consume the kit, but is not the kit.
```

## Verification state of this repaired package

This package was edited in an environment without Rust/Cargo execution. Therefore:

```txt
packaged: yes
runtime-verified: no
compiled here: no
tested here: no
```

Do not call this package compiled, tested, green, or ready without running the probes in a Rust environment.

## Signature

```txt
We Trust and Build with LogLine.
```
