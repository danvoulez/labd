//! v0.2 end-to-end lab flow over the **decided** storage model (ADR-0002):
//!
//! ```txt
//! act  ->  canonical receipt hashes  ->  provisional SQLite cache/outbox  ->  outbox  ->  report
//! ```
//!
//! This deliberately stops at the local boundary. It does NOT fake a receipt or
//! remote confirmation, because under ADR-0002 those are *remote consequences*
//! produced by the Supabase queue worker — not something the provisional SQLite cache may
//! claim. The test asserts both that the flow happened and that no broad claim
//! was made (step 12 of the plan's lab_flow: "assert no broad claim was made").
//!
//! Lives in `logline-lab-outbox` because that crate sits atop `logline-lab-local-sql`
//! and can pull the whole local chain (the workspace root is virtual, so it can't
//! host a `tests/` dir of its own).

use logline_lab_core::LogLineAct;
use logline_lab_local_sql::{ActRow, LocalLedger};
use logline_lab_outbox::OutboxSync;

#[test]
fn act_to_cache_to_outbox_to_report() {
    let dir = tempfile::tempdir().unwrap();
    let cache = LocalLedger::open(dir.path().join("lab.db")).unwrap();

    // 1. An act arrives, sealed with canonical LogLine hashes (engine/conformance path).
    let act = LogLineAct::new(
        "dan",
        "declare_lab",
        "santo-andre",
        "2026-05-29T00:00:00Z",
        "manual",
        "project_manifest",
        "open_ghost",
        "reject",
        "observed",
    );
    let receipt = act.to_receipt().expect("act seals into a receipt");
    assert!(
        receipt.verify().expect("receipt verifies"),
        "canonical receipt must verify before it touches the cache"
    );

    // 2. Write to the provisional SQLite cache; the row carries the canonical hashes.
    let row = ActRow {
        id: receipt.id.clone(),
        who: act.who.clone(),
        did: act.did.clone(),
        this: act.this.clone(),
        when_ts: act.when.clone(),
        confirmed_by: act.confirmed_by.clone(),
        if_ok: act.if_ok.clone(),
        if_doubt: act.if_doubt.clone(),
        if_not: act.if_not.clone(),
        status: act.status.clone(),
        tuple_hash: Some(receipt.hashes.tuple_hash.clone()),
        content_hash: Some(receipt.hashes.content_hash.clone()),
    };
    let entry = cache.append_act(&row).expect("append act + outbox");

    // 3. Append produced exactly one pending outbox event keyed by the act id.
    assert_eq!(entry.status, "pending");
    assert_eq!(entry.ref_id, receipt.id);
    assert_eq!(cache.act_count().unwrap(), 1);
    assert_eq!(cache.pending_outbox(10).unwrap().len(), 1);

    // 4. Local-only flow: the act is awaiting delivery in the outbox. We do NOT
    //    ship here (no Supabase in a unit test) — shipping is covered by the
    //    Doppler-gated `sync` path. Just confirm exactly one pending entry.
    assert_eq!(
        OutboxSync::pending_count(&cache).expect("count pending"),
        1,
        "the one act is still awaiting delivery"
    );

    // 5. The report reflects local state — and only local state.
    let report = cache.report().expect("project local lab state");
    assert_eq!(report.acts, 1);
    assert_eq!(report.outbox_pending, 1);
    assert_eq!(report.outbox_synced, 0);

    // 6. No broad claim (plan step 12): the act exists locally, but the report
    //    must NOT claim remote confirmation, and there is NO receipt yet (a
    //    receipt is a remote consequence under ADR-0002, not a local artifact).
    assert!(
        !report.remote_confirmed,
        "provisional SQLite cache may not claim online spine truth"
    );
    assert_eq!(
        report.receipts, 0,
        "no receipt may exist before the consequence is processed"
    );
    assert!(
        report.claim_limits.contains("not remote-confirmed")
            && report.claim_limits.contains("not a receipt"),
        "the report must state its own scope limits, got: {}",
        report.claim_limits
    );
}
