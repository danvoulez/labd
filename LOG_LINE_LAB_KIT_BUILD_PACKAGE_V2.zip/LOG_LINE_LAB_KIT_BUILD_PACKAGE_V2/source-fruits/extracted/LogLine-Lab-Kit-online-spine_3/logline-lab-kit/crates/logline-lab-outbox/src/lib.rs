#![forbid(unsafe_code)]

//! Outbox sync (ADR-0002): drain the local outbox into the Supabase spine.
//!
//! Each pending local act is pushed through `ops.ingest_logline_act` (idempotent
//! on content_hash). On success the local outbox entry is marked synced; on
//! failure it is left pending for a later pass (bounded retry / dead-letter is the
//! next refinement). No silent drop: a failed entry stays pending and counted.

use logline_lab_local_sql::{ActRow, LedgerError, LocalLedger};
use logline_lab_supabase::{BoxErr, SupabaseSpine};
use serde_json::json;

/// Maximum delivery attempts before an entry is dead-lettered + ghosted.
/// ADR-0002 hard rule: no infinite retry.
pub const MAX_RETRIES: i64 = 8;

/// Result of a drain pass.
#[derive(Debug)]
pub struct DrainReport {
    pub pending: usize,
    pub shipped: usize,
    pub failed: usize,
}

pub struct OutboxSync;

impl OutboxSync {
    /// Inspect pending outbox entries without shipping (kept for diagnostics).
    pub fn pending_count(ledger: &LocalLedger) -> Result<usize, LedgerError> {
        Ok(ledger.pending_outbox(10_000)?.len())
    }

    /// Drain up to `max` pending entries into the remote spine.
    pub fn drain(
        ledger: &LocalLedger,
        spine: &mut SupabaseSpine,
        max: usize,
    ) -> Result<DrainReport, BoxErr> {
        let pending = ledger.pending_outbox(max)?;
        let mut shipped = 0usize;
        let mut failed = 0usize;

        for entry in &pending {
            // The outbox payload is the serialized ActRow. Map it to the jsonb shape
            // `ingest_logline_act` expects (note the `when_ts` -> `when` slot rename).
            let act: ActRow = serde_json::from_str(&entry.payload)?;
            let payload = json!({
                "who": act.who,
                "did": act.did,
                "this": act.this,
                "when": act.when_ts,
                "confirmed_by": act.confirmed_by,
                "if_ok": act.if_ok,
                "if_doubt": act.if_doubt,
                "if_not": act.if_not,
                "status": act.status,
                "tuple_hash": act.tuple_hash,
                "content_hash": act.content_hash,
            });

            match spine.ingest_act(&payload) {
                Ok(_id) => {
                    ledger.mark_synced(entry.seq)?;
                    shipped += 1;
                }
                Err(_e) => {
                    // Left pending — no silent drop. Bounded-retry + dead_letter next.
                    failed += 1;
                }
            }
        }

        Ok(DrainReport {
            pending: pending.len(),
            shipped,
            failed,
        })
    }
}
