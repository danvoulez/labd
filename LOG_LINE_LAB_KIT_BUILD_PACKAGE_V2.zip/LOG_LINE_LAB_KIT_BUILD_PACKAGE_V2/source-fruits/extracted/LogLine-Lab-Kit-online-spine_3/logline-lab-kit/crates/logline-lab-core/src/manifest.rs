use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LabPublicStatus {
    Private,
    Public,
    Mixed,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct LabManifestLoads {
    pub foundation: String,
    #[serde(default)]
    pub practice_profiles: Vec<String>,
    pub local_overlay: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct LabManifestPrimitives {
    pub runtime_envelope_required: bool,
    pub content_addressing_required: bool,
    pub ghost_policy: String,
    pub receipt_policy: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct LabManifest {
    pub manifest_version: u32,
    pub name: String,
    pub steward: String,
    pub purpose: String,
    pub public_status: LabPublicStatus,
    pub loads: LabManifestLoads,
    pub primitives: LabManifestPrimitives,
    #[serde(default)]
    pub runtimes: Vec<String>,
    #[serde(default)]
    pub projectors: Vec<String>,
    #[serde(default)]
    pub clocks: Vec<String>,
    #[serde(default)]
    pub evidence_paths: Vec<String>,
    #[serde(default)]
    pub proof_paths: Vec<String>,
    pub ghost_registry: String,
    pub receipt_registry: String,
    #[serde(default)]
    pub allowed_tools: Vec<String>,
    #[serde(default)]
    pub forbidden_actions: Vec<String>,
}

impl LabManifest {
    pub fn minimal(name: impl Into<String>, steward: impl Into<String>) -> Self {
        let name = name.into();
        Self {
            manifest_version: 1,
            name: name.clone(),
            steward: steward.into(),
            purpose: "Study LogLine in motion and build with LogLine under real conditions."
                .to_string(),
            public_status: LabPublicStatus::Private,
            loads: LabManifestLoads {
                foundation: "vendor/logline-foundation".to_string(),
                practice_profiles: vec![
                    "docs/canon/logline-lab-definition-and-primitives.md".to_string()
                ],
                local_overlay: format!("{} local practice", name),
            },
            primitives: LabManifestPrimitives {
                runtime_envelope_required: true,
                content_addressing_required: true,
                ghost_policy: "preserve_missing_truth".to_string(),
                receipt_policy: "scoped_closure_only".to_string(),
            },
            runtimes: vec![
                "logline-engine-rs".to_string(),
                "constitutional-runtime-rs".to_string(),
            ],
            projectors: vec![
                "current_state".to_string(),
                "ghost_registry".to_string(),
                "evidence_registry".to_string(),
            ],
            clocks: vec!["manual".to_string()],
            evidence_paths: vec!["online_spine:ops.logline_acts -> evidence.records projection".to_string()],
            proof_paths: vec![
                "receipt_review".to_string(),
                "conformance_suite".to_string(),
            ],
            ghost_registry: "projection:lab_observability.ghosts".to_string(),
            receipt_registry: "projection:receipts.*".to_string(),
            allowed_tools: vec!["cargo".to_string(), "logline-lab-cli".to_string()],
            forbidden_actions: vec![
                "claim_local_practice_as_foundation_canon".to_string(),
                "call_model_output_evidence".to_string(),
            ],
        }
    }
}
