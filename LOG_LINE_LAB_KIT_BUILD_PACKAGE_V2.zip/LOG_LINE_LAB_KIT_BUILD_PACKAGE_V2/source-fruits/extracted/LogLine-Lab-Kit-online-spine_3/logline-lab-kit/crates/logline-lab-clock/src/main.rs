#![forbid(unsafe_code)]

use logline_lab_core::ClockTick;
use serde_json::json;

fn main() -> anyhow::Result<()> {
    let lab_id = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "local-lab".to_string());
    let tick = ClockTick::manual(lab_id, "manual");
    println!(
        "{}",
        serde_json::to_string_pretty(&json!({
            "clock_tick": tick,
            "storage": "stdout only; official persistence requires ops.logline_acts"
        }))?
    );
    Ok(())
}
