//! CLI online-spine smoke tests.
//!
//! These tests require a real DATABASE_URL and LOGLINE_LAB_SUPABASE_CA_CERT.
//! Without those env vars they are skipped, because the CLI must not fake online
//! act storage through SQLite/files/JSON.

use std::process::Command;

const BIN: &str = env!("CARGO_BIN_EXE_logline-lab");

fn have_online_env() -> bool {
    std::env::var("DATABASE_URL").is_ok()
        && std::env::var("LOGLINE_LAB_SUPABASE_CA_CERT").is_ok()
}

#[test]
fn cli_report_requires_online_spine_or_skips() {
    if !have_online_env() {
        eprintln!("skipping online-spine CLI test: DATABASE_URL/LOGLINE_LAB_SUPABASE_CA_CERT not set");
        return;
    }
    let out = Command::new(BIN)
        .args(["report", "."])
        .output()
        .expect("spawn logline-lab");
    assert!(
        out.status.success(),
        "report failed: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    let stdout = String::from_utf8(out.stdout).expect("utf8 stdout");
    assert!(stdout.contains("ops.logline_acts"), "report must name the online spine: {stdout}");
}
