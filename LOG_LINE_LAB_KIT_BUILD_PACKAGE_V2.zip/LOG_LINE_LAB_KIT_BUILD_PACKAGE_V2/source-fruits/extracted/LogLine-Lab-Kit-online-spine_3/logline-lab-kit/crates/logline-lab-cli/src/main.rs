#![forbid(unsafe_code)]

use anyhow::Context;
use clap::{Parser, Subcommand};
use constitutional_runtime::AdmissionContext;
use logline_lab_core::{
    admit_lab_act, now_rfc3339, seal_receipt_value, verify_receipt_value, ClockTick,
    DispatchPacket, DispatchPacketType, GhostRecord, GhostStatus, HermesMode, HermesWorkorder,
    LogLineAct,
};
use logline_lab_hermes::{DryRunHermes, HermesRunner};
use logline_lab_local_sql::LocalLedger;
use logline_lab_outbox::OutboxSync;
use logline_lab_supabase::SupabaseSpine;
use serde_json::json;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Parser)]
#[command(name = "logline-lab")]
#[command(about = "LogLine Lab Kit CLI — official semantic writes go to the online SQL spine")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Register a Lab instance in the online spine. Does not create file storage.
    Init {
        /// Reserved local working directory argument retained for compatibility; no official storage is created here.
        path: PathBuf,
        name: String,
        steward: String,
    },
    /// Emit a LogLine Act directly into ops.logline_acts through the online spine.
    EmitAct {
        /// Reserved local working directory argument retained for compatibility; act truth is online only.
        path: PathBuf,
        who: String,
        did: String,
        this: String,
        #[arg(long)]
        when: Option<String>,
        #[arg(long = "confirmed-by")]
        confirmed_by: String,
        #[arg(long = "if-ok")]
        if_ok: String,
        #[arg(long = "if-doubt")]
        if_doubt: String,
        #[arg(long = "if-not")]
        if_not: String,
        status: String,
    },
    SealReceipt {
        input: PathBuf,
        /// Disabled: use stdout redirection if you need a local artifact. File output is not official storage.
        output: Option<PathBuf>,
    },
    VerifyReceipt {
        input: PathBuf,
    },
    Admit {
        act: PathBuf,
        context: Option<PathBuf>,
    },
    /// Open a ghost by writing an open_ghost act to the online spine.
    Ghost {
        /// Reserved local working directory argument retained for compatibility; ghost truth is online only.
        path: PathBuf,
        id: String,
        missing: String,
        #[arg(long, default_value = "unscoped")]
        why: String,
        #[arg(long)]
        blocks: Vec<String>,
        #[arg(long, default_value = "dan")]
        owner: String,
        #[arg(long = "next-act", default_value = "name_next_probe")]
        next_act: String,
    },
    /// Prepare dispatch/workorder JSON to stdout. Does not store files.
    Workorder {
        /// Reserved local working directory argument retained for compatibility; no official storage is created here.
        path: PathBuf,
        id: String,
        process: String,
        #[arg(long = "target-lab")]
        target_lab: String,
        #[arg(long, value_parser = ["read_only", "dry_run", "apply"])]
        mode: String,
        objective: String,
    },
    /// Execute a dry-run workorder loaded from an input file and print the report to stdout. Does not store files.
    HermesDryRun {
        /// Reserved local working directory argument retained for compatibility; no official storage is created here.
        path: PathBuf,
        workorder: PathBuf,
    },
    /// Emit a clock tick object to stdout. Does not store files.
    ClockTick {
        /// Reserved local working directory argument retained for compatibility; no official storage is created here.
        path: PathBuf,
        #[arg(long = "lab-id", default_value = "local-lab")]
        lab_id: String,
    },
    /// Read online spine status. Does not read local storage as truth.
    Report {
        path: PathBuf,
    },
    /// Inspect provisional SQLite cache/outbox only. This is not official LogLine Act storage.
    Outbox {
        path: PathBuf,
        #[arg(long, default_value_t = 100)]
        limit: usize,
    },
    /// Drain provisional SQLite cache/outbox into the online spine. SQLite remains non-official.
    Sync {
        path: PathBuf,
        #[arg(long, default_value_t = 1000)]
        max: usize,
    },
}

fn cache_path(home: &Path) -> PathBuf {
    home.join("lab-cache.db")
}

fn spine_from_env() -> anyhow::Result<SupabaseSpine> {
    SupabaseSpine::from_env().map_err(|e| anyhow::anyhow!("online spine connect failed: {e}"))
}

fn ingest_payload(mut spine: SupabaseSpine, payload: &serde_json::Value) -> anyhow::Result<String> {
    spine.ingest_act(payload).map_err(|e| anyhow::anyhow!("online spine ingest failed: {e}"))
}

fn act_payload(act: &LogLineAct) -> anyhow::Result<serde_json::Value> {
    let receipt = act.to_receipt()?;
    Ok(json!({
        "who": act.who,
        "did": act.did,
        "this": act.this,
        "when": act.when,
        "confirmed_by": act.confirmed_by,
        "if_ok": act.if_ok,
        "if_doubt": act.if_doubt,
        "if_not": act.if_not,
        "status": act.status,
        "tuple_hash": receipt.hashes.tuple_hash,
        "content_hash": receipt.hashes.content_hash,
        "runtime_envelope": {
            "writer": "logline-lab-cli",
            "official_spine": "ops.logline_acts",
            "local_storage": "none"
        }
    }))
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Init { path: _, name, steward } => {
            let act = LogLineAct::new(
                steward.clone(),
                "instantiate_logline_lab".to_string(),
                name.clone(),
                now_rfc3339(),
                steward,
                "project_registry_and_observability".to_string(),
                "open_lab_instantiation_ghost".to_string(),
                "reject_invalid_lab_instantiation".to_string(),
                "declared".to_string(),
            );
            let payload = act_payload(&act)?;
            let id = ingest_payload(spine_from_env()?, &payload)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "remote_act_id": id,
                    "official_spine": "ops.logline_acts",
                    "local_storage": "none",
                    "claim_limits": "init emitted one lab-instantiation act to the online SQL spine; no filesystem/JSON/SQLite official storage was created"
                }))?
            );
        }
        Commands::EmitAct { path: _, who, did, this, when, confirmed_by, if_ok, if_doubt, if_not, status } => {
            let act = LogLineAct::new(
                who,
                did,
                this,
                when.unwrap_or_else(now_rfc3339),
                confirmed_by,
                if_ok,
                if_doubt,
                if_not,
                status,
            );
            let payload = act_payload(&act)?;
            let id = ingest_payload(spine_from_env()?, &payload)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({
                    "remote_act_id": id,
                    "official_spine": "ops.logline_acts",
                    "local_storage": "none",
                    "claim_limits": "act inserted through online SQL spine; not file storage, not JSONL, not SQLite official truth"
                }))?
            );
        }
        Commands::SealReceipt { input, output } => {
            if output.is_some() {
                anyhow::bail!("file output disabled: receipt sealing prints to stdout; redirect explicitly if you want a non-official artifact");
            }
            let value: serde_json::Value = serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            let sealed = seal_receipt_value(value)?;
            println!("{}", serde_json::to_string_pretty(&sealed)?);
        }
        Commands::VerifyReceipt { input } => {
            let value: serde_json::Value = serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            println!("{}", serde_json::to_string_pretty(&json!({"valid": verify_receipt_value(&value)?}))?);
        }
        Commands::Admit { act, context } => {
            let act: LogLineAct = serde_json::from_slice(&fs::read(&act).context("read act")?)?;
            let ctx: AdmissionContext = match context {
                Some(path) => serde_json::from_slice(&fs::read(&path).context("read admission context")?)?,
                None => AdmissionContext::default(),
            };
            let admission = admit_lab_act(&act, &ctx);
            println!("{}", serde_json::to_string_pretty(&admission)?);
        }
        Commands::Ghost { path: _, id, missing, why, blocks, owner, next_act } => {
            let ghost = GhostRecord {
                ghost_id: id.clone(),
                missing,
                why_it_matters: why,
                blocks,
                owner: owner.clone(),
                next_act,
                opened_at: now_rfc3339(),
                status: GhostStatus::Open,
            };
            let payload = json!({
                "who": owner,
                "did": "open_ghost",
                "this": ghost,
                "when": now_rfc3339(),
                "confirmed_by": {"source": "logline-lab-cli"},
                "if_ok": {"project": "lab_observability.ghosts"},
                "if_doubt": {"carry": true},
                "if_not": {"reject": "ghost_without_missing_condition"},
                "status": "open",
                "runtime_envelope": {"writer": "logline-lab-cli", "official_spine": "ops.logline_acts"}
            });
            let remote_id = ingest_payload(spine_from_env()?, &payload)?;
            println!("{}", serde_json::to_string_pretty(&json!({"ghost_id": id, "remote_act_id": remote_id, "official_spine": "ops.logline_acts"}))?);
        }
        Commands::Workorder { path: _, id, process, target_lab, mode, objective } => {
            let mode = match mode.as_str() {
                "read_only" => HermesMode::ReadOnly,
                "dry_run" => HermesMode::DryRun,
                "apply" => HermesMode::Apply,
                _ => unreachable!(),
            };
            let dispatch = DispatchPacket {
                dispatch_version: "logline.dispatch.v0".to_string(),
                packet_id: format!("dispatch.{}", id),
                correlation_id: id.clone(),
                created_at: now_rfc3339(),
                created_by: "logline-lab-cli".to_string(),
                process_id: process.clone(),
                organ: "LAB".to_string(),
                office: "LAB Reporter".to_string(),
                packet_type: DispatchPacketType::Verification,
                authority_level: "read_only".to_string(),
                objective: objective.clone(),
                input_sources: vec!["online_spine:ops.logline_acts".to_string()],
                proposed_action: "prepare Hermes dry-run workorder".to_string(),
                expected_evidence: vec!["execution_report".to_string()],
                rollback_or_rectify: "none_for_dry_run".to_string(),
                required_human_check: "none_for_read_only".to_string(),
                ghosts: Vec::new(),
            };
            let workorder = HermesWorkorder {
                workorder_version: "hermes.workorder.v0".to_string(),
                workorder_id: id.clone(),
                correlation_id: id,
                source_dispatch_packet: dispatch.packet_id.clone(),
                requested_by: "logline-lab-cli".to_string(),
                target_lab,
                process_id: process,
                authority_level: "read_only".to_string(),
                mode,
                allowed_actions: vec!["observe".to_string(), "hash".to_string(), "report".to_string()],
                forbidden_actions: vec!["provider_mutation".to_string(), "db_semantic_write".to_string(), "secret_value_read".to_string()],
                inputs: vec![json!({"objective": objective})],
                expected_outputs: vec!["execution_report".to_string()],
                evidence_required: vec!["timestamp".to_string(), "redaction_status".to_string()],
                artifact_policy: "no_official_file_storage".to_string(),
                secret_policy: "secret_names_only_no_values".to_string(),
                timeout_seconds: 60,
                rollback_or_rectify: "not_applicable_for_dry_run".to_string(),
                receipt_profile: "none_until_evidence_review".to_string(),
            };
            println!("{}", serde_json::to_string_pretty(&json!({"dispatch": dispatch, "workorder": workorder, "storage": "stdout only; not official storage"}))?);
        }
        Commands::HermesDryRun { path: _, workorder } => {
            let workorder: HermesWorkorder = serde_json::from_slice(&fs::read(&workorder).context("read workorder")?)?;
            let report = DryRunHermes.execute(&workorder);
            println!("{}", serde_json::to_string_pretty(&json!({"execution_report": report, "storage": "stdout only; not official storage"}))?);
        }
        Commands::ClockTick { path: _, lab_id } => {
            let tick = ClockTick::manual(lab_id, "manual");
            println!("{}", serde_json::to_string_pretty(&json!({"clock_tick": tick, "storage": "stdout only; official persistence requires ops.logline_acts"}))?);
        }
        Commands::Report { path: _ } => {
            let mut spine = spine_from_env()?;
            spine.check().map_err(|e| anyhow::anyhow!("online spine check failed: {e}"))?;
            let remote_acts = spine.act_count().map_err(|e| anyhow::anyhow!("act_count failed: {e}"))?;
            println!("{}", serde_json::to_string_pretty(&json!({"official_spine": "ops.logline_acts", "remote_acts": remote_acts, "local_storage": "none"}))?);
        }
        Commands::Outbox { path, limit } => {
            let ledger = LocalLedger::open(cache_path(&path))?;
            let pending = ledger.pending_outbox(limit)?;
            println!("{}", serde_json::to_string_pretty(&json!({
                "count": pending.len(),
                "pending": pending,
                "storage_class": "provisional_sqlite_cache_outbox_only",
                "official_spine": "ops.logline_acts",
                "claim_limits": "SQLite here is not official LogLine Act storage"
            }))?);
        }
        Commands::Sync { path, max } => {
            let ledger = LocalLedger::open(cache_path(&path))?;
            let mut spine = spine_from_env()?;
            let report = OutboxSync::drain(&ledger, &mut spine, max).map_err(|e| anyhow::anyhow!("outbox drain failed: {e}"))?;
            let remote_acts = spine.act_count().map_err(|e| anyhow::anyhow!("act_count failed: {e}"))?;
            println!("{}", serde_json::to_string_pretty(&json!({
                "pending_before": report.pending,
                "shipped": report.shipped,
                "failed": report.failed,
                "remote_acts_now": remote_acts,
                "storage_class": "provisional_sqlite_cache_outbox_only",
                "official_spine": "ops.logline_acts",
                "claim_limits": "shipped acts were pushed into the online SQL spine; SQLite remains provisional cache/outbox, not truth"
            }))?);
        }
    }
    Ok(())
}
