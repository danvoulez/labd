#![forbid(unsafe_code)]

//! Provisional SQLite cache/outbox (SQLite + WAL) — the **provisional local cache** and the **outbox
//! delivery pact** of ADR-0002.
//!
//! SQLite is never official LogLine Act storage. It is permitted only as a
//! high-frequency/provisional cache and outbox for eventual delivery into the
//! online SQL spine: `ops.logline_acts`.
//!
//! This crate does not push anywhere itself — that is `logline-lab-outbox`.

use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::Path;
use time::format_description::well_known::Rfc3339;
use time::OffsetDateTime;

#[derive(Debug, thiserror::Error)]
pub enum LedgerError {
    #[error("sqlite error: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("time format error: {0}")]
    Time(#[from] time::error::Format),
}

const SCHEMA: &str = r#"
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS logline_acts (
  id           TEXT PRIMARY KEY,
  who          TEXT NOT NULL,
  did          TEXT NOT NULL,
  this         TEXT NOT NULL,
  when_ts      TEXT NOT NULL,
  confirmed_by TEXT NOT NULL,
  if_ok        TEXT NOT NULL,
  if_doubt     TEXT NOT NULL,
  if_not       TEXT NOT NULL,
  status       TEXT NOT NULL,
  tuple_hash   TEXT,
  content_hash TEXT,
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS outbox (
  seq             INTEGER PRIMARY KEY AUTOINCREMENT,
  idempotency_key TEXT NOT NULL UNIQUE,
  kind            TEXT NOT NULL,
  ref_id          TEXT NOT NULL,
  payload         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending',
  retries         INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL,
  synced_at       TEXT
);
CREATE INDEX IF NOT EXISTS outbox_status_idx ON outbox(status);

CREATE TABLE IF NOT EXISTS receipts (
  id         TEXT PRIMARY KEY,
  act_id     TEXT NOT NULL,
  payload    TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ghosts (
  ghost_id  TEXT PRIMARY KEY,
  missing   TEXT NOT NULL,
  payload   TEXT NOT NULL,
  status    TEXT NOT NULL,
  opened_at TEXT NOT NULL
);

"#;

/// A provisional cached LogLine act row (9 slots + canonical hashes).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ActRow {
    pub id: String,
    pub who: String,
    pub did: String,
    pub this: String,
    pub when_ts: String,
    pub confirmed_by: String,
    pub if_ok: String,
    pub if_doubt: String,
    pub if_not: String,
    pub status: String,
    pub tuple_hash: Option<String>,
    pub content_hash: Option<String>,
}

/// A pending (or settled) outbox event: the promise that a local act will reach
/// the remote spine.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutboxEntry {
    pub seq: i64,
    pub idempotency_key: String,
    pub kind: String,
    pub ref_id: String,
    pub payload: String,
    pub status: String,
    pub retries: i64,
}

/// A projection of provisional cache/outbox state.
///
/// This is a **local** view only. `remote_confirmed` is always `false` here:
/// the provisional cache cannot prove the remote spine (`ops.logline_acts`) accepted
/// anything — that proof lives on the other side of the outbox.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LabState {
    pub report_version: String,
    pub generated_at: String,
    pub acts: i64,
    pub outbox_pending: i64,
    pub outbox_synced: i64,
    pub outbox_dead: i64,
    pub receipts: i64,
    pub ghosts_open: i64,
    pub remote_confirmed: bool,
    pub claim_limits: String,
}

pub struct LocalLedger {
    conn: Connection,
}

impl LocalLedger {
    /// Open (creating if absent) a WAL-mode SQLite cache/outbox at `path`.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, LedgerError> {
        let conn = Connection::open(path)?;
        conn.execute_batch(SCHEMA)?;
        Ok(Self { conn })
    }

    fn now() -> Result<String, LedgerError> {
        Ok(OffsetDateTime::now_utc().format(&Rfc3339)?)
    }

    /// Append an act and its outbox event in one transaction.
    ///
    /// The act id is the idempotency key, so re-appending the same act neither
    /// duplicates the act nor the outbox event (no silent drop, no double send).
    /// Returns the outbox entry (existing or newly created).
    pub fn append_act(&self, act: &ActRow) -> Result<OutboxEntry, LedgerError> {
        let now = Self::now()?;
        let tx = self.conn.unchecked_transaction()?;
        tx.execute(
            "INSERT OR IGNORE INTO logline_acts
              (id, who, did, this, when_ts, confirmed_by, if_ok, if_doubt, if_not,
               status, tuple_hash, content_hash, created_at)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13)",
            params![
                act.id,
                act.who,
                act.did,
                act.this,
                act.when_ts,
                act.confirmed_by,
                act.if_ok,
                act.if_doubt,
                act.if_not,
                act.status,
                act.tuple_hash,
                act.content_hash,
                now
            ],
        )?;
        let payload = serde_json::to_string(act)?;
        tx.execute(
            "INSERT OR IGNORE INTO outbox (idempotency_key, kind, ref_id, payload, created_at)
             VALUES (?1, 'logline_act', ?2, ?3, ?4)",
            params![act.id, act.id, payload, now],
        )?;
        tx.commit()?;

        match self.outbox_by_key(&act.id)? {
            Some(entry) => Ok(entry),
            None => Err(LedgerError::Sqlite(rusqlite::Error::QueryReturnedNoRows)),
        }
    }

    /// Outbox events still awaiting delivery, oldest first.
    pub fn pending_outbox(&self, limit: usize) -> Result<Vec<OutboxEntry>, LedgerError> {
        let mut stmt = self.conn.prepare(
            "SELECT seq, idempotency_key, kind, ref_id, payload, status, retries
               FROM outbox WHERE status = 'pending' ORDER BY seq ASC LIMIT ?1",
        )?;
        let rows = stmt.query_map([limit as i64], map_outbox)?;
        let mut out = Vec::new();
        for row in rows {
            out.push(row?);
        }
        Ok(out)
    }

    /// Mark an outbox entry as delivered to the remote spine.
    pub fn mark_synced(&self, seq: i64) -> Result<(), LedgerError> {
        let now = Self::now()?;
        self.conn.execute(
            "UPDATE outbox SET status='synced', synced_at=?2 WHERE seq=?1",
            params![seq, now],
        )?;
        Ok(())
    }

    /// Count of acts in the provisional cache.
    pub fn act_count(&self) -> Result<i64, LedgerError> {
        Ok(self
            .conn
            .query_row("SELECT COUNT(*) FROM logline_acts", [], |row| row.get(0))?)
    }

    fn count(&self, sql: &str) -> Result<i64, LedgerError> {
        Ok(self.conn.query_row(sql, [], |row| row.get(0))?)
    }

    /// Project the current local lab state. Never claims remote confirmation.
    pub fn report(&self) -> Result<LabState, LedgerError> {
        Ok(LabState {
            report_version: "logline.lab.local_state.v0".to_string(),
            generated_at: Self::now()?,
            acts: self.count("SELECT COUNT(*) FROM logline_acts")?,
            outbox_pending: self.count("SELECT COUNT(*) FROM outbox WHERE status='pending'")?,
            outbox_synced: self.count("SELECT COUNT(*) FROM outbox WHERE status='synced'")?,
            outbox_dead: self.count("SELECT COUNT(*) FROM outbox WHERE status='dead'")?,
            receipts: self.count("SELECT COUNT(*) FROM receipts")?,
            ghosts_open: self.count("SELECT COUNT(*) FROM ghosts WHERE status='open'")?,
            remote_confirmed: false,
            claim_limits: "provisional cache projection only; pending outbox not yet \
                delivered to ops.logline_acts; not a receipt; not remote-confirmed"
                .to_string(),
        })
    }

    /// Record (or keep) a ghost in the provisional cache. Idempotent on `ghost_id`.
    /// `payload` is the full ghost document as JSON.
    pub fn record_ghost(
        &self,
        ghost_id: &str,
        missing: &str,
        payload: &str,
        status: &str,
    ) -> Result<(), LedgerError> {
        let now = Self::now()?;
        self.conn.execute(
            "INSERT OR IGNORE INTO ghosts (ghost_id, missing, payload, status, opened_at)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![ghost_id, missing, payload, status, now],
        )?;
        Ok(())
    }

    fn outbox_by_key(&self, key: &str) -> Result<Option<OutboxEntry>, LedgerError> {
        let mut stmt = self.conn.prepare(
            "SELECT seq, idempotency_key, kind, ref_id, payload, status, retries
               FROM outbox WHERE idempotency_key = ?1",
        )?;
        let mut rows = stmt.query_map([key], map_outbox)?;
        match rows.next() {
            Some(row) => Ok(Some(row?)),
            None => Ok(None),
        }
    }
}

fn map_outbox(row: &rusqlite::Row) -> rusqlite::Result<OutboxEntry> {
    Ok(OutboxEntry {
        seq: row.get(0)?,
        idempotency_key: row.get(1)?,
        kind: row.get(2)?,
        ref_id: row.get(3)?,
        payload: row.get(4)?,
        status: row.get(5)?,
        retries: row.get(6)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample(id: &str) -> ActRow {
        ActRow {
            id: id.into(),
            who: "dan".into(),
            did: "declare_lab".into(),
            this: "{}".into(),
            when_ts: "2026-05-29T00:00:00Z".into(),
            confirmed_by: "manual".into(),
            if_ok: "project_manifest".into(),
            if_doubt: "open_ghost".into(),
            if_not: "reject".into(),
            status: "observed".into(),
            tuple_hash: None,
            content_hash: None,
        }
    }

    #[test]
    fn append_writes_act_and_pending_outbox_atomically() {
        let dir = tempfile::tempdir().unwrap();
        let ledger = LocalLedger::open(dir.path().join("lab.db")).unwrap();

        let entry = ledger.append_act(&sample("act.1")).unwrap();
        assert_eq!(entry.status, "pending");
        assert_eq!(entry.kind, "logline_act");
        assert_eq!(entry.ref_id, "act.1");
        assert_eq!(ledger.act_count().unwrap(), 1);
        assert_eq!(ledger.pending_outbox(10).unwrap().len(), 1);
    }

    #[test]
    fn reappending_same_act_is_idempotent() {
        let dir = tempfile::tempdir().unwrap();
        let ledger = LocalLedger::open(dir.path().join("lab.db")).unwrap();

        ledger.append_act(&sample("act.1")).unwrap();
        ledger.append_act(&sample("act.1")).unwrap();

        assert_eq!(ledger.act_count().unwrap(), 1);
        assert_eq!(ledger.pending_outbox(10).unwrap().len(), 1);
    }

    #[test]
    fn marking_synced_clears_pending_without_dropping_row() {
        let dir = tempfile::tempdir().unwrap();
        let ledger = LocalLedger::open(dir.path().join("lab.db")).unwrap();

        let entry = ledger.append_act(&sample("act.1")).unwrap();
        ledger.mark_synced(entry.seq).unwrap();

        assert_eq!(ledger.pending_outbox(10).unwrap().len(), 0);
        // the act itself is never dropped — only the outbox state advances
        assert_eq!(ledger.act_count().unwrap(), 1);
    }
}
