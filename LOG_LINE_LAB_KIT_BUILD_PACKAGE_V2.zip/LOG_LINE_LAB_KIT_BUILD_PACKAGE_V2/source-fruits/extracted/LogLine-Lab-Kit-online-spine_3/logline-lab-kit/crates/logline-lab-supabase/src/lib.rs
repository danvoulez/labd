#![forbid(unsafe_code)]

//! Online SQL spine driver.
//!
//! Official LogLine Act persistence is `ops.logline_acts` in the online
//! Postgres/Supabase spine, through `ops.ingest_logline_act(jsonb)`. Local
//! SQLite may be used by other crates only as provisional cache/outbox; it is
//! not official storage.
//!
//! TLS is not allowed to run with disabled certificate verification. This crate
//! requires `LOGLINE_LAB_SUPABASE_CA_CERT` to point to the PEM certificate bundle
//! used to verify the Supabase/Postgres endpoint.

use base64::Engine;
use postgres::Client;
use rustls::pki_types::CertificateDer;
use rustls::{ClientConfig, RootCertStore};
use serde_json::Value;
use std::fs;
use std::path::Path;
use std::sync::Arc;

pub type BoxErr = Box<dyn std::error::Error + Send + Sync>;

/// Adopted migrations, relative to the workspace root.
pub const MIGRATIONS_DIR: &str = "ops/supabase/migrations";

pub struct SupabaseSpine {
    client: Client,
}

impl SupabaseSpine {
    /// Connect using an explicit Postgres URL and a verified TLS root bundle.
    pub fn connect(database_url: &str) -> Result<Self, BoxErr> {
        let ca_cert = std::env::var("LOGLINE_LAB_SUPABASE_CA_CERT").map_err(|_| {
            "LOGLINE_LAB_SUPABASE_CA_CERT not set — official spine connections require verified TLS"
        })?;
        Self::connect_with_ca(database_url, ca_cert)
    }

    /// Connect using an explicit PEM CA bundle path.
    pub fn connect_with_ca(database_url: &str, ca_cert_path: impl AsRef<Path>) -> Result<Self, BoxErr> {
        let mut roots = RootCertStore::empty();
        let pem = fs::read_to_string(ca_cert_path)?;
        let certs = parse_pem_certificates(&pem)?;
        if certs.is_empty() {
            return Err("LOGLINE_LAB_SUPABASE_CA_CERT contains no certificates".into());
        }
        for cert in certs {
            roots.add(cert)?;
        }

        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let config = ClientConfig::builder_with_provider(provider)
            .with_safe_default_protocol_versions()?
            .with_root_certificates(roots)
            .with_no_client_auth();
        let tls = tokio_postgres_rustls::MakeRustlsConnect::new(config);
        let client = Client::connect(database_url, tls)?;
        Ok(Self { client })
    }

    /// Connect using `DATABASE_URL` from the environment.
    pub fn from_env() -> Result<Self, BoxErr> {
        let url = std::env::var("DATABASE_URL").map_err(|_| "DATABASE_URL not set")?;
        Self::connect(&url)
    }

    /// Connectivity probe.
    pub fn check(&mut self) -> Result<(), BoxErr> {
        self.client.simple_query("select 1")?;
        Ok(())
    }

    /// Push one act payload into the online spine via the audited, idempotent
    /// ingest boundary. Returns the act id (uuid as text).
    pub fn ingest_act(&mut self, payload: &Value) -> Result<String, BoxErr> {
        let row = self.client.query_one(
            "select id::text from ops.ingest_logline_act($1::jsonb)",
            &[payload],
        )?;
        let id: String = row.get(0);
        Ok(id)
    }

    /// Count of acts currently in the online spine.
    pub fn act_count(&mut self) -> Result<i64, BoxErr> {
        let row = self
            .client
            .query_one("select count(*)::bigint from ops.logline_acts", &[])?;
        Ok(row.get(0))
    }
}

fn parse_pem_certificates(pem: &str) -> Result<Vec<CertificateDer<'static>>, BoxErr> {
    let mut certs = Vec::new();
    let mut in_cert = false;
    let mut body = String::new();

    for line in pem.lines() {
        let line = line.trim();
        if line == "-----BEGIN CERTIFICATE-----" {
            in_cert = true;
            body.clear();
        } else if line == "-----END CERTIFICATE-----" {
            if in_cert {
                let der = base64::engine::general_purpose::STANDARD.decode(&body)?;
                certs.push(CertificateDer::from(der));
                in_cert = false;
                body.clear();
            }
        } else if in_cert {
            body.push_str(line);
        }
    }

    Ok(certs)
}
