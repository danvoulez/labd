#![forbid(unsafe_code)]

use anyhow::Context;
use clap::{Parser, Subcommand};
use constitutional_runtime::AdmissionContext;
use logline_lab_core::{
    admit_lab_act, now_rfc3339, seal_receipt_value, verify_receipt_value, ClockTick,
    DispatchPacket, DispatchPacketType, FileLabStore, GhostRecord, GhostStatus, HermesMode,
    HermesWorkorder, LabManifest, LogLineAct,
};
use logline_lab_hermes::{DryRunHermes, HermesRunner};
use serde_json::json;
use std::fs;
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "logline-lab")]
#[command(about = "Rust-first LogLine Lab kit CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Init {
        path: PathBuf,
        name: String,
        steward: String,
    },
    EmitAct {
        path: PathBuf,
        who: String,
        did: String,
        this: String,
        #[arg(long)]
        when: Option<String>,
        #[arg(long = "confirmed-by")]
        confirmed_by: String,
        #[arg(long = "if-ok")]
        if_ok: String,
        #[arg(long = "if-doubt")]
        if_doubt: String,
        #[arg(long = "if-not")]
        if_not: String,
        status: String,
    },
    SealReceipt {
        input: PathBuf,
        output: Option<PathBuf>,
    },
    VerifyReceipt {
        input: PathBuf,
    },
    Admit {
        act: PathBuf,
        context: Option<PathBuf>,
    },
    Ghost {
        path: PathBuf,
        id: String,
        missing: String,
        #[arg(long, default_value = "unscoped")]
        why: String,
        #[arg(long)]
        blocks: Vec<String>,
        #[arg(long, default_value = "dan")]
        owner: String,
        #[arg(long = "next-act", default_value = "name_next_probe")]
        next_act: String,
    },
    Workorder {
        path: PathBuf,
        id: String,
        process: String,
        #[arg(long = "target-lab")]
        target_lab: String,
        #[arg(long, value_parser = ["read_only", "dry_run", "apply"])]
        mode: String,
        objective: String,
    },
    HermesDryRun {
        path: PathBuf,
        workorder: PathBuf,
    },
    ClockTick {
        path: PathBuf,
        #[arg(long = "lab-id", default_value = "local-lab")]
        lab_id: String,
    },
    Report {
        path: PathBuf,
    },
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Init {
            path,
            name,
            steward,
        } => {
            let store = FileLabStore::new(&path);
            store.init_layout()?;
            let manifest = LabManifest::minimal(name, steward);
            let manifest_path = path.join("lab_manifest.json");
            fs::write(&manifest_path, serde_json::to_vec_pretty(&manifest)?)?;
            println!("{}", manifest_path.display());
        }
        Commands::EmitAct {
            path,
            who,
            did,
            this,
            when,
            confirmed_by,
            if_ok,
            if_doubt,
            if_not,
            status,
        } => {
            let store = FileLabStore::new(path);
            let act = LogLineAct::new(
                who,
                did,
                this,
                when.unwrap_or_else(now_rfc3339),
                confirmed_by,
                if_ok,
                if_doubt,
                if_not,
                status,
            );
            let receipt = act.to_receipt()?;
            let id = receipt.id.clone();
            let act_path = store.write_json("acts", &id, &act)?;
            let receipt_path = store.write_json("receipts", &id, &receipt)?;
            println!(
                "{}",
                serde_json::to_string_pretty(
                    &json!({"act": act_path.display().to_string(), "receipt": receipt_path.display().to_string(), "id": id})
                )?
            );
        }
        Commands::SealReceipt { input, output } => {
            let value: serde_json::Value =
                serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            let sealed = seal_receipt_value(value)?;
            let data = serde_json::to_vec_pretty(&sealed)?;
            if let Some(output) = output {
                fs::write(&output, data)?;
                println!("{}", output.display());
            } else {
                println!("{}", String::from_utf8(data)?);
            }
        }
        Commands::VerifyReceipt { input } => {
            let value: serde_json::Value =
                serde_json::from_slice(&fs::read(&input).context("read input")?)?;
            println!(
                "{}",
                serde_json::to_string_pretty(&json!({"valid": verify_receipt_value(&value)?}))?
            );
        }
        Commands::Admit { act, context } => {
            let act: LogLineAct = serde_json::from_slice(&fs::read(&act).context("read act")?)?;
            let ctx: AdmissionContext = match context {
                Some(path) => {
                    serde_json::from_slice(&fs::read(&path).context("read admission context")?)?
                }
                None => AdmissionContext::default(),
            };
            let admission = admit_lab_act(&act, &ctx);
            println!("{}", serde_json::to_string_pretty(&admission)?);
        }
        Commands::Ghost {
            path,
            id,
            missing,
            why,
            blocks,
            owner,
            next_act,
        } => {
            let store = FileLabStore::new(path);
            let ghost = GhostRecord {
                ghost_id: id.clone(),
                missing,
                why_it_matters: why,
                blocks,
                owner,
                next_act,
                opened_at: now_rfc3339(),
                status: GhostStatus::Open,
            };
            let p = store.write_json("ghosts", &id, &ghost)?;
            println!("{}", p.display());
        }
        Commands::Workorder {
            path,
            id,
            process,
            target_lab,
            mode,
            objective,
        } => {
            let store = FileLabStore::new(path);
            let mode = match mode.as_str() {
                "read_only" => HermesMode::ReadOnly,
                "dry_run" => HermesMode::DryRun,
                "apply" => HermesMode::Apply,
                _ => unreachable!(),
            };
            let dispatch = DispatchPacket {
                dispatch_version: "minilab.dispatch.v0".to_string(),
                packet_id: format!("dispatch.{}", id),
                correlation_id: id.clone(),
                created_at: now_rfc3339(),
                created_by: "logline-lab-cli".to_string(),
                process_id: process.clone(),
                organ: "LAB".to_string(),
                office: "LAB Reporter".to_string(),
                packet_type: DispatchPacketType::Verification,
                authority_level: "read_only".to_string(),
                objective: objective.clone(),
                input_sources: vec!["vendor/logline-foundation".to_string()],
                proposed_action: "prepare Hermes dry-run workorder".to_string(),
                expected_evidence: vec!["execution_report".to_string()],
                rollback_or_rectify: "none_for_dry_run".to_string(),
                required_human_check: "none_for_read_only".to_string(),
                ghosts: Vec::new(),
            };
            let workorder = HermesWorkorder {
                workorder_version: "hermes.workorder.v0".to_string(),
                workorder_id: id.clone(),
                correlation_id: id.clone(),
                source_dispatch_packet: dispatch.packet_id.clone(),
                requested_by: "logline-lab-cli".to_string(),
                target_lab,
                process_id: process,
                authority_level: "read_only".to_string(),
                mode,
                allowed_actions: vec![
                    "observe".to_string(),
                    "hash".to_string(),
                    "report".to_string(),
                ],
                forbidden_actions: vec![
                    "provider_mutation".to_string(),
                    "db_semantic_write".to_string(),
                    "secret_value_read".to_string(),
                ],
                inputs: vec![json!({"objective": objective})],
                expected_outputs: vec!["execution_report".to_string()],
                evidence_required: vec!["timestamp".to_string(), "redaction_status".to_string()],
                artifact_policy: "content_address_outputs_when_any".to_string(),
                secret_policy: "secret_names_only_no_values".to_string(),
                timeout_seconds: 60,
                rollback_or_rectify: "not_applicable_for_dry_run".to_string(),
                receipt_profile: "none_until_evidence_review".to_string(),
            };
            let dispatch_path = store.write_json("workorders", &dispatch.packet_id, &dispatch)?;
            let workorder_path = store.write_json("workorders", &id, &workorder)?;
            println!(
                "{}",
                serde_json::to_string_pretty(
                    &json!({"dispatch": dispatch_path.display().to_string(), "workorder": workorder_path.display().to_string()})
                )?
            );
        }
        Commands::HermesDryRun { path, workorder } => {
            let store = FileLabStore::new(path);
            let workorder: HermesWorkorder =
                serde_json::from_slice(&fs::read(&workorder).context("read workorder")?)?;
            let report = DryRunHermes.execute(&workorder);
            let report_path = store.write_json(
                "reports",
                &format!("execution.{}", workorder.workorder_id),
                &report,
            )?;
            println!("{}", report_path.display());
        }
        Commands::ClockTick { path, lab_id } => {
            let store = FileLabStore::new(path);
            let tick = ClockTick::manual(lab_id, "manual");
            let tick_path = store.write_json("reports", &tick.tick_id, &tick)?;
            println!("{}", tick_path.display());
        }
        Commands::Report { path } => {
            let report = json!({
                "report_version": "logline.lab.report.v0",
                "generated_at": now_rfc3339(),
                "root": path.display().to_string(),
                "states": {
                    "acts": "projected_from lab-home/acts",
                    "receipts": "projected_from lab-home/receipts",
                    "ghosts": "projected_from lab-home/ghosts",
                    "workorders": "projected_from lab-home/workorders",
                    "reports": "projected_from lab-home/reports"
                },
                "claim_limits": "filesystem projection only; not a receipt; not proof of external execution"
            });
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
    }
    Ok(())
}
