# LogLine Lab Kit — Rust Distribution

A Rust-first LogLine Lab starter kit assembled from the canonical repos included in the uploaded zip.

This kit does **not** redefine LogLine canon. It loads and vendors the canonical stack, then adds the Lab layer: manifests, runtime envelopes, ghosts, probes, evidence records, workorders, receipts, clocks, reports, and Rust operators for the first local laboratory.

```txt
LogLine Foundation = grammar / canon
LogLine engine     = Rust implementation of the nine-slot body
Conformance        = proof that engines obey
Constitutional Runtime = admission / policy / capability / evidence boundary
LogLine Lab        = practice kit
Hermes             = execution hand for admitted workorders
```

## Rust-first decision

The critical path is Rust:

```txt
crates/logline-lab-core     # primitives and receipt/admission helpers
crates/logline-lab-hermes   # Hermes workorder execution contract, dry-run only by default
crates/logline-lab-clock    # Lab pulse/tick act producer
crates/logline-lab-cli      # CLI for init, act, receipt, ghost, workorder, report
```

The vendored repos stay under `vendor/logline-foundation/` as sources and path dependencies where appropriate.

## Canonical repos vendored

```txt
vendor/logline-foundation/canon
vendor/logline-foundation/conformance
vendor/logline-foundation/engine
vendor/logline-foundation/constitutional-runtime
vendor/logline-foundation/governance
vendor/logline-foundation/ethics-is-efficient
vendor/logline-foundation/what-runs-natively-above-software
```

## Commands

```bash
cargo run -p logline-lab-cli -- init --path lab-home --name santo-andre --steward dan
cargo run -p logline-lab-cli -- emit-act --path lab-home --who dan --did declare_lab --this santo-andre --confirmed-by manual --if-ok project_manifest --if-doubt open_ghost --if-not reject --status observed
cargo run -p logline-lab-cli -- report --path lab-home
cargo run -p logline-lab-cli -- clock-tick --path lab-home
```

Hermes is intentionally dry-run/read-only at first:

```bash
cargo run -p logline-lab-cli -- workorder --path lab-home --id wo.exp000 --process exp-000.load-canonical-stack --target-lab local --mode dry_run --objective "hash and index canonical stack"
cargo run -p logline-lab-cli -- hermes-dry-run --path lab-home --workorder lab-home/workorders/wo.exp000.json
```

## Important build note

This package was generated in an environment that did **not** have `cargo` or `rustc` installed, so the source is assembled and structured but not locally compiled here. See `docs/guides/BUILD_STATUS.md`.

## Public kit contents included

The kit includes the required public Lab pieces:

```txt
README
lab manifest template
act examples
invalid act examples
runtime envelope template
runtime registry template
ghost registry template
receipt template
probe template
interval template
projector examples
clock discipline
conformance instructions
standards adapter notes
first Lab Report template
```

## First experiment

See `docs/experiments/EXP-000-load-canonical-stack.md`.

```txt
EXP-000 — Can a LogLine Lab load the canonical stack?
```

The correct first proof is not deployment. It is whether the Lab can load canon, identify engines, emit acts, preserve ghosts, prepare receipts, and report what it has actually observed.
