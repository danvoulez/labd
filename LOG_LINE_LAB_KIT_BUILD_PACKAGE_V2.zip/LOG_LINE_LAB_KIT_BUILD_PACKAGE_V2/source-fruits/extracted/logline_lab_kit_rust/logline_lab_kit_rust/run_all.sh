set -e

rustc --version
cargo --version

cargo fmt --all -- --check
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build --workspace

cargo run -p logline-lab-cli -- --help

cd vendor/logline-foundation/conformance
node tools/verify-receipt.mjs --suite
