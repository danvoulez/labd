# 01 — Minilab Founding Act

## Status

`draft fundador`

## 1. Declaração

Minilab é fundado como a instituição operacional de Dan para sustentar, por uma década ou mais, a continuidade entre casa, laboratório físico-digital, pesquisa, execução, evidência e memória institucional.

Minilab não é um app.
Minilab não é um dashboard.
Minilab não é um chatbot.
Minilab não é uma pasta de arquivos.
Minilab não é uma coleção de automações soltas.
Minilab não é um agente autônomo.
Minilab não é uma stack técnica procurando propósito.

Minilab é a instituição que permite a Dan acordar e saber:

- o que existe;
- o que está vivo;
- o que falhou;
- o que está planejado;
- o que foi executado;
- o que tem evidência;
- o que segue ghost;
- o que precisa da mão de Dan;
- o que deve ser promovido;
- o que deve ser recusado.

## 2. Frase fundadora

Minilab deve acordar todos os dias como uma instituição viva: sabendo o que existe, o que funciona, o que falhou, o que está provado, o que está ghosted, quem pode agir, e onde Dan precisa assinar consequência.

## 3. Escopo fundador

Minilab nasce para governar seis domínios permanentes:

1. Casa;
2. LAB físico-digital;
3. Pesquisa Santo André;
4. Execução controlada;
5. Evidência, receipts e ghosts;
6. Memória institucional e fontes de verdade.

Esses domínios não são projetos descartáveis. São órgãos permanentes da instituição. Ferramentas, apps, repositórios, chats, agentes e bancos de dados podem mudar. Os órgãos permanecem.

## 4. Primeiro cockpit

ChatGPT é o primeiro cockpit do Minilab.

ChatGPT pode:

- perguntar;
- organizar;
- lembrar contexto operacional;
- manter ritos;
- ocupar cargos efêmeros;
- preparar decisões;
- nomear ghosts;
- preparar relatórios;
- rotear trabalho;
- propor próximos atos.

ChatGPT não pode:

- ser fonte final de verdade;
- governar autoridade;
- fechar evidência;
- declarar execução sem prova;
- substituir receipts;
- criar consequência sem Dan;
- transformar narrativa em fato.

## 5. Dan

Dan é fundador, operador soberano e assinante de consequência.

Dan mantém com as próprias mãos:

- criação de jurisdições;
- mudança de escopo;
- promoção de fontes canônicas;
- aceitação de risco;
- aprovação de execução protegida;
- assinatura de consequência;
- decisão de publicação ou doutrina;
- correção de drift institucional.

Essas ações são manuais por desenho. A fricção humana não é defeito; é boundary de soberania.

## 6. LLMs

LLMs não são membros permanentes da instituição.

LLMs ocupam cargos efêmeros.

O cargo sobrevive ao modelo. O modelo não possui o cargo.

Todo cargo deve declarar:

- mandato;
- escopo;
- fontes autorizadas;
- o que pode fazer;
- o que não pode fazer;
- formato de handoff;
- critério de encerramento.

Regra:

> LLM ocupa cargo. Cargo não pertence ao LLM.

## 7. Lei de prova

Minilab não fecha sobre narrativa.

Plano não é execução.
Execução não é sucesso.
Observação não é verificação.
Relatório não é receipt.
Provider success não é verdade.
Receipt fecha apenas o escopo que declara.
Ghost preserva ausência.

Todo claim importante deve poder responder:

- qual é a afirmação;
- qual é o escopo;
- qual evidência existe;
- qual evidência falta;
- qual ghost impede fechamento;
- quem pode promover;
- o que seria um receipt suficiente.

## 8. Primeiro rito

O primeiro rito institucional é o Morning State.

Todo ciclo de operação começa perguntando:

- Casa: o que precisa acontecer?
- LAB: o que está vivo, stale ou unknown?
- Pesquisa: que experimento está ativo?
- Prova / Estado: o que é fato, evidência, ghost ou decisão pendente?
- Dan: que ação humana é necessária?

O Morning State não precisa provar tudo. Ele precisa impedir que ausência vire mentira.

## 9. Órgãos fundadores

Minilab nasce com estes órgãos:

1. Constituição;
2. Cockpit;
3. Casa;
4. LAB;
5. Santo André Laboratory;
6. Autoridade;
7. Evidência / Receipts / Ghosts;
8. Registry / Estado;
9. Arquivo.

Cada órgão pode depois se materializar como Project, pasta de repositório, schema, app surface, rotina, cargo, documento, ou runtime.

A ordem é:

```txt
órgão → jurisdição → fonte → rito → ferramenta
```

Nunca:

```txt
ferramenta → pasta → confusão → falsa instituição
```

## 10. Primeiro estado honesto

No momento de fundação, o estado padrão de tudo que não foi observado é `unknown`.

`unknown` não é fracasso. É honestidade inicial.

Estados iniciais permitidos:

```txt
declared
planned
observed
verified
ghost
unknown
retired
```

Nenhum estado pode ser promovido por fluência, confiança, entusiasmo, memória ou aparência.

## 11. Critério de sucesso inicial

O primeiro sucesso do Minilab não é automação completa.

O primeiro sucesso é Dan conseguir abrir o cockpit e saber, sem arqueologia:

- o que existe;
- o que está pendente;
- o que está bloqueado;
- o que tem evidência;
- o que é ghost;
- onde Dan precisa agir;
- qual é o próximo ato correto.

## 12. Próximo documento

O próximo documento fundador é:

```txt
02 — Organs and Jurisdictions
```

Ele deve definir os órgãos permanentes, seus limites, suas fontes, suas responsabilidades e o que cada órgão não pode fazer.

