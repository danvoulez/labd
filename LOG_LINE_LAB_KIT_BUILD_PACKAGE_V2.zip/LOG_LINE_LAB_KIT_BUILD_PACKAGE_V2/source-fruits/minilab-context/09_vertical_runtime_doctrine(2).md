# 09 — Vertical Runtime Doctrine

**Status:** canon candidate / operational assembly draft  
**Layer:** Minilab process dynamics, operator runtime, mini-LLM metabolism, Constitutional Runtime boundary, dispatch/Hermes seam  
**Parents:** 01 — Minilab Founding Act; 02 — Organs and Jurisdictions; 03 — Source of Truth Map; 04 — LLM Offices; 05 — Morning State Ritual; 06 — Current State; 07 — Ghost Registry; mini-llms.rs Spec; mini-llms.rs Math Contract; PR-001 LAB512 Runbook  
**Evidence status:** doctrine-grounded, runtime-unverified  
**Runtime mutation:** none  
**World-touch:** none

---

## 0. Purpose

This document defines how things happen vertically inside Minilab.

The horizontal doctrine defines organs, jurisdictions, sources, rites, and tools.

This vertical doctrine defines movement:

```txt
intent
→ office
→ operator session
→ process
→ LogLine candidate
→ Constitutional Runtime admission
→ Authority / Gate
→ Dispatch packet
→ Hermes workorder
→ LAB execution
→ evidence return
→ receipt or ghost
→ projection
→ Morning State
```

It exists to prevent the Process Catalog from becoming mere checklists and to prevent mini-LLMs, operators, dispatch packets, Hermes, or LABs from impersonating authority.

Minilab is not operated by free language alone.  
Minilab is operated by processes that pass through constitutional runtime boundaries.

---

## 1. Canonical Sentence

```txt
Minilab happens through operator-mediated constitutional runtime:
offices interpret intent,
processes lower intent into LogLine candidates,
mini-llms.rs supplies local cognition below authority,
Constitutional Runtime admits or ghosts,
Authority gates consequence,
Hermes executes admitted work,
evidence returns,
receipts close narrowly,
and projections update state.
```

Portuguese form:

```txt
Minilab acontece por runtime constitucional mediado por operadores:
offices interpretam intenção,
processos baixam intenção para candidatos LogLine,
mini-llms.rs fornece cognição local abaixo da autoridade,
o Constitutional Runtime admite ou ghosta,
a Autoridade governa consequência,
Hermes executa trabalho admitido,
a evidência retorna,
receipts fecham escopo,
e projeções atualizam o estado.
```

Short form:

```txt
Operators interpret.
mini-LLMs metabolize.
Runtime admits.
Authority gates.
Hermes executes.
Evidence returns.
Receipts close.
Ghosts preserve.
State projects.
```

---

## 2. Vertical Law

```txt
Processes are not checklists.
Processes are constitutional trajectories.
```

Every consequential process must declare:

```txt
which organ owns it
which office conducts it
which sources govern it
which operator session is active
whether mini-LLM cognition is allowed
what candidate act is produced
what admission boundary applies
what authority class applies
whether dispatch is required
whether Hermes may execute
what evidence must return
what may close
what must remain ghost
where state projects
```

Forbidden collapses:

```txt
operator output = truth
mini-LLM output = admitted act
process step = authority
dispatch packet = execution
Hermes run = receipt
LAB identity = permission
runtime observation = closure
projection = canon
Morning State = proof
```

Allowed reductions:

```txt
intent may become candidate
office may prepare process
process may produce act candidate
mini-LLM may propose structure
Constitutional Runtime may admit / reject / ghost
Authority may allow / deny / require approval
Hermes may execute admitted work
Evidence may support closure
Receipt may close declared scope
Ghost may preserve missing proof
Projection may render current state
```

---

## 3. Horizontal Versus Vertical

Horizontal doctrine answers:

```txt
What organs exist?
What sources govern truth?
Which offices may operate?
Which rites repeat?
What is current state?
What ghosts are open?
```

Vertical doctrine answers:

```txt
How does intent move?
How does an office become an operator session?
How does a process produce a candidate act?
How does local cognition assist without governing?
How does admission happen?
How does work become dispatch?
How does dispatch become Hermes execution?
How does evidence return?
How does closure or ghosting happen?
How does current state update?
```

The relationship:

```txt
01–07 define the institution.
Process Catalog defines repeatable rites.
Vertical Runtime Doctrine defines the motion through those rites.
Hermes Dispatch Contract defines the executable seam.
mini-llms.rs defines the cognition substrate below operators.
```

---

## 4. Core Objects

### 4.1 Organ

A permanent institutional function.

Examples:

```txt
Cockpit
Casa
LAB
Santo André Laboratory
Authority
Evidence / Receipts / Ghosts
Registry / Estado
Archive
```

An organ is not a tool, Project, app, schema, or chat.

### 4.2 Jurisdiction

A concrete operational room where an organ works in a tool or surface.

Examples:

```txt
ChatGPT Project
repo path
database schema
future app surface
Hermes queue namespace
```

Jurisdictions are created or changed by Dan.

### 4.3 Office

A stable institutional role that may be occupied by a model, human, or future agent.

```txt
office = mandate + scope + sources + powers + prohibitions + handoff
```

The office persists. The model does not.

### 4.4 Operator

An operator is an active occupant of an office during a bounded session.

```txt
operator = office occupant under current process scope
```

An operator may be:

```txt
Dan
ChatGPT in a Project
future GPT/Agent
mini-LLM-assisted office session
human reviewer
```

Operator is not authority by itself.

### 4.5 Operator Session

A bounded runtime context in which an office conducts a process.

Conceptual shape:

```yaml
operator_session:
  session_id:
  office_id:
  organ:
  jurisdiction:
  process_id:
  source_refs:
  input_claim:
  evidence_state:
  allowed_actions:
  forbidden_actions:
  mini_llm_allowed:
  output_type:
  handoff_required: true
  status: draft | active | blocked | handed_off | ghosted | closed
```

### 4.6 Process

A repeatable institutional trajectory.

A process defines:

```txt
gate / trigger
actor / office
preconditions
steps
runtime dynamics
evidence requirements
failures / ghosts
next process
```

### 4.7 mini-LLM Metabolism

mini-LLMs are cognitive metabolism below operators.

They may classify, summarize, compare, extract candidate structure, suggest probes, detect ghosts, and propose decision requests.

They may not admit, approve, execute, mutate, promote, close, or sign consequence.

### 4.8 LogLineCandidate

Primary live model output contract.

A LogLineCandidate has exactly the nine LogLine slots plus version metadata:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

A LogLineCandidate is not a receipt.

### 4.9 Constitutional Runtime

The semantic admission boundary.

It determines whether a candidate is shaped, admissible, blocked, ghosted, rejected, or ready to proceed to authority/dispatch.

### 4.10 Authority / Gate

The operational power boundary.

Authority classifies command class, risk, required approval, evidence path, receipt path, execution window, passkey window, and Dan signature requirements.

### 4.11 Dispatch Packet

A structured packet representing a unit of work to inspect, mutate, code, verify, research, publish, communicate, or execute.

Dispatch packet is not execution.

### 4.12 Hermes Workorder

An admitted executable dispatch subset.

Hermes receives workorders, not free language.

### 4.13 Evidence Packet

Returned observation from Hermes, LABs, providers, commands, probes, or reviews.

Evidence supports closure. It is not closure.

### 4.14 Receipt / Ghost

Receipt closes declared scope.  
Ghost preserves missing proof, authority, runtime, signer, schema, source, or evidence path.

---

## 5. Vertical Flow

### 5.1 Intake

Input may arrive from:

```txt
Dan
Morning State
Current State
Ghost Registry
Lab observation
Home observation
Research question
uploaded file
chat thread
external provider observation
Hermes execution report
```

At intake, the Cockpit or Routing Clerk must determine:

```txt
organ
jurisdiction
source class
office
process candidate
evidence state
whether Dan is needed
```

### 5.2 Office Selection

The selected office must match the organ and task.

Examples:

```txt
Morning State → Morning Scribe
Missing proof → Ghost Keeper
Research experiment → Research Registrar
Command risk → Authority Clerk
LAB health → LAB Reporter
Home continuity → Home Ops Planner
Receipt candidate → Receipt Reviewer
Doctrine conflict → Canon Librarian
Ambiguous request → Routing Clerk
```

If no office fits, do not improvise authority.

Open a ghost:

```txt
office-missing-for-process
```

or prepare an office proposal for Dan.

### 5.3 Operator Session

The office becomes active only through an operator session.

The session must declare:

```txt
scope
sources
input claim
allowed outputs
handoff format
mini-LLM allowance
```

The session may produce:

```txt
answer
report
routing note
ghost record
experiment record
authority packet
dispatch packet
receipt candidate
LogLineCandidate
next act
```

### 5.4 mini-LLM Assistance

An operator session may call mini-LLM cognition when:

```txt
classification is useful
large context must be summarized
ghosts should be detected
candidate LogLine needs extraction
findings/probes/decision requests should be proposed
profile evaluation is being performed
```

mini-LLM assistance must be recorded as observation/candidate, not truth.

### 5.5 Candidate Formation

If the process is meaningful, it should produce a candidate act or explicitly explain why no act is required.

Candidate act shape:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

Rules:

```txt
model generation is not evidence
missing evidence routes to if_doubt
contradicted evidence routes to if_not
sufficient external support may route to if_ok
```

### 5.6 Admission

The Constitutional Runtime evaluates:

```txt
slot completeness
source class
jurisdiction
operator office
process class
evidence state
capability boundary
policy class
closure claim language
secret safety
projection target
```

Possible admission outcomes:

```txt
admissible
rejected
ghosted
needs_authority
needs_evidence
needs_dan
needs_dispatch
```

No process may skip admission merely because it is well-written.

### 5.7 Authority Classification

Authority classifies:

```txt
none
read_only
normal
protected
publish_candidate
proposed_mutation
executable
```

Examples:

```txt
summarize current state → read_only
prepare dispatch → normal
change Project jurisdiction → protected / Dan manual
DB semantic write → protected
Hermes execution → executable with boundary
public post → publish_candidate / Dan depending risk
receipt closure → protected / receipt path
```

### 5.8 Dispatch

A dispatch packet is required when work crosses from interpretation into a concrete work unit.

Required for:

```txt
mutation proposal
code work
verification run
internet research with citations
publication candidate
Hermes execution
worker job
protected action preparation
```

May not be required for:

```txt
simple answer
Morning State report
routing note
ghost naming
manual Dan observation
```

### 5.9 Hermes Workorder

Only admitted executable dispatch becomes Hermes workorder.

Hermes workorder must declare:

```yaml
workorder_version:
workorder_id:
correlation_id:
source_dispatch_packet:
process_id:
target_lab:
mode: dry_run | apply
authority_level:
allowed_actions:
forbidden_actions:
inputs:
expected_outputs:
evidence_required:
secret_policy:
timeout:
rollback_or_rectify:
receipt_profile:
```

Hermes may not infer authority from workorder presence.

### 5.10 Execution

Hermes executes on LABs under admitted scope.

Hermes must preserve:

```txt
command/request
runtime
started_at
finished_at
exit/status
stdout/stderr refs
artifact refs
hashes
secret redaction
observations
ghosts
```

Hermes does not close receipts.

### 5.11 Evidence Return

Execution returns an Evidence Packet / Execution Report.

Conceptual shape:

```yaml
report_version:
workorder_id:
target_lab:
started_at:
finished_at:
status: observed | failed | inconclusive | ghost
commands_run:
artifacts:
stdout_ref:
stderr_ref:
hashes:
secret_redacted: true
observations:
ghosts:
next_act:
```

### 5.12 Closure Review

Receipt Reviewer compares:

```txt
claim
scope
evidence refs
conformance state
receipt profile
what this may close
what this does not close
ghosts
```

Closure outcomes:

```txt
receipt_candidate
receipt_closed
ghost_opened
ghost_carried
rejected_overclaim
needs_conformance
needs_dan_signature
```

### 5.13 Projection

After evidence, receipt, or ghost state changes, projection updates:

```txt
Current State
Ghost Registry
Evidence Registry
Receipt Registry
Registry / Estado
Morning State
Supabase/Postgres views when available
```

Projection is not the source of semantic truth. It is a rendered state from acts, evidence, receipts, and ghosts.

---

## 6. mini-LLM Runtime Rules

### 6.1 Role

```txt
mini-LLMs are cognitive metabolism below Operators.
```

They help an office metabolize material into structure.

They are not:

```txt
Constitutional Runtime
Authority
Tower
Hermes
Receipt Engine
Dan
```

### 6.2 Allowed Uses

```txt
classify incoming events
summarize sources
detect missing proof
extract LogLineCandidate
suggest probes
suggest decision requests
project findings from candidates
prepare ghost candidates
measure profile behavior
compare candidate outputs
```

### 6.3 Forbidden Uses

```txt
approve protected action
open execution window
execute Hermes workorder
write semantic state directly
promote canon
close receipt
claim production readiness
call model output evidence by itself
read secret values
```

### 6.4 Output Contract

Primary live output:

```txt
LogLineCandidate
```

Derived projections:

```txt
Finding
GhostCandidate
ProbeSuggestion
DecisionRequest
Summary
```

Runtime observation is always preserved.

If provider returns reasoning without final content:

```txt
extraction_status = ReasoningOnlyNoContent
candidate_emitted = false
```

### 6.5 Store Boundary

Operational persistence belongs to Supabase/Postgres or explicit future projection stores.

Allowed:

```txt
RuntimeObservation
LogLineCandidate
Finding
GhostCandidate
ProfileEvaluation
```

Forbidden:

```txt
line-delimited JSON pseudo-ledger
debug file called ledger
model output treated as receipt
filesystem persistence claiming operational truth
```

---

## 7. Constitutional Runtime Boundary

The Constitutional Runtime must stand between candidate and institutional effect.

It evaluates:

```txt
nine-slot completeness
canonical version / schema version
source class
process id
operator office
jurisdiction
capability boundary
evidence state
if_ok / if_doubt / if_not routing
status language
secret safety
closure claim risk
projection path
authority escalation requirement
```

It may return:

```txt
admit_for_planning
admit_for_dispatch
requires_authority
requires_dan
requires_evidence
ghost
reject
error
```

It may not itself execute LAB work unless routed through the admitted execution path.

---

## 8. Process Catalog Patch

Every Process Catalog entry must include a `runtime_dynamics` block.

Template:

```yaml
runtime_dynamics:
  organ:
  jurisdiction:
  primary_office:
  supporting_offices:
  operator_role:
  mini_llm_use:
    allowed: []
    forbidden: []
  model_output_contract:
  candidate_type:
  constitutional_runtime_boundary:
    checks: []
    possible_outcomes: []
  authority_boundary:
    class:
    dan_required:
    execution_window_required:
  dispatch_boundary:
    required:
    packet_type:
  hermes_boundary:
    allowed:
    mode:
    target_lab:
  evidence_return:
    required: []
  projection_target: []
  closure_path:
    receipt_candidate_allowed:
    receipt_profile:
  ghost_path:
    if_missing: []
```

A process without runtime dynamics is incomplete.

---

## 9. Example: LAB Health Check

```yaml
process_id: lab.health.check.v0
name: Check LAB health
trigger: Morning State or Dan concern

runtime_dynamics:
  organ: LAB
  jurisdiction: LAB Execution / Cockpit
  primary_office: LAB Reporter
  supporting_offices:
    - Ghost Keeper
    - Authority Clerk if execution is requested
  operator_role: report LAB state honestly and preserve unknowns
  mini_llm_use:
    allowed:
      - summarize heartbeat history
      - classify stale/offline/unknown states
      - suggest next probe
    forbidden:
      - claim machine alive without observation
      - authorize execution
      - close receipt
  model_output_contract: LogLineCandidate if local cognition is invoked
  candidate_type: observation_candidate
  constitutional_runtime_boundary:
    checks:
      - source exists
      - evidence_state declared
      - no execution claimed from missing heartbeat
      - missing heartbeat routes to if_doubt
    possible_outcomes:
      - admissible_as_report
      - ghost_lab_heartbeat_missing
      - requires_hermes_probe
  authority_boundary:
    class: normal for reporting; executable if probe command is requested
    dan_required: false for report; true if protected host action
    execution_window_required: only for protected host command
  dispatch_boundary:
    required: true if automated probe or Hermes command is requested
    packet_type: verification | executable
  hermes_boundary:
    allowed: true only for admitted probe workorder
    mode: dry_run or read_only probe by default
    target_lab: declared LAB
  evidence_return:
    required:
      - heartbeat observation
      - runtime status output if probed
      - timestamp
      - secret_redacted=true
  projection_target:
    - Current State
    - Ghost Registry
    - Morning State
  closure_path:
    receipt_candidate_allowed: only if scoped probe ran and evidence exists
    receipt_profile: minilab.health.receipt_profile.v1
  ghost_path:
    if_missing:
      - lab-inventory-missing
      - lab-heartbeat-missing
      - host-runtime-unobserved
```

---

## 10. Example: Research Experiment Registration

```yaml
process_id: santo_andre.experiment.register.v0
name: Register research experiment
trigger: new research thesis or active track selection

runtime_dynamics:
  organ: Santo André Laboratory
  jurisdiction: Research Registry
  primary_office: Research Registrar
  supporting_offices:
    - Ghost Keeper
    - Canon Librarian if doctrine promotion is implied
  operator_role: turn intuition into explicit experiment record
  mini_llm_use:
    allowed:
      - clarify thesis
      - propose invariant candidates
      - propose falsification criteria
      - draft probe candidates
    forbidden:
      - call intuition discovery
      - claim experiment passed without observation
      - promote doctrine
  model_output_contract: LogLineCandidate or Experiment Record draft
  candidate_type: research_candidate
  constitutional_runtime_boundary:
    checks:
      - thesis present
      - invariant candidate present or ghost named
      - probe candidate present or ghost named
      - evidence state declared
    possible_outcomes:
      - admissible_as_experiment_draft
      - ghost_invariant_missing
      - ghost_probe_missing
  authority_boundary:
    class: normal unless public claim or doctrine promotion
    dan_required: true for promotion or publication
    execution_window_required: false
  dispatch_boundary:
    required: false for registration; true for runtime probe execution
    packet_type: research | verification
  hermes_boundary:
    allowed: true only if experiment probe requires LAB execution
    mode: dry_run/read_only unless otherwise admitted
    target_lab: depends on probe
  evidence_return:
    required:
      - experiment record
      - source thesis
      - later probe output if run
  projection_target:
    - Santo André Experiment Registry
    - Current State
    - Morning State
  closure_path:
    receipt_candidate_allowed: only after probe observation
    receipt_profile: santo_andre.experiment.receipt_profile.v1
  ghost_path:
    if_missing:
      - research-track-not-selected
      - invariant-missing
      - probe-missing
      - observation-missing
```

---

## 11. Example: Receipt Candidate Review

```yaml
process_id: receipt.candidate.review.v0
name: Review receipt candidate
trigger: evidence exists and someone wants closure

runtime_dynamics:
  organ: Evidence / Receipts / Ghosts
  jurisdiction: Receipts & Ghosts
  primary_office: Receipt Reviewer
  supporting_offices:
    - Ghost Keeper
    - Authority Clerk if consequence-bearing
  operator_role: compare claim, scope, evidence, conformance, and overclaim risk
  mini_llm_use:
    allowed:
      - summarize evidence refs
      - detect overclaim language
      - compare claim scope to evidence scope
      - draft review note
    forbidden:
      - create receipt by prose
      - validate hash by looking at it
      - run conformance unless tool/runtime exists
      - close missing evidence
  model_output_contract: LogLineCandidate or Receipt Review draft
  candidate_type: closure_review_candidate
  constitutional_runtime_boundary:
    checks:
      - evidence refs exist
      - claim scope explicit
      - conformance state explicit
      - forbidden closure language absent
    possible_outcomes:
      - receipt_candidate_ok_for_conformance
      - ghost_evidence_missing
      - reject_overclaim
      - needs_dan_signature
  authority_boundary:
    class: protected if closure affects consequential claim
    dan_required: depends on scope and consequence
    execution_window_required: false unless probe/conformance run mutates state
  dispatch_boundary:
    required: true if conformance/probe execution is requested
    packet_type: verification
  hermes_boundary:
    allowed: true for admitted conformance/probe run
    mode: read_only by default
    target_lab: declared verification runtime
  evidence_return:
    required:
      - evidence refs
      - conformance result if claimed
      - hash refs
  projection_target:
    - Receipt Registry
    - Ghost Registry
    - Current State
  closure_path:
    receipt_candidate_allowed: true when evidence and profile exist
    receipt_profile: relevant Foundation-conformant profile
  ghost_path:
    if_missing:
      - evidence-registry-missing
      - receipt-registry-missing
      - conformance-unobserved
      - broad-claim-from-narrow-evidence
```

---

## 12. Metabolism Metrics

Process health with mini-LLM assistance must be measured as metabolism, not intelligence theater.

Minimum metrics:

```txt
content_yield
reasoning_only_rate
structured_output_rate
candidate_emission_rate
parse_failure_rate
schema_failure_rate
guard_hit_rate
evidence_routing_accuracy
false_closure_rate
projection_rate
useful_projection_rate
drift_delta
```

Hard targets:

```txt
false_closure_rate = 0
false_ok_from_missing_evidence = 0
secret_value_leakage = 0
```

A mini-LLM profile may assist operation. It may not become authority because its metrics look good.

---

## 13. Projection Targets

Vertical flow may project to:

```txt
CURRENT_STATE
GHOST_REGISTRY
EVIDENCE_REGISTRY
RECEIPT_REGISTRY
SANTO_ANDRE_EXPERIMENT_REGISTRY
LAB_INVENTORY
LAB_HEARTBEAT_LOG
HOME_OPS_PLAN
HOME_EXECUTION_LOG
AUTHORITY_LEDGER
WORK_REQUEST_LEDGER
registry.entities
registry.links
ops.logline_acts
mini_llms.*
```

Projection rules:

```txt
Projection renders state.
Projection does not create canon.
Projection does not authorize execution.
Projection does not close proof.
Projection must preserve source refs.
```

---

## 14. Failure Modes

### 14.1 Operator Drift

Symptom:

```txt
office silently expands scope or claims authority
```

Response:

```txt
stop session
name ghost: operator-scope-drift
route to Canon Librarian or Authority Clerk
```

### 14.2 mini-LLM Overclaim

Symptom:

```txt
model emits verified / safe / closed / done / production-ready without evidence
```

Response:

```txt
guard downgrade or reject
record false closure candidate
open ghost if needed
```

### 14.3 Process Without Source

Symptom:

```txt
process proceeds from memory, mood, or unstated assumption
```

Response:

```txt
ghost source-missing
ask for governing source
```

### 14.4 Dispatch Without Admission

Symptom:

```txt
packet tries to become execution by being well-formed
```

Response:

```txt
reject dispatch
route to Constitutional Runtime / Authority
```

### 14.5 Hermes As Authority

Symptom:

```txt
Hermes starts deciding what should be done
```

Response:

```txt
stop worker path
restrict Hermes to admitted workorders
open ghost hermes-authority-boundary-violated
```

### 14.6 Evidence As Closure

Symptom:

```txt
stdout, screenshot, provider 200, model answer, or test pass called receipt
```

Response:

```txt
Receipt Reviewer rejects overclaim
preserve evidence as evidence
open receipt-path-missing if needed
```

---

## 15. Open Ghosts

```txt
vertical-runtime-doc-not-promoted
process-catalog-runtime-dynamics-missing
hermes-workorder-contract-missing
constitutional-runtime-adapter-unimplemented
mini-llms-profile-evaluation-unimplemented
lab512-reasoning-only-no-content
jcs-hash-implementation-missing
current-state-projection-path-unverified
operator-session-record-schema-missing
```

---

## 16. Acceptance Criteria

This doctrine is accepted when:

```txt
1. It is reviewed and promoted by Dan, or explicitly marked superseded.
2. Process Catalog entries gain runtime_dynamics blocks.
3. Hermes Dispatch and Execution Contract references this doctrine.
4. mini-llms.rs Spec is referenced as cognition substrate, not authority.
5. PR-001 carries LogLineCandidate / RuntimeObservation output without false closure.
6. Current State and Ghost Registry can render vertical runtime ghosts.
```

---

## 17. Final Formulation

```txt
Operators are the institutional hands of interpretation.
mini-LLMs are cognitive metabolism below those hands.
Constitutional Runtime is the admission boundary.
Authority governs consequence.
Hermes is execution.
Evidence returns from contact with reality.
Receipts close only declared scope.
Ghosts preserve missing truth.
Projection makes the institution visible each morning.
```

Portuguese:

```txt
Operadores são as mãos institucionais da interpretação.
mini-LLMs são metabolismo cognitivo abaixo dessas mãos.
Constitutional Runtime é a fronteira de admissão.
Autoridade governa consequência.
Hermes é execução.
Evidência volta do contato com a realidade.
Receipts fecham apenas escopo declarado.
Ghosts preservam a verdade ausente.
Projeção torna a instituição visível a cada manhã.
```

