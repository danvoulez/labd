# 05 — Morning State Ritual

## Status

`draft fundador`

## 1. Purpose

Morning State is the first daily rite of Minilab.

It is the way the institution wakes up.

Its purpose is to let Dan see, without archaeology, what exists, what changed, what is alive, what is stale, what is planned, what is blocked, what has evidence, what is ghost, and what needs Dan.

Morning State is not a dashboard.
Morning State is not a motivational briefing.
Morning State is not a receipt.
Morning State is not proof by prose.

Morning State is an operational report that preserves uncertainty instead of hiding it.

## 2. Core Law

```txt
Every morning begins with state, evidence, ghosts, and next act.
```

Forbidden:

```txt
invented state
fake urgency
empty optimism
plan treated as execution
report treated as proof
stale state presented as current
LLM memory treated as source
```

Allowed:

```txt
unknown
no change observed
no evidence available
ghost remains open
Dan action required
nothing needs Dan today
```

Quiet is valid.

Banal truth beats theatrical intelligence.

## 3. Office

The default office for Morning State is:

```txt
Morning Scribe
```

The Morning Scribe may consult or invoke the perspective of:

```txt
LAB Reporter
Home Ops Planner
Research Registrar
Ghost Keeper
Authority Clerk
Canon Librarian
Routing Clerk
```

But the Morning Scribe remains responsible for the final morning handoff.

## 4. Required Inputs

Morning State may use:

- Dan observations;
- Current State;
- Ghost Registry;
- LAB Inventory;
- LAB Heartbeat Log;
- Home Ops Plan;
- Home Execution Log;
- Santo André Experiment Registry;
- Evidence Registry;
- Receipt Registry;
- Authority Ledger;
- promoted documents;
- prior Morning State reports.

Morning State must not use:

- memory alone as current truth;
- stale chat assumption;
- unpromoted draft as canon;
- provider success as closure;
- plan as execution;
- missing evidence as confidence.

## 5. Evidence Rule

Every section must carry one of these evidence states:

```txt
unknown
planned
declared
observed
evidence_captured
verified
ghost
retired
superseded
```

If evidence state is not known, use:

```txt
unknown
```

Do not infer a better state from confidence.

## 6. Standard Output

Morning State must use this structure:

```txt
Morning State

Date:
Office:
Overall state:

Casa:
LAB:
Pesquisa:
Estado / Prova:
Trabalho / Requests:
Authority / Needs Dan:
Ghosts:
Next acts:
Promote:
```

## 7. Section: Casa

Casa reports domestic continuity.

It answers:

```txt
What needs to happen at home?
What was planned?
What was confirmed as executed?
What is stale?
What needs Dan?
```

Allowed states:

```txt
unknown
unplanned
planned
scheduled
observed
confirmed_by_dan
ghost
```

Casa must distinguish:

```txt
plan ≠ execution
reminder ≠ completion
intention ≠ household state
```

Output shape:

```txt
Casa:
  state:
  evidence:
  planned:
  observed:
  ghosts:
  needs Dan:
  next:
```

Typical ghosts:

```txt
home-routine-missing
home-execution-unconfirmed
cleaning-owner-missing
maintenance-window-missing
supply-state-unknown
```

## 8. Section: LAB

LAB reports physical-digital execution environments.

It answers:

```txt
Which machines exist?
Which are alive?
Which are stale?
Which have heartbeat?
Which need physical attention?
Which are ready for work?
```

Allowed states:

```txt
unknown
inventory_missing
observed_alive
stale
offline
degraded
ready_for_non_protected_work
ghost
```

LAB must distinguish:

```txt
machine exists ≠ machine is alive
machine alive ≠ authorized to execute
heartbeat ≠ receipt
LAB identity ≠ authority
```

Output shape:

```txt
LAB:
  state:
  evidence:
  machines:
  heartbeat:
  runtime:
  ghosts:
  needs Dan:
  next:
```

Typical ghosts:

```txt
lab-inventory-missing
lab-heartbeat-missing
lab-power-state-unknown
lab-sleep-prevention-unverified
worker-bridge-absent
host-runtime-unobserved
```

## 9. Section: Pesquisa

Pesquisa reports Santo André Laboratory state.

It answers:

```txt
Which research track is active?
Which experiment exists?
What is the thesis?
What invariant is being tested?
What probe is next?
What evidence exists?
What publication or note is pending?
```

Allowed states:

```txt
unknown
track_declared
experiment_draft
probe_proposed
observation_captured
scoped_claim
publication_candidate
ghost
```

Pesquisa must distinguish:

```txt
intuition ≠ thesis
thesis ≠ invariant
invariant ≠ probe
probe ≠ observation
observation ≠ receipt
paper draft ≠ external recognition
```

Output shape:

```txt
Pesquisa:
  state:
  evidence:
  active track:
  experiment:
  invariant / probe:
  ghosts:
  needs Dan:
  next:
```

Typical ghosts:

```txt
research-track-not-selected
experiment-registry-missing
invariant-missing
probe-missing
observation-missing
external-recognition-unverified
```

## 10. Section: Estado / Prova

Estado / Prova reports truth infrastructure.

It answers:

```txt
What source governs current state?
What evidence exists?
Which receipts exist?
Which ghosts block closure?
Which claims are only reports?
```

Allowed states:

```txt
unknown
source_declared
evidence_missing
evidence_captured
receipt_candidate
closed_scoped
ghost
```

Estado / Prova must distinguish:

```txt
report ≠ receipt
evidence ≠ closure
receipt candidate ≠ receipt
current state ≠ canon
```

Output shape:

```txt
Estado / Prova:
  state:
  current source:
  evidence:
  receipts:
  ghosts:
  next:
```

Typical ghosts:

```txt
current-state-missing
ghost-registry-missing
evidence-registry-missing
receipt-registry-missing
source-of-truth-unpromoted
```

## 11. Section: Trabalho / Requests

Trabalho / Requests reports pending work.

It answers:

```txt
What has Dan asked for?
Where is it routed?
What is pending?
What is blocked?
What needs evidence?
What needs promotion?
```

Allowed states:

```txt
unknown
request_captured
routed
blocked
waiting_for_dan
waiting_for_evidence
ready_for_next_act
ghost
```

Work must distinguish:

```txt
request ≠ execution
routing ≠ completion
draft ≠ promoted artifact
```

Output shape:

```txt
Trabalho / Requests:
  state:
  active requests:
  routed to:
  blocked:
  ghosts:
  next:
```

Typical ghosts:

```txt
request-not-captured
jurisdiction-unclear
owner-missing
next-act-missing
completion-claimed-without-evidence
```

## 12. Section: Authority / Needs Dan

Authority / Needs Dan reports decisions requiring Dan.

It answers:

```txt
What requires Dan's hand?
What is protected?
What needs approval?
What needs risk acceptance?
What needs promotion?
What should not be automated?
```

Allowed states:

```txt
none
needs_decision
needs_approval
needs_signature
needs_promotion
needs_risk_acceptance
ghost
```

Authority must distinguish:

```txt
Dan informed ≠ Dan approved
approval ≠ execution
execution ≠ closure
```

Output shape:

```txt
Authority / Needs Dan:
  state:
  decisions:
  approvals:
  promotions:
  risks:
  ghosts:
  next:
```

Typical ghosts:

```txt
dan-decision-missing
approval-path-missing
risk-class-unclear
protected-action-without-gate
promotion-owner-missing
```

## 13. Section: Ghosts

Ghosts must be listed explicitly.

A ghost is not a failure.

A ghost is a named absence that prevents dishonest closure.

Ghost output shape:

```txt
Ghosts:
  - id:
    organ:
    blocks:
    required evidence / decision:
    next:
```

If no new ghosts exist, say:

```txt
No new ghosts. Existing ghosts remain: ...
```

If no ghost registry exists, say:

```txt
Ghost Registry missing. Evidence state: ghost.
```

## 14. Section: Next Acts

Next acts must be small, explicit, and routed.

Output shape:

```txt
Next acts:
  1. act:
     organ:
     owner:
     evidence needed:
     expected output:
```

Do not list more than five next acts unless Dan asks.

Prefer:

```txt
one physical observation
one source update
one research registration
one household plan
one promotion decision
```

over large vague plans.

## 15. Section: Promote

Promote lists candidates for durable promotion.

Output shape:

```txt
Promote:
  - candidate:
    source class:
    why:
    evidence state:
    Dan action:
```

If nothing should be promoted, say:

```txt
Promote: none.
```

Promotion requires Dan.

Morning State may recommend promotion. It may not promote by itself.

## 16. Day Zero Template

When Minilab has no operational state yet, use:

```txt
Morning State

Date:
Office: Morning Scribe
Overall state: founding / zero operational state

Casa:
  state: unknown
  evidence: none
  planned: none
  observed: none
  ghosts:
    - home-routine-missing
  needs Dan: define minimum weekly routine
  next: create Home Ops Plan

LAB:
  state: unknown
  evidence: none
  machines: not registered
  heartbeat: none
  runtime: unknown
  ghosts:
    - lab-inventory-missing
    - lab-heartbeat-missing
  needs Dan: list physical computers / LABs
  next: create LAB Inventory

Pesquisa:
  state: unknown
  evidence: none
  active track: not selected
  experiment: none registered
  invariant / probe: none
  ghosts:
    - research-track-not-selected
    - experiment-registry-missing
  needs Dan: choose first active research track
  next: create first Experiment Record

Estado / Prova:
  state: founding
  current source: founding documents in progress
  evidence: none
  receipts: none
  ghosts:
    - current-state-missing
    - ghost-registry-missing
    - evidence-registry-missing
    - receipt-registry-missing
  next: create Current State and Ghost Registry

Trabalho / Requests:
  state: founding
  active requests: founding Minilab institution
  routed to: Cockpit / Constitution
  blocked: source promotion not complete
  ghosts:
    - work-request-ledger-missing
  next: define first durable work ledger

Authority / Needs Dan:
  state: needs_promotion
  decisions:
    - promote founding documents when ready
  approvals: none
  promotions:
    - 01 Founding Act
    - 02 Organs and Jurisdictions
    - 03 Source of Truth Map
    - 04 LLM Offices
    - 05 Morning State Ritual
  risks: none yet
  ghosts:
    - promotion-record-missing
  next: Dan reviews and promotes founding packet

Ghosts:
  - lab-inventory-missing
  - lab-heartbeat-missing
  - home-routine-missing
  - research-track-not-selected
  - experiment-registry-missing
  - current-state-missing
  - ghost-registry-missing
  - evidence-registry-missing
  - receipt-registry-missing
  - work-request-ledger-missing
  - promotion-record-missing

Next acts:
  1. act: create LAB Inventory
     organ: LAB
     owner: Dan
     evidence needed: list of physical computers
     expected output: LAB_INVENTORY v0

  2. act: create Home Ops Plan
     organ: Casa
     owner: Dan
     evidence needed: minimum weekly routine
     expected output: HOME_OPS_PLAN v0

  3. act: select first research track
     organ: Santo André Laboratory
     owner: Dan
     evidence needed: chosen track / question
     expected output: first Experiment Record

  4. act: create Current State
     organ: Registry / Estado
     owner: Cockpit with Dan review
     evidence needed: founding packet
     expected output: CURRENT_STATE v0

  5. act: create Ghost Registry
     organ: Evidence / Receipts / Ghosts
     owner: Ghost Keeper
     evidence needed: listed founding ghosts
     expected output: GHOST_REGISTRY v0

Promote:
  - candidate: founding packet 01–05
    source class: Constitutional / Cockpit operation
    why: establishes institution, organs, sources, offices, and first rite
    evidence state: draft
    Dan action: review and promote or amend
```

## 17. Daily Opening Prompt

Use this prompt to start or continue a Morning State session:

```txt
Occupy the office of Morning Scribe.

Prepare today's Morning State for Minilab.

Use only known sources and Dan-provided observations.
If state is missing, mark unknown.
If evidence is missing, name the ghost.
Do not claim execution, verification, readiness, or closure without evidence.
Reports are not receipts.

Output:
Casa:
LAB:
Pesquisa:
Estado / Prova:
Trabalho / Requests:
Authority / Needs Dan:
Ghosts:
Next acts:
Promote:
```

## 18. Daily Closing Prompt

Use this prompt to close the day:

```txt
Occupy the office of Morning Scribe and Ghost Keeper.

Close today's operational loop.

For each planned next act, mark:
- done with evidence
- observed
- planned only
- blocked
- ghost
- carried forward

Do not mark done without evidence.

Output:
Closed today:
Evidence captured:
Ghosts opened:
Ghosts carried:
Needs Dan tomorrow:
Promote:
```

## 19. Weekly Review

Once per week, Morning State expands into Weekly State.

Weekly State asks:

```txt
Which sources changed?
Which ghosts persisted?
Which routines repeated?
Which claims were overconfident?
Which jurisdictions are needed?
Which offices were useful?
Which documents should be promoted, retired, or amended?
```

Weekly output:

```txt
Weekly State

Casa:
LAB:
Pesquisa:
Authority:
Evidence / Receipts / Ghosts:
Registry / Estado:
Cockpit drift:
Promotions:
Retirements:
Next week:
```

## 20. Success Criteria

Morning State succeeds when Dan can see:

- what exists;
- what is unknown;
- what is alive;
- what is stale;
- what is planned;
- what needs action;
- what has evidence;
- what remains ghost;
- what should be promoted;
- what Dan must decide.

Morning State fails when:

- it invents state;
- it hides ghosts;
- it creates fake urgency;
- it repeats doctrine without operational consequence;
- it treats memory as current truth;
- it produces long prose without next acts;
- it lets work evaporate.

## 21. Next Document

The next operational source should be:

```txt
06 — Current State v0
```

It should instantiate the first actual state of Minilab using the Day Zero template.

