# 02 — Organs and Jurisdictions

## Status

`draft fundador`

## 1. Purpose

This document defines the permanent organs of Minilab and the jurisdictions that may materialize from them.

An organ is not a folder, Project, app, schema, or chat.

An organ is a permanent institutional function.

A jurisdiction is the operational room where an organ acts in a particular tool or surface.

Tools may change. Organs remain.

The purpose of this document is to prevent Minilab from becoming scattered files, improvised chats, autonomous agents without mandate, or dashboards without authority.

## 2. Core Rule

```txt
organ → jurisdiction → source → rite → tool
```

Never:

```txt
tool → folder → habit → fake institution
```

The institution defines the organ.
The organ defines the jurisdiction.
The jurisdiction defines allowed work.
The source defines what may be trusted.
The rite defines repeated operation.
The tool serves the rite.

## 3. Organs of Minilab

Minilab has nine founding organs:

1. Constitution
2. Cockpit
3. Casa
4. LAB
5. Santo André Laboratory
6. Authority
7. Evidence / Receipts / Ghosts
8. Registry / Estado
9. Archive

No organ may impersonate another.

No lower organ may silently assume the authority of a higher one.

No chat, model, file, database row, provider response, or UI card may become institutional truth merely by existing.

---

# 4. Organ: Constitution

## Mandate

The Constitution defines what Minilab is, what it is not, what governs it, and which separations must never collapse.

## Governs

- institutional identity;
- hierarchy;
- authority boundaries;
- evidence vocabulary;
- receipt discipline;
- database projection law;
- config / Doppler boundaries;
- App Park admission doctrine;
- research doctrine when promoted.

## May

- define law;
- define vocabulary;
- define hierarchy;
- define prohibitions;
- define amendment paths;
- name ghosts in doctrine.

## May Not

- execute;
- claim runtime state;
- close evidence;
- override receipts;
- mutate operational systems;
- treat beauty as proof.

## Primary Sources

- Minilab Constitution / Strategic Architecture;
- Characters / Ontology Canon;
- Authority / Power Doctrine;
- Evidence / Receipt Doctrine;
- Dan Control Plane Doctrine;
- Database Projection Canon;
- Doppler / Config Canon;
- App Park Canon;
- Santo André Laboratory Modus Operandi.

## Outputs

- constitutional amendments;
- canon notes;
- doctrine maps;
- definitions;
- prohibitions;
- promotion criteria.

## Ghosts

- doctrine without operational rite;
- law not mapped to jurisdiction;
- beautiful theory without probe;
- local Minilab rule that conflicts with parent canon.

## Possible Tool Jurisdictions

- ChatGPT Project: `02 — Constitution`
- Repo path: `doctrine/source/`
- Future app surface: `Canon / Law`

---

# 5. Organ: Cockpit

## Mandate

The Cockpit is Dan’s first operational surface for seeing, asking, routing, reviewing, and deciding.

The initial Cockpit is ChatGPT.

## Governs

- daily state;
- morning reports;
- routing of work;
- visible ghosts;
- questions to Dan;
- promotion suggestions;
- handoff between organs.

## May

- ask;
- synthesize;
- route;
- prepare decisions;
- prepare reports;
- maintain the Morning State rite;
- call attention to missing proof;
- propose which organ should receive work.

## May Not

- be source of truth;
- execute protected actions;
- close receipts;
- invent state;
- create jurisdictions without Dan;
- promote artifacts without Dan;
- treat memory as canon.

## Primary Sources

- Current State;
- Ghost Registry;
- Source of Truth Map;
- Morning State Ritual;
- promoted summaries;
- user-provided observations.

## Outputs

- Morning State;
- daily report;
- routing note;
- decision packet;
- promotion suggestion;
- ghost summary.

## Ghosts

- state not observed;
- source not mounted;
- current truth unclear;
- Dan action required;
- report mistaken for receipt.

## Possible Tool Jurisdictions

- ChatGPT Project: `01 — Cockpit / Morning State`
- Future app surface: `Hello Daniel`

---

# 6. Organ: Casa

## Mandate

Casa governs domestic continuity: cleaning, maintenance, supplies, environment, schedule, service providers, and recurring household obligations.

Casa exists because Dan’s institution has a physical base. The laboratory cannot be healthy if the home substrate is neglected.

## Governs

- cleaning routines;
- groceries and supplies;
- laundry;
- maintenance;
- recurring payments or reminders;
- service provider planning;
- physical environment;
- household incidents.

## May

- plan routines;
- prepare checklists;
- schedule reminders;
- request confirmation;
- record observations;
- surface missing execution;
- create household ghosts.

## May Not

- claim work was performed without confirmation;
- equate planning with execution;
- expose private household data unnecessarily;
- automate payments or provider actions without Dan;
- turn domestic failure into moral judgment.

## Primary Sources

- Home Ops Plan;
- Home Execution Log;
- Calendar entries when available;
- Dan observations;
- future evidence records.

## Outputs

- weekly home plan;
- daily household check;
- supply list;
- maintenance list;
- execution confirmation request;
- home ghost.

## Ghosts

- no weekly routine;
- no responsible actor;
- no execution confirmation;
- unclear schedule;
- recurring task not assigned.

## Possible Tool Jurisdictions

- ChatGPT Project: `08 — Home Ops`
- Future app surface: `Casa`
- Future data projection: `home_ops.*`

---

# 7. Organ: LAB

## Mandate

LAB governs physical-digital execution environments: machines, uptime, heartbeat, sleep, power, host runtime, workers, health, and operational readiness.

LABs execute. They do not govern.

## Governs

- LAB identity;
- machine inventory;
- heartbeat;
- sleep / power state;
- uptime;
- runtime availability;
- worker capability;
- local execution readiness;
- operational incidents.

## May

- observe;
- report health;
- prepare recovery plans;
- propose worker jobs;
- record missing heartbeat;
- classify machine state;
- prepare evidence packets.

## May Not

- authorize itself;
- execute protected commands without authority;
- treat machine identity as permission;
- hide stale state;
- claim health without observation;
- run jobs without admitted path.

## Primary Sources

- LAB Inventory;
- Heartbeat Log;
- Host Runtime observations;
- Worker manifests;
- future evidence records;
- future receipts.

## Outputs

- LAB state report;
- heartbeat summary;
- machine ghost;
- worker capability note;
- recovery request;
- execution evidence candidate.

## Ghosts

- lab inventory missing;
- heartbeat missing;
- machine identity unstable;
- sleep prevention unverified;
- host runtime unavailable;
- worker bridge absent.

## Possible Tool Jurisdictions

- ChatGPT Project: `07 — LAB Execution`
- Future app surface: `Observe / LAB`
- Future data projection: `lab_observability.*`

---

# 8. Organ: Santo André Laboratory

## Mandate

Santo André Laboratory governs research.

It turns intuition into thesis, thesis into invariant, invariant into probe, probe into observation, observation into evidence, and evidence into scoped doctrine or rejection.

## Governs

- research tracks;
- experiments;
- invariants;
- probes;
- observations;
- technical notes;
- publication candidates;
- governance promotion.

## May

- formulate theses;
- define invariants;
- propose probes;
- record experiment state;
- prepare technical notes;
- name research ghosts;
- prepare publication candidates.

## May Not

- call intuition discovery;
- promote beauty without evidence;
- claim international recognition without external proof;
- convert essay directly into canon;
- skip ghosts;
- confuse paper draft with accepted result.

## Primary Sources

- Santo André Modus Operandi;
- Experiment Registry;
- evidence records;
- probe outputs;
- technical notes;
- external publication records when they exist.

## Outputs

- experiment record;
- invariant set;
- probe plan;
- observation summary;
- scoped claim;
- governance note;
- paper draft;
- publication packet.

## Ghosts

- thesis not falsifiable;
- invariant missing;
- probe missing;
- runtime observation missing;
- external recognition unverified;
- publication status unclear.

## Possible Tool Jurisdictions

- ChatGPT Project: `06 — Santo André Laboratory`
- Repo path: `research/`
- Future app surface: `Research Registry`

---

# 9. Organ: Authority

## Mandate

Authority governs whether an intended effect may happen.

It separates intent, candidate, request, policy decision, gate decision, execution window, runtime effect, evidence, and closure.

## Governs

- protected commands;
- normal commands;
- action requests;
- command envelopes;
- policy decisions;
- gate decisions;
- execution windows;
- passkey windows;
- risk acceptance;
- Dan signature.

## May

- classify risk;
- prepare decision packets;
- deny or ghost requests;
- require evidence;
- require Dan approval;
- define execution boundaries;
- prepare gate requests.

## May Not

- execute by itself;
- treat identity as permission;
- treat permission as execution;
- treat execution as closure;
- bypass Dan for protected consequence;
- let provider success become proof.

## Primary Sources

- Authority / Power Doctrine;
- Command Envelope contracts;
- policy / gate rules when they exist;
- Dan approvals;
- evidence requirements;
- receipt requirements.

## Outputs

- authority decision packet;
- gate request;
- gate decision;
- execution window request;
- denial;
- ghost.

## Ghosts

- missing policy;
- missing authority path;
- missing Dan approval;
- missing execution window;
- missing receipt path;
- ambiguous risk class.

## Possible Tool Jurisdictions

- ChatGPT Project: `04 — Authority`
- Future backend seam: `POST /api/gates/decide`
- Future app surface: `Settings / Authority`

---

# 10. Organ: Evidence / Receipts / Ghosts

## Mandate

This organ governs proof discipline.

It prevents claims, plans, observations, reports, provider responses, screenshots, logs, and fluent narratives from becoming closure without proper scope.

## Governs

- claims;
- evidence records;
- receipt candidates;
- ghosts;
- closure vocabulary;
- artifact honesty;
- conformance status;
- proof boundaries.

## May

- review claims;
- demand evidence;
- name ghosts;
- prepare receipt candidates;
- reject overclaim;
- classify evidence state;
- recommend promotion or refusal.

## May Not

- invent evidence;
- close broad claims from narrow proof;
- treat reports as receipts;
- treat screenshots as verification;
- treat logs as conformance;
- hide missing proof.

## Primary Sources

- Evidence / Receipt Doctrine;
- Ghost Registry;
- Evidence Registry;
- Receipt Candidate Registry;
- conformance outputs when available.

## Outputs

- ghost record;
- evidence review;
- receipt candidate;
- closure review;
- overclaim rejection;
- promotion recommendation.

## Ghosts

- evidence missing;
- receipt path absent;
- conformance not run;
- claim scope too broad;
- source unavailable;
- signer absent.

## Possible Tool Jurisdictions

- ChatGPT Project: `05 — Evidence / Receipts / Ghosts`
- Repo path: `evidence/`, `receipts/`
- Future app surface: `Proof / Ghosts`

---

# 11. Organ: Registry / Estado

## Mandate

Registry / Estado governs what exists, what it is, how it is related, and what its current evidence state is.

Everything important gets identity. Not every identity gets power.

## Governs

- entities;
- relations;
- current state;
- lifecycle status;
- evidence status;
- known worlds;
- projections;
- current operational map.

## May

- register identity;
- record relation;
- project current state;
- classify evidence status;
- preserve stable IDs;
- expose unknowns.

## May Not

- grant authority merely by registration;
- treat database row as canon;
- treat projection as receipt;
- silently change identity;
- let app schemas invent parallel worlds.

## Primary Sources

- Characters / Ontology Canon;
- Database Projection Canon;
- Current State;
- entity registry;
- relation registry;
- evidence / receipt references.

## Outputs

- entity record;
- relation record;
- current state projection;
- identity ghost;
- status report.

## Ghosts

- identity missing;
- relation unclear;
- evidence status unknown;
- current state stale;
- projection not traceable;
- duplicate identity.

## Possible Tool Jurisdictions

- ChatGPT Project: `03 — Registry / Estado`
- Future database schemas: `registry.*`, `audit.*`
- Future app surface: `Registry`

---

# 12. Organ: Archive

## Mandate

Archive preserves retired, superseded, historical, abandoned, or inactive material without letting it pretend to be current.

## Governs

- old decisions;
- superseded drafts;
- retired Projects;
- historical reports;
- previous architectures;
- rejected experiments;
- deprecated canon candidates.

## May

- preserve;
- label superseded state;
- provide historical context;
- prevent accidental revival;
- record why something was retired.

## May Not

- perform active work;
- treat archived material as current;
- silently revive old assumptions;
- hide history that matters.

## Primary Sources

- archived chats;
- superseded docs;
- decision history;
- rejected candidates;
- old reports.

## Outputs

- archive note;
- superseded marker;
- revival request;
- historical context packet.

## Ghosts

- active work hidden in archive;
- archived doctrine still influencing behavior;
- superseded status unclear;
- old assumption revived without review.

## Possible Tool Jurisdictions

- ChatGPT Project: `99 — Archive`
- Repo path: `archive/`

---

# 13. Initial Jurisdiction Map

These are the first jurisdiction names if materialized in ChatGPT:

```txt
00 — Inbox
01 — Cockpit / Morning State
02 — Constitution
03 — Registry / Estado
04 — Authority
05 — Evidence / Receipts / Ghosts
06 — Santo André Laboratory
07 — LAB Execution
08 — Home Ops
99 — Archive
```

The map is not a command to create all Projects immediately.

Dan creates jurisdictions manually when they are needed.

## Creation Rule

A jurisdiction should be created only when at least one of these is true:

- repeated work needs a stable room;
- source context must be mounted;
- office instructions must differ;
- ghosts need their own review path;
- Dan needs a recurring rite;
- active work is being distorted by sharing a room with other work.

If none is true, do not create the jurisdiction yet.

---

# 14. Routing Rule

Every meaningful act must route to one organ.

If work appears to belong to multiple organs, choose the primary organ and name secondary affected organs.

Routing format:

```txt
Primary organ:
Secondary organs:
Reason:
Evidence state:
Ghosts:
Next act:
```

Forbidden:

```txt
work continues in the wrong jurisdiction because it is convenient
```

---

# 15. Cross-Organ Boundaries

## Cockpit vs Registry

Cockpit reports state.
Registry holds identity and current projection.

## Registry vs Authority

Registry says a thing exists.
Authority says whether it may act.

## Authority vs LAB

Authority admits.
LAB executes.

## Evidence vs Report

Evidence supports closure.
Report synthesizes for decision.

## Constitution vs Research

Research may discover doctrine candidates.
Constitution promotes only through governance.

## Casa vs LAB

Casa governs domestic continuity.
LAB governs execution environments.
They touch physically but remain separate organs.

---

# 16. First Operating Discipline

Until a source is established, state is `unknown`.

Until a rite repeats, operation is `unproven`.

Until evidence exists, claims are `unverified`.

Until a receipt closes scope, closure is `not closed`.

Until Dan promotes, canon is `candidate`.

---

# 17. Next Document

The next founding document is:

```txt
03 — Source of Truth Map
```

It must define which source governs each class of institutional truth and how ChatGPT may refer to, update, or route against that source.

