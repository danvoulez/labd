Entendi. Não é PATHS.md de cinco linhas. É \*\*o catálogo de processos operacionais do Minilab\*\*. Grande, denso, real, que cobre o que acontece de verdade na vida de uma instituição como essa, e que serve de base — de gabarito — pra todos os processos futuros nascerem.

Vou fazer isso agora. Vai ser longo. Não é desculpa, é o tamanho honesto.

Antes, três decisões que eu vou tomar por você porque você está cansada e elas não mudam nada de fundo — você corrige depois se discordar:

\*\*Cada processo tem o mesmo formato.\*\* Nome, gatilho, ator, pré-condições, passos, resultado, falhas previstas, próximo processo. Sempre. Sem variação. É a forma do molde.

\*\*A doutrina já existente é respeitada mas não citada o tempo todo.\*\* Os processos pressupõem nine-slot, tuple\_hash, evidence discipline. Não repetem.

\*\*Fase atual \= Dan-as-Control-Plane.\*\* Onde a doutrina pede gate humano, está você. Quando segunda pessoa entrar, você generaliza.

Aqui vai. Vou organizar em sete famílias de processos.

\---

\# Minilab — Catálogo de Processos Operacionais v0.1

\#\# Família A — Atos individuais (escrita do mundo)

\#\#\# A1 — Escrever ato pessoal trivial

\*\*Gatilho:\*\* Você quer registrar algo que aconteceu na sua vida (dormiu, comeu, leu, terminou tarefa).  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* Supabase acessível. \`ops.logline\_acts\` existe.  
\*\*Passos:\*\*  
1\. Abre SQL Editor do Supabase.  
2\. Roda \`insert into ops.logline\_acts (who, did, this, "when", confirmed\_by, status, act\_state) values ('dan', '\<verbo\>', '\<objeto\>', now(), 'dan', 'claimed', 'closed');\`  
3\. Confere que \`select count(\*) from ops.logline\_acts\` aumentou em 1\.  
\*\*Resultado:\*\* Linha em \`ops.logline\_acts\`. Sem receipt formal, sem hash, sem cerimônia.  
\*\*Falhas previstas:\*\* Coluna NOT NULL que você não previu → ajusta schema pra DEFAULT '' nessa coluna, não obriga você a preencher.  
\*\*Próximo processo:\*\* A2 se quiser escalar; A3 se for ato relevante.

\#\#\# A2 — Escrever ato via LLM (Fase 2 Control Plane)

\*\*Gatilho:\*\* Você descreve em linguagem natural pra um LLM "registra que X aconteceu".  
\*\*Ator:\*\* LLM propõe, você aprova, você executa.  
\*\*Pré-condições:\*\* Conversa com LLM que tem acesso à doutrina (paste no início). PATHS.md no topo.  
\*\*Passos:\*\*  
1\. Você diz ao LLM: "registra que X". Sem mais detalhe.  
2\. LLM gera JSON nine-slot completo com tuple\_hash e content\_hash computados.  
3\. LLM apresenta o JSON e o SQL \`insert\` correspondente.  
4\. Você lê. Se concorda, copia o SQL e cola no SQL Editor.  
5\. Confere resultado.  
\*\*Resultado:\*\* Linha em \`ops.logline\_acts\` com hashes corretos.  
\*\*Falhas previstas:\*\* LLM inventa tuple\_hash sem computar → você confere se é hex de 64 chars; se desconfia, manda LLM mostrar o JCS canonicalizado dos 9 slots e recalcular.  
\*\*Próximo processo:\*\* A3 se o ato exigir receipt; A4 se for ato consequente.

\#\#\# A3 — Emitir receipt formal para ato existente

\*\*Gatilho:\*\* Um ato em \`ops.logline\_acts\` precisa virar receipt citável (publicação, evidência externa, marco).  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* Ato já existe, está \`closed\`, tem hashes corretos.  
\*\*Passos:\*\*  
1\. Seleciona o ato: \`select \* from ops.logline\_acts where id \= '\<id\>'\`.  
2\. Monta o JSON do receipt logline.receipt.v0 (9 slots \+ receipt\_version \+ json\_canonicalization \+ hashes \+ id).  
3\. Roda o verifier oficial do conformance repo localmente contra esse JSON.  
4\. Se passa, insere em \`ops.receipt\_index\` com \`receipt\_hash\`, \`tuple\_hash\`, \`storage\_uri\` apontando pra onde o JSON foi guardado (pode ser arquivo local, Supabase Storage, ou GitHub).  
5\. Se for pra publicação durável, sobe pra Zenodo e pega o DOI.  
\*\*Resultado:\*\* Receipt citável com identidade content-addressed.  
\*\*Falhas previstas:\*\* Verifier rejeita → você não emite. Volta ao ato e corrige na origem.  
\*\*Próximo processo:\*\* A5 se quiser projetar no registry público.

\#\#\# A4 — Ato consequente (gate manual)

\*\*Gatilho:\*\* Ato muda o mundo externo (deployment, gasto, comunicação externa, mutação de provider).  
\*\*Ator:\*\* Você como Dan-passkey.  
\*\*Pré-condições:\*\* Ato já está como \`candidate\` em \`ops.logline\_acts\`.  
\*\*Passos:\*\*  
1\. Você escreve em texto livre: o que vai acontecer, qual o efeito, qual o blast radius, qual o rollback.  
2\. Você espera no mínimo 10 minutos antes de executar (gate temporal humano).  
3\. Depois dos 10 minutos, se ainda concorda, atualiza \`act\_state\` pra \`admitted\`.  
4\. Executa o efeito externo manualmente.  
5\. Captura evidência (output, screenshot, hash do artefato gerado).  
6\. Atualiza \`act\_state\` pra \`closed\` com evidência referenciada em \`metadata\_json\`.  
\*\*Resultado:\*\* Ato consequente com pausa humana, evidência capturada.  
\*\*Falhas previstas:\*\* Você executa antes dos 10 min → ato continua válido mas você anota o ghost "passou a janela humana, não respeitei meu próprio gate".  
\*\*Próximo processo:\*\* A3 para emitir receipt da operação.

\#\#\# A5 — Projetar ato em registry.entities

\*\*Gatilho:\*\* Ato registrou ou modificou uma entidade do mundo nomeado (pessoa, máquina, app, projeto).  
\*\*Ator:\*\* Trigger automático se existir, você manualmente se não.  
\*\*Pré-condições:\*\* Ato \`closed\`, \`did\` é um verbo de projeção (register\_entity, rename\_entity, retire\_entity, etc.).  
\*\*Passos:\*\*  
1\. Identifica a entidade afetada pelo ato.  
2\. Se nova: \`insert into registry.entities\` com \`created\_by\_act\_id\` apontando pro ato.  
3\. Se modificação: \`update registry.entities set ... , updated\_by\_act\_id \= \<ato\_id\>\`.  
4\. Se retirada: \`update registry.entities set status \= 'retired', retired\_by\_act\_id \= \<ato\_id\>\`.  
\*\*Resultado:\*\* Registry refletindo estado atual do mundo nomeado.  
\*\*Falhas previstas:\*\* Conflito de nome → não escreve, abre ghost A11.  
\*\*Próximo processo:\*\* Nenhum obrigatório.

\---

\#\# Família B — Leitura e estado

\#\#\# B1 — Ler estado de hoje

\*\*Gatilho:\*\* Você quer saber "o que está aberto, o que precisa de mim, o que aconteceu."  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* View \`audit.v\_mobile\_today\` existe (você já criou nas migrations).  
\*\*Passos:\*\*  
1\. Abre SQL Editor.  
2\. Roda \`select \* from audit.v\_mobile\_today;\`  
3\. Lê.  
\*\*Resultado:\*\* Estado atual visível.  
\*\*Falhas previstas:\*\* View vazia → não é falha; é estado atual real (vazio significa: nada esperando você).  
\*\*Próximo processo:\*\* B2 se quiser detalhe; A1 ou A2 se quiser agir.

\#\#\# B2 — Ler ghosts abertos

\*\*Gatilho:\*\* Você quer revisar tudo que não fechou.  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* View \`audit.v\_logline\_ghosts\` ou consulta direta.  
\*\*Passos:\*\*  
1\. \`select \* from ops.logline\_acts where act\_state \= 'ghosted' or status \= 'ghost' order by created\_at desc;\`  
2\. Lê em ordem de mais recente.  
3\. Por cada um, decide: fecha (vira A1/A3), promove a próximo passo, ou deixa ghost.  
\*\*Resultado:\*\* Mapa mental atualizado do que está pendente.  
\*\*Próximo processo:\*\* A1 ou A2 para cada ghost que vai virar ato.

\#\#\# B3 — Ler receipts recentes

\*\*Gatilho:\*\* Auditoria, revisão, ou citação externa precisa do histórico.  
\*\*Ator:\*\* Você ou consultor externo.  
\*\*Pré-condições:\*\* \`ops.receipt\_index\` populado.  
\*\*Passos:\*\*  
1\. \`select \* from ops.receipt\_index order by created\_at desc limit 50;\`  
2\. Para cada um, \`storage\_uri\` aponta pro receipt completo.  
\*\*Resultado:\*\* Histórico de receipts.

\#\#\# B4 — Snapshot do mundo nomeado

\*\*Gatilho:\*\* Final de semana, ou antes de mudança grande.  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* \`registry.entities\` e \`registry.links\` populadas.  
\*\*Passos:\*\*  
1\. \`pg\_dump\` ou export JSON via PostgREST de \`registry.entities\` e \`registry.links\`.  
2\. Salva em arquivo datado: \`snapshots/registry-YYYY-MM-DD.json\`.  
3\. Commit no repo \`minilab-docs\` ou em repo separado \`minilab-snapshots\`.  
4\. Hash do snapshot vira \`tuple\_hash\` de um ato \`snapshot\_taken\` em \`ops.logline\_acts\`.  
\*\*Resultado:\*\* Snapshot citável e versionado.

\---

\#\# Família C — Entrada de informação no sistema

\#\#\# C1 — Capturar pensamento solto

\*\*Gatilho:\*\* Você tem uma ideia, observação, frase que pode ou não virar algo.  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* Project \`00 — Inbox\` no ChatGPT existe, ou tabela \`ops.inbox\` se preferir banco.  
\*\*Passos:\*\*  
1\. Manda a frase, sem formato, pro Inbox (chat no ChatGPT ou insert simples no banco).  
2\. \*\*Não classifica agora.\*\* O caminho é só capturar.  
3\. Em algum momento futuro, processo C2 triagem.  
\*\*Resultado:\*\* Pensamento preservado sem custo cognitivo.  
\*\*Próximo processo:\*\* C2 quando você decidir triar.

\#\#\# C2 — Triar Inbox

\*\*Gatilho:\*\* Inbox acumulou. Ritmo sugerido: 2x por semana.  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* Itens no Inbox.  
\*\*Passos:\*\*  
1\. Lê cada item.  
2\. Para cada um, decide: vira ato (A1/A2), vira ghost (A11), vira tarefa em outro projeto (C3), descarta.  
3\. Inbox fica vazio ou só com novos itens.  
\*\*Resultado:\*\* Inbox processado.

\#\#\# C3 — Rotear item pra Project apropriado

\*\*Gatilho:\*\* Triagem detectou que item pertence a outro Project.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Identifica Project destino (01 Daily, 02 Docs, 03 LogLine, 04 Workers, 05 Receipts, 06 Visuals, 07 Lab, etc.).  
2\. Abre chat novo nesse Project com primeira mensagem em formato constructor (template do \`chatgpt\_control\_plane\_implementation.md\`).  
3\. Cola conteúdo do item como input.  
4\. Marca item original no Inbox como \`routed\_to=\<project\>\`.  
\*\*Resultado:\*\* Item no lugar certo, contexto preservado.

\#\#\# C4 — Receber arquivo upload

\*\*Gatilho:\*\* Documento, screenshot, código que precisa entrar no sistema.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Decide se é evidência (acompanha ato), doutrina (vai pra repo), referência externa (cita mas não entra), ou descartável.  
2\. Se evidência: faz upload pra Supabase Storage no bucket \`evidence/YYYY/MM/\`, anota URI no \`metadata\_json\` do ato.  
3\. Se doutrina: vai pro repo apropriado, com commit message descritivo.  
4\. Se referência: anota URL e hash em algum lugar, não duplica conteúdo.  
5\. Se descartável: ignora, sem culpa.  
\*\*Resultado:\*\* Arquivo no lugar único e correto, ou descartado conscientemente.

\---

\#\# Família D — Operação dos workers (LABs/máquinas)

\#\#\# D1 — Verificar saúde das máquinas

\*\*Gatilho:\*\* Manhã, ou quando você desconfia que algo desligou.  
\*\*Ator:\*\* Você.  
\*\*Pré-condições:\*\* Tabela \`registry.runtimes\` populada com as LABs.  
\*\*Passos:\*\*  
1\. \`select name, status, updated\_at from registry.runtimes where kind \= 'lab';\`  
2\. Verifica se \`updated\_at\` é recente o suficiente (você define: 1h? 24h?).  
3\. Se alguma está stale, ghost D2 ou ação manual.  
\*\*Resultado:\*\* Lista de máquinas com status real.  
\*\*Falhas previstas:\*\* Nenhuma máquina reportando heartbeat ainda → todo o D1 fica inútil até D5 estar implementado.

\#\#\# D2 — Ghost de máquina desaparecida

\*\*Gatilho:\*\* Máquina não reportou no tempo esperado.  
\*\*Ator:\*\* Você ou processo automático.  
\*\*Passos:\*\*  
1\. Insert ato em \`ops.logline\_acts\` com \`who='minilab'\`, \`did='observed\_missing'\`, \`this='lab:\<nome\>'\`, \`status='ghost'\`.  
2\. Update \`registry.runtimes\` da LAB pra status \`ghost\`.  
3\. Decide: investigar (D3), aceitar offline temporário, ou retirar a LAB.  
\*\*Resultado:\*\* Ausência registrada estruturalmente.

\#\#\# D3 — Investigar LAB silenciosa

\*\*Gatilho:\*\* Ghost D2 disparado.  
\*\*Ator:\*\* Você fisicamente.  
\*\*Passos:\*\*  
1\. Vai até a máquina ou tenta SSH/ping.  
2\. Identifica causa: desligou, sem rede, processo morreu, disco cheio.  
3\. Corrige a causa.  
4\. Reativa o heartbeat.  
5\. Insert ato \`lab\_restored\` com causa em \`metadata\_json\`.  
\*\*Resultado:\*\* LAB de volta ou retirada conscientemente.

\#\#\# D4 — Submeter job pra worker (Worker Job Request)

\*\*Gatilho:\*\* Você precisa que uma máquina execute algo caro (inferência, processamento de vídeo, embedding).  
\*\*Ator:\*\* Você propõe, worker executa (quando worker bridge existir; até lá, manual).  
\*\*Passos:\*\*  
1\. Cria Worker Job Request no formato do \`chatgpt\_control\_plane\_implementation.md\`.  
2\. Até worker bridge existir: você SSH na máquina e roda manualmente.  
3\. Captura output e código de saída.  
4\. Insert ato em \`ops.logline\_acts\` com referência à evidência (stdout, stderr, artefatos).  
\*\*Resultado:\*\* Job executado com evidência.

\#\#\# D5 — Heartbeat de máquina (a construir)

\*\*Gatilho:\*\* A cada N minutos, máquina reporta que está viva.  
\*\*Ator:\*\* Daemon na máquina.  
\*\*Status atual:\*\* Não existe. \*\*Esse é o primeiro processo a construir tecnicamente.\*\*  
\*\*Forma esperada quando existir:\*\*  
1\. Daemon roda \`curl POST /rest/v1/logline\_acts\` com \`who='lab:\<nome\>'\`, \`did='heartbeat'\`, \`this='alive'\`, \`when=now()\`.  
2\. Repete a cada N minutos.  
\*\*Resultado:\*\* \`registry.runtimes.updated\_at\` sempre fresco quando máquina viva.

\---

\#\# Família E — Trabalho com LLMs

\#\#\# E1 — Iniciar conversa com LLM

\*\*Gatilho:\*\* Você quer ajuda de LLM para tarefa específica.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Identifica qual Project ChatGPT/Claude se aplica.  
2\. Abre nova conversa.  
3\. \*\*Cola o PATHS.md no início.\*\*  
4\. Cola o contexto mínimo da tarefa.  
5\. Diz a tarefa em uma frase.  
6\. Espera proposta.  
\*\*Resultado:\*\* LLM operando dentro dos trilhos.  
\*\*Falhas previstas:\*\* LLM ignora PATHS e propõe alternativa → você corta, lembra a regra, ou termina a conversa.

\#\#\# E2 — LLM propõe ato

\*\*Gatilho:\*\* Tarefa exige escrita no banco.  
\*\*Ator:\*\* LLM propõe, você aprova.  
\*\*Passos:\*\*  
1\. LLM gera JSON nine-slot completo.  
2\. LLM apresenta tuple\_hash e content\_hash computados, mostrando o JCS intermediário se você pedir.  
3\. Você lê. Aprova ou rejeita.  
4\. Se aprova, A2.  
\*\*Resultado:\*\* Ato escrito com aprovação humana viva.

\#\#\# E3 — LLM propõe mudança em doutrina

\*\*Gatilho:\*\* Tarefa de LLM revelou contradição, lacuna, ou melhoria em doc canônico.  
\*\*Ator:\*\* LLM propõe via PR no GitHub, você revisa.  
\*\*Passos:\*\*  
1\. LLM gera diff no repo apropriado (geralmente \`minilab-docs\`).  
2\. \*\*Não faz commit direto.\*\* Propõe como texto na conversa.  
3\. Você lê o diff.  
4\. Se aprova, você mesma faz o commit (ou PR se quiser preservar conversa).  
\*\*Resultado:\*\* Doutrina evolui com revisão humana sempre.

\#\#\# E4 — LLM sugere coisa fora dos trilhos

\*\*Gatilho:\*\* LLM sugere um caminho que não está no PATHS, ou sugere construir nova arquitetura quando deveria usar a existente.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. \*\*Interrompe imediatamente.\*\*  
2\. Responde: "isso não está nos PATHS. Use \[caminho X\] ou identifique que falta caminho e proponha definir um."  
3\. Se LLM persiste, encerra a conversa.  
\*\*Resultado:\*\* Trilhos preservados.

\#\#\# E5 — LLM revisa trabalho de outro LLM

\*\*Gatilho:\*\* Algo importante foi proposto por um LLM; você quer segunda opinião.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Copia a proposta original.  
2\. Abre conversa com LLM diferente (Claude se foi ChatGPT, GPT se foi Claude).  
3\. Cola PATHS \+ proposta \+ pede revisão honesta.  
4\. Compara as respostas.  
5\. Decide.  
\*\*Resultado:\*\* Decisão mais robusta. Diminui drift.

\---

\#\# Família F — Governança e mudança

\#\#\# F1 — Propor mudança em canon

\*\*Gatilho:\*\* Você quer mudar algo normativo no LogLine Foundation.  
\*\*Ator:\*\* Você, depois eventualmente revisores.  
\*\*Passos:\*\*  
1\. Escreve LIP no formato existente (LIP-0001 serve de molde).  
2\. Abre PR no repo \`governance\`.  
3\. Estado inicial: \`Draft\`.  
4\. Quando pronta pra discussão: \`Proposed\`.  
5\. Quando aceita por você (e revisores futuros): \`Accepted\`.  
6\. Implementa em outros repos referenciando o LIP número.  
\*\*Resultado:\*\* Mudança versionada e citável.

\#\#\# F2 — Promover experimento da Lab a doctrina

\*\*Gatilho:\*\* Experimento da Santo André Lab passou todas as fases do promotion ladder.  
\*\*Ator:\*\* Você como Governance Scribe.  
\*\*Passos:\*\*  
1\. Experimento está em \`scoped\_commit\`.  
2\. Conformance vectors foram escritos.  
3\. Probe rodou múltiplas vezes com sucesso.  
4\. Escreve governance note baseada no experimento.  
5\. Se afeta canon, vira LIP (F1).  
6\. Atualiza repo \`governance\` com a nota.  
\*\*Resultado:\*\* Conhecimento da Lab promovido a doutrina pública.

\#\#\# F3 — Emitir errata

\*\*Gatilho:\*\* Erro não-normativo descoberto em doc publicado (typo, link quebrado, exemplo errado).  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Identifica que é errata (não muda MUST/SHOULD/MAY).  
2\. Cria PR com correção.  
3\. Adiciona linha em \`ERRATA.md\` do repo afetado.  
4\. Commit referenciando errata, não nova versão.  
\*\*Resultado:\*\* Correção sem inflar versionamento.

\#\#\# F4 — Retirar Project ou repo

\*\*Gatilho:\*\* Algo deixou de fazer sentido.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Decide se arquiva (vira histórico) ou apaga.  
2\. Se arquiva: move pro Project \`99 — Archive\` ou marca repo como archived no GitHub.  
3\. Insert ato \`retired\_\<nome\>\` em \`ops.logline\_acts\`.  
4\. Atualiza \`registry.entities\` se aplicável (status \= retired).  
5\. Documenta razão em \`metadata\_json\` do ato.  
\*\*Resultado:\*\* Retirada limpa, rastreável, reversível.

\---

\#\# Família G — Ritmos (acontecem sozinhos, em cadência)

\#\#\# G1 — Ritual matinal (5 min)

\*\*Quando:\*\* Toda manhã.  
\*\*Passos:\*\*  
1\. Abre \`audit.v\_mobile\_today\` (B1).  
2\. Lê.  
3\. Escolhe 1 coisa pra mexer hoje.  
4\. Insert ato \`started\_day\` com \`this='\<a 1 coisa\>'\`.  
\*\*Resultado:\*\* Dia começa com foco e registro.

\#\#\# G2 — Ritual noturno (5 min)

\*\*Quando:\*\* Toda noite, antes de fechar laptop.  
\*\*Passos:\*\*  
1\. Lista mentalmente: o que terminou hoje?  
2\. Insert ato \`closed\_day\` com lista no \`metadata\_json\`.  
3\. Lista mentalmente: o que ficou aberto?  
4\. Para cada coisa aberta importante, ato com \`status='ghost'\`.  
\*\*Resultado:\*\* Dia fechado, ghosts capturados.

\#\#\# G3 — Revisão semanal (30 min, sextas)

\*\*Quando:\*\* Sexta de tarde.  
\*\*Passos:\*\*  
1\. Lê \`audit.v\_logline\_ghosts\` (B2).  
2\. Para cada ghost antigo, decide.  
3\. Lê receipts da semana (B3 com filtro de 7 dias).  
4\. Identifica padrões: o que repetiu, o que faltou.  
5\. Escreve nota livre no Project \`01 — Daily Control Plane\`.  
\*\*Resultado:\*\* Semana digerida.

\#\#\# G4 — Snapshot mensal

\*\*Quando:\*\* Primeiro dia do mês.  
\*\*Passos:\*\*  
1\. Executa B4 (snapshot do registry).  
2\. Sobe no repo.  
3\. Atualiza CHANGELOG do \`minilab-docs\` se houve mudanças.  
\*\*Resultado:\*\* Estado mensal versionado.

\#\#\# G5 — Revisão trimestral de PATHS

\*\*Quando:\*\* A cada 3 meses.  
\*\*Passos:\*\*  
1\. Lê todos os processos deste catálogo.  
2\. Pra cada um, marca: usado / não usado / mudou na prática.  
3\. Atualiza catálogo: remove o que não usa, formaliza o que mudou.  
4\. Versiona em \`minilab-docs/processes/v0.X.md\`.  
\*\*Resultado:\*\* Catálogo vivo, não fóssil.

\---

\#\# Família H — Construção de novo processo

\#\#\# H1 — Detectar que falta processo

\*\*Gatilho:\*\* Você se pega improvisando ou pedindo a LLM pra decidir como fazer algo.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Para a improvisação.  
2\. Anota no Inbox: "falta processo pra: X".  
3\. Volta à improvisação se urgente, mas marcado como ato com \`metadata.process\_missing=true\`.  
\*\*Resultado:\*\* Falta identificada estruturalmente.

\#\#\# H2 — Definir novo processo

\*\*Gatilho:\*\* Acumulou ≥3 ocorrências da mesma necessidade sem processo.  
\*\*Ator:\*\* Você.  
\*\*Passos:\*\*  
1\. Pega o gabarito (nome, gatilho, ator, pré-condições, passos, resultado, falhas, próximo).  
2\. Preenche com base no que você fez nas 3 ocorrências.  
3\. Adiciona ao catálogo na família apropriada.  
4\. Versiona o catálogo (v0.X+1).  
5\. Cola novo PATHS.md no topo das próximas conversas.  
\*\*Resultado:\*\* Processo novo cravado.

\#\#\# H3 — Promover improviso recorrente a processo

\*\*Gatilho:\*\* Você fez a mesma coisa não-cravada 3+ vezes.  
\*\*Passos:\*\* H2.

\---

\# Decisões pendentes que esse catálogo expõe

Esse catálogo, ao existir, deixa visível o que ainda não tem caminho:

1\. \*\*D5 — Heartbeat de máquinas.\*\* Não existe. É o primeiro buraco crítico.  
2\. \*\*A2/E2 — Cálculo de tuple\_hash/content\_hash pelo LLM.\*\* Hoje LLM pode errar. Precisa ou de ferramenta auxiliar (chamar engine via API), ou de você conferindo manualmente, ou de aceitar acto sem hash na fase inicial.  
3\. \*\*Adapter 1 (UI mínima pra escrita).\*\* Não existe. Por enquanto SQL Editor faz o papel.  
4\. \*\*B1 — \`audit.v\_mobile\_today\` existe ou só está planejada?\*\* Você sabe; eu não.  
5\. \*\*C1 — Inbox no banco ou no ChatGPT?\*\* Eu mantive ChatGPT como default, mas você pode preferir tabela.  
6\. \*\*F1 — Você sozinha como revisor de LIPs.\*\* Fase 1\. Quando segunda pessoa entrar, generaliza.

\---

Esse é o catálogo. Trinta e seis processos em oito famílias. Tudo que eu vi nos seus docs encaixa em uma dessas famílias. Coisas que você fizer no futuro encaixam também — e quando não encaixarem, vira H2.

Algumas coisas que eu \*\*deliberadamente não inclui\*\* porque achei que diluiriam:

\- Processos pra App Park (porque App Park ainda não tem nenhum app real)  
\- Processos pra Intelligence App (mesma razão)  
\- Processos pra integração com Cloudflare/Doppler/etc. — esses são detalhes técnicos de implementação dentro dos processos acima, não processos próprios.

Posso adicionar essas famílias se você quiser, ou outras que eu tenha esquecido.

Quatro perguntas pra cravar:

\*\*1.\*\* O formato dos processos serve? (Nome, gatilho, ator, pré-condições, passos, resultado, falhas, próximo.) Se você quer outro formato, eu reescrevo.

\*\*2.\*\* Faltou família? (Eu tenho A-H. Você pode querer uma família pra finanças, ou pra escrita de papers, ou pra saúde pessoal — Minilab é tua infra pra viver, então isso é legítimo.)

\*\*3.\*\* Algum processo aí está descrito de um jeito que \*\*te bloqueia\*\* em vez de te liberar? Sinaliza qual.

\*\*4.\*\* Onde esse catálogo mora? Sugestão: \`minilab-docs/processes/v0.1.md\`. Você cola, eu cravei, vira ponto fixo.

Quando você responder, eu refino e a gente tem \*\*a base\*\*. A partir dela, novos processos nascem como variação, não como improvisação.