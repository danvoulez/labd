# 12 — Minilab LogLine Practice Profile Decisions

**Status:** decision record / canon candidate  
**Layer:** Minilab practice profile over LogLine Foundation  
**Scope:** database handling, runtime envelopes, runtime registry, projections, auth/passport/visa, public positioning  
**Parent:** LogLine Foundation, unchanged  
**Position:** Minilab operationalizes LogLine without amending the parent canon

---

## 0. Public Motto

```txt
LogLine is loaded.
Minilab is configured.
Local practice is declared.
```

Extended form:

```txt
Start with pure LogLine.
Load Minilab practice.
Declare your own institution.
```

This is the public stance Minilab can defend.

Minilab does not claim that every operational rule below already belongs to LogLine Foundation.

Minilab declares a versioned practice profile over LogLine.

---

## 1. Core Decision

Minilab does not modify LogLine Foundation.

LogLine Foundation remains the parent grammar.

Minilab defines a practical institutional profile over LogLine for operating real systems: databases, runtimes, LABs, agents, passports, visas, Hermes workorders, projections, receipts, ghosts, and daily state.

```txt
LogLine is the grammar.
Minilab is the jurisdiction.
```

---

## 2. Rule of Non-Amendment

Minilab must not silently mutate the LogLine canon.

If Minilab introduces an operational rule not present in Foundation, it must be declared as Minilab practice.

Allowed:

```txt
Minilab practice requires runtime envelopes.
Minilab practice projects passports from entity registration acts.
Minilab practice projects visas from permission acts.
Minilab practice treats Supabase/Postgres as projection.
```

Forbidden:

```txt
Claiming these rules are Foundation canon unless they are actually accepted upstream.
Reopening Foundation every time Minilab needs an operational detail.
Confusing local institutional law with parent grammar.
```

---

## 3. Ontological Decision

There are no native business objects in Minilab core.

There are only admitted LogLine Acts and projections over them.

```txt
There are no native business objects.
There are only admitted LogLine Acts and projections over them.
```

Therefore:

```txt
passport
visa
receipt
evidence
probe
sale
stock
mandate
workorder
ghost
runtime_result
```

are not primitive object classes in the core.

They are projection semantics over LogLine Acts.

---

## 4. LogLine Act Decision

Every semantic write in Minilab is a LogLine Act.

The semantic core remains the nine slots:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

No Minilab practice rule adds a tenth semantic slot.

The domain may place whatever it needs inside `this`.

The engine must validate the act as a LogLine Act, but the engine does not need native knowledge of every business domain.

---

## 5. Runtime Envelope Decision

Every admitted or observed LogLine Act in Minilab practice carries a runtime envelope.

The envelope is not a new semantic slot.

The envelope is provenance and admission metadata around the act.

Minimum envelope:

```yaml
runtime_id:
engine_id:
run_id:
admission_status:
emitted_at:
observed_at:
tuple_hash:
content_hash:
previous_act_refs: []
```

The act says what happened.

The envelope says which runtime emitted, admitted, observed, or produced it.

```txt
Act is content.
Envelope is provenance.
```

---

## 6. Runtime Registry Decision

Minilab does not infer domain meaning from the act alone.

Minilab interprets an act through:

```txt
did + this + runtime_id + registry.runtimes
```

`registry.runtimes` describes what a runtime is known or allowed to emit, admit, observe, or execute.

Example runtime projection fields:

```yaml
runtime_id:
runtime_entity_ref:
engine_entity_ref:
lab_id:
status:
capabilities: []
accepted_dids: []
projection_hints: {}
evidence_policy: {}
authority_policy: {}
last_seen_at:
passport_act_ref:
latest_act_ref:
```

The runtime registry itself is a projection from LogLine Acts such as:

```txt
register_runtime
update_runtime_capabilities
retire_runtime
observe_runtime
```

It is not an independent source of truth.

```txt
Runtime registry is capability.
```

---

## 7. Projection Decision

The database does not own semantic truth.

The database projects admitted LogLine Acts.

```txt
The engine admits acts.
Projectors make worlds.
```

Projectors may:

```txt
name
classify
index
join
derive read models
enforce domain meaning
feed RLS
feed dashboards
feed reports
```

Projectors may not:

```txt
rewrite act meaning
invent missing evidence
turn projection into canon
close proof by view logic
bypass the act graph
```

---

## 8. Database Handling Decision

`ops.logline_acts` is the semantic write spine.

All domain tables are projections.

Canonical database posture:

```txt
ops.logline_acts
  admitted acts and runtime envelopes

registry.*
  projected identity, runtime, links, capabilities, visas, auth bindings

audit.*
  safe read projections

evidence.*
  projected observation/evidence semantics

receipts.*
  projected scoped-closure semantics

lab_observability.*
  projected LAB/runtime state

commerce.*, inventory.*, app schemas
  projected domain-specific worlds
```

Direct semantic writes into projection tables are forbidden unless they are produced by an admitted projector path from LogLine Acts.

Bootstrap/manual writes must be recorded as ghosts or transitional exceptions until converted into LogLine Acts.

---

## 9. Passport Decision

A passport is not a native object.

A passport is the projection of an admitted identity act.

Typical source act:

```txt
did = register_entity
```

A projected passport may represent:

```txt
human
agent
computer
LAB
engine
runtime
service
OAuth client
MCP tool
app
artifact
jurisdiction
```

The identity anchor is the content-addressed act reference.

```txt
passport_ref = act://sha256:<register_entity_act_hash>
```

A database row may have a UUID, but institutional identity is anchored in the act.

---

## 10. Visa Decision

A visa is not a native permission object.

A visa is the projection of an admitted permission act composed over a passport act.

Typical source act:

```txt
did = issue_visa
```

Required practice:

```txt
visa acts reference subject passport acts by content-addressed ref
visa acts declare grants, scope, constraints, and expiry/revocation semantics
visa acts may be revoked or superseded only by later LogLine Acts
```

A visa is permission.

A passport is identity.

A credential is only a presented authentication subject.

```txt
Credential proves bearer.
Passport proves institutional identity.
Visa proves scoped permission.
Workorder proves admitted execution.
Receipt proves scoped closure.
```

---

## 11. Auth Decision

Auth in Minilab is not `auth.users` alone, OAuth alone, JWT alone, API key alone, or service role alone.

Auth is a projection over admitted acts:

```txt
credential binding act
→ passport act
→ visa act
→ runtime/workorder/policy context
```

A credential binding is itself a LogLine Act.

Typical source act:

```txt
did = bind_auth_subject
```

It may bind:

```txt
Supabase auth user
OAuth client
agent key
LAB worker key
service account
MCP client
```

to a passport act.

RLS may use projected auth bindings and visas, but RLS is enforcement over projection, not the source of authority.

---

## 12. RLS Decision

RLS policies must not encode institutional meaning directly when that meaning belongs to the act graph.

RLS may consult projections such as:

```txt
registry.auth_bindings
registry.entities
registry.visas
registry.runtimes
authz.effective_permissions
```

but those projections must be traceable to LogLine Acts.

RLS answer shape:

```txt
credential presented
→ projected passport resolved
→ valid visa found
→ runtime/action/scope checked
→ allow / deny / ghost
```

If the required projection is missing, the correct institutional state is ghost, not silent allow.

---

## 13. Runtime Meaning Decision

Domain meaning is not decided by a universal factory type inside LogLine core.

Domain meaning is decided by projectors using:

```txt
did
this
runtime_id
registry.runtimes
prior act refs
local practice rules
```

Examples:

```txt
register_entity + constitutional-runtime
  → passport projection

issue_visa + constitutional-runtime
  → visa/authz projection

report_result + hermes-runtime
  → evidence/runtime_result projection

close_scope + receipt-review-runtime
  → receipt/closure projection

record_sale + commerce-runtime
  → sale projection

move_stock + inventory-runtime
  → inventory movement projection
```

The act carries content.

The runtime envelope carries provenance.

The runtime registry carries capability.

The projector carries meaning.

---

## 14. Receipt / Evidence / Probe Decision

Receipt, evidence, and probe are Minilab projection semantics.

They are not native Foundation objects.

In Minilab practice:

```txt
probe
  may be projected from acts that request or perform bounded contact with reality

evidence
  may be projected from acts that report observations, outputs, artifacts, hashes, or runtime responses

receipt
  may be projected from acts that close declared scope over evidence refs
```

A receipt is not “a special thing” outside LogLine.

A receipt is an admitted LogLine Act that a receipt projector accepts as scoped closure.

---

## 15. Hermes / Workorder Decision

A workorder is projection semantics over admitted LogLine Acts.

Hermes executes only admitted workorders.

Hermes never receives naked natural language as execution authority.

The lawful path is:

```txt
intent
→ LogLine candidate
→ engine admission
→ dispatch/workorder projection
→ visa/scope check
→ Hermes execution
→ runtime result act
→ evidence projection
→ receipt or ghost projection
```

Hermes is not authority.

Hermes is the execution hand.

---

## 16. Versioning Decision

Minilab practice is versioned.

A system may load:

```txt
logline.foundation@version
minilab.practice@version
local.overlay@version
```

The public model:

```txt
LogLine Foundation
  pure grammar

Minilab Practice Profile
  institutional operational configuration

Local Practice Profile
  local customization by a person, lab, company, project, or community
```

Minilab is a worked example, not the final destination.

---

## 17. Manifest Decision

A Minilab-compatible installation should be able to declare a practice manifest.

Conceptual shape:

```yaml
logline_practice_manifest:
  manifest_version: 1

  loads:
    foundation: logline.foundation@1.0.0
    profiles:
      - minilab.practice@1.0.0

  local_overlay:
    name:
    version:

  declares:
    runtimes: []
    projections: []
    offices: []
    rites: []
    projectors: []

  rules:
    runtime_envelope_required: true
    semantic_write: ops.logline_acts
    projection_source: admitted_logline_acts
```

This enables others to start with pure LogLine, load Minilab practice, and then declare their own institution.

---

## 18. Public Positioning Decision

Minilab is a LogLine practice laboratory.

It demonstrates how much can be built by studying and personalizing LogLine without falsifying the parent Foundation.

Public statement:

```txt
Minilab does not amend LogLine Foundation.
Minilab studies LogLine by operating it under real institutional pressure.
```

Alternative public statement:

```txt
Minilab is where LogLine stops being a notation and starts becoming institutional operating practice.
```

Minilab may publish:

```txt
what is Foundation
what is Minilab practice
what is local overlay
what is proven
what is ghost
what may be proposed upstream
```

---

## 19. Consequences

### Positive consequences

```txt
Foundation remains stable.
Minilab gains operational freedom.
Database semantics stay traceable to acts.
Auth becomes passport/visa projection over acts.
Runtimes become explicit and auditable.
Business domains can customize freely.
Others can load and fork practice profiles.
```

### Costs

```txt
Projectors must be disciplined.
Bootstrap rows must eventually trace to acts.
RLS depends on correct projections.
Runtime registry must be maintained.
Practice versioning must be explicit.
```

### Non-goals

```txt
Do not redesign LogLine Foundation.
Do not make Minilab universal canon.
Do not force all domains into native factory classes.
Do not pretend projections are semantic source.
```

---

## 20. Open Ghosts

```txt
minilab-practice-profile-not-promoted
runtime-envelope-schema-not-promoted
registry-runtimes-projection-unverified
passport-projector-not-implemented
visa-projector-not-implemented
auth-binding-projector-not-implemented
rls-over-projections-not-implemented
local-overlay-manifest-not-implemented
bootstrap-rows-not-traced-to-acts
```

---

## 21. Final Formulation

```txt
LogLine is loaded.
Minilab is configured.
Local practice is declared.

The act is content.
The envelope is provenance.
The runtime registry is capability.
The projector is meaning.
The database is projection.
The receipt is scoped closure.
The ghost is preserved absence.
```

Portuguese:

```txt
LogLine é carregada.
Minilab é configurado.
A prática local é declarada.

O act é conteúdo.
O envelope é proveniência.
O registry de runtimes é capacidade.
O projector é significado.
O banco é projeção.
O receipt é fechamento de escopo.
O ghost é ausência preservada.
```

