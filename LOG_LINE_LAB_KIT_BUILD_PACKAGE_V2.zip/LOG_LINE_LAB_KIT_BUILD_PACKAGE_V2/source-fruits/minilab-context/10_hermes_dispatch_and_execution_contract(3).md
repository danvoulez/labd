# 10 — Hermes Dispatch and Execution Contract

**Status:** canon candidate / execution seam draft  
**Layer:** Minilab dispatch, Hermes workorders, LAB execution, evidence return, projection boundary  
**Parents:** 01 — Minilab Founding Act; 02 — Organs and Jurisdictions; 03 — Source of Truth Map; 04 — LLM Offices; 05 — Morning State Ritual; 06 — Current State; 07 — Ghost Registry; 08 — Process Catalog; 09 — Vertical Runtime Doctrine; Authority / Power Doctrine; Evidence / Receipt Doctrine; Database Projection Canon; mini-llms.rs Spec  
**Evidence status:** doctrine-grounded, runtime-unverified  
**Runtime mutation:** none  
**World-touch:** none

---

## 0. Purpose

This document defines the seam where Minilab work leaves interpretation and may become execution.

It connects:

```txt
Process Catalog
→ Vertical Runtime Doctrine
→ Dispatch Packet
→ Authority classification
→ Hermes Workorder
→ LAB execution
→ Execution Report
→ Evidence Record
→ Receipt Candidate or Ghost
→ Current State projection
```

It exists to prevent:

```txt
free language becoming execution
operator confidence becoming dispatch
mini-LLM output becoming workorder
well-formed packet becoming authority
Hermes becoming governor
LAB identity becoming permission
stdout becoming receipt
provider success becoming closure
```

Hermes is the worker runtime.  
Hermes executes admitted work.  
Hermes does not govern.

---

## 1. Canonical Sentence

```txt
Hermes executes only admitted workorders:
dispatch packets describe work,
Constitutional Runtime admits shape,
Authority gates consequence,
Dan signs protected scope,
Hermes runs on LABs,
evidence returns,
receipts close narrowly,
and ghosts preserve what cannot honestly close.
```

Portuguese form:

```txt
Hermes executa apenas workorders admitidos:
dispatch packets descrevem trabalho,
o Constitutional Runtime admite a forma,
a Autoridade governa consequência,
Dan assina escopo protegido,
Hermes roda nos LABs,
a evidência retorna,
receipts fecham escopo,
e ghosts preservam o que não pode fechar honestamente.
```

Short form:

```txt
Dispatch describes.
Runtime admits.
Authority gates.
Hermes executes.
Evidence returns.
Receipts close.
Ghosts preserve.
```

---

## 2. Execution Law

```txt
Hermes receives workorders, not wishes.
```

No natural-language request may be sent directly to Hermes.

Correct path:

```txt
intent
→ process
→ dispatch packet
→ runtime admission
→ authority classification
→ Hermes workorder
→ LAB execution
→ evidence packet
→ receipt / ghost / projection
```

Forbidden path:

```txt
chat message
→ Hermes command
→ claimed completion
```

Hermes may execute:

```txt
read-only inspections
dry-run probes
verification commands
build/test commands
research capture jobs
local inference jobs
media processing jobs
artifact generation jobs
explicitly admitted apply operations
```

Hermes may not decide:

```txt
whether work should exist
whether a protected action is allowed
whether Dan approved consequence
whether evidence closes a claim
whether a receipt is valid
whether a ghost is resolved
```

---

## 3. Place in the Vertical Stack

```txt
Dan
  source of intent, consequence signer

Cockpit
  intake, routing, reports, decision preparation

Offices / Operators
  interpret within mandate

mini-llms.rs
  cognitive metabolism below operators

Process Catalog
  repeatable institutional trajectories

Dispatch Packet
  structured work proposal or work unit

Constitutional Runtime
  admission and semantic boundary

Authority / Gate / Window
  consequence and protected power boundary

Hermes
  worker runtime / execution hand

LABs
  physical-digital execution places

Evidence / Receipts / Ghosts
  proof, closure, and missing-proof discipline

Registry / Current State
  projection and visibility
```

Hermes sits below Authority and above LAB execution mechanics.

---

## 4. Core Objects

### 4.1 Process

A repeatable institutional trajectory from the Process Catalog.

A process defines:

```txt
trigger
organ
office
preconditions
runtime dynamics
evidence requirements
possible ghosts
next process
```

### 4.2 Dispatch Packet

A structured packet representing a proposed or prepared unit of work.

It may be read-only, advisory, code, research, publication, mutation, verification, or executable.

A dispatch packet is not execution.

### 4.3 Authority Classification

The decision about consequence surface.

Authority class may include:

```txt
read_only
advisory
proposed_mutation
code_draft
verification
research
publication_candidate
executable
protected
```

### 4.4 Hermes Workorder

An admitted executable subset of a dispatch packet.

Hermes workorders are bounded, typed, and evidence-bearing.

A workorder is not a receipt.

### 4.5 LAB

The physical or local execution environment.

LABs execute. They do not govern.

### 4.6 Execution Report

Hermes' structured return from execution.

It records what was attempted, where, when, with what status, and what evidence references exist.

### 4.7 Evidence Record

A persisted referenceable observation derived from execution, inspection, runtime contact, provider response, file hash, or manual observation.

Evidence supports closure. It is not closure.

### 4.8 Receipt Candidate

A proposed closure packet for review.

Receipt candidate is not a receipt.

### 4.9 Ghost

A structured absence blocking honest closure or execution.

---

## 5. Dispatch Packet Contract

### 5.1 Purpose

Dispatch packets make work explicit before execution.

They separate:

```txt
inspection
mutation
code manipulation
verification
intelligence
research
publication
communication
execution
```

This prevents a single attractive instruction from smuggling authority, execution, and proof closure into one step.

### 5.2 Conceptual Shape

```yaml
dispatch_version: minilab.dispatch.v0
packet_id:
correlation_id:
created_at:
created_by:

source_process:
  process_id:
  process_name:
  organ:
  office:
  jurisdiction:

packet_type:
  inspection | mutation | code | verification | intelligence | research | publication | communication | executable

authority_level:
  read_only | advisory | proposed_mutation | code_draft | verification | publish_candidate | executable | protected

objective:
input_sources: []
proposed_action:
expected_evidence: []
rollback_or_rectify:
required_human_check:
  none | Dan | reviewer | conference | external_authority

runtime_dynamics_ref:
logline_candidate_ref:
authority_packet_ref:

hermes:
  workorder_allowed: true | false
  suggested_target_lab:
  suggested_mode: read_only | dry_run | apply
  allowed_actions: []
  forbidden_actions: []

evidence_status:
  missing | planned | observed | evidence_captured | verified | ghost

receipt_path:
projection_targets: []
ghosts: []
notes:
```

### 5.3 Dispatch Packet Invariants

```txt
Every dispatch packet names its process.
Every dispatch packet names its authority level.
Every dispatch packet names expected evidence.
Every dispatch packet names rollback or rectify condition.
Every dispatch packet names required human check.
Executable dispatch must name Hermes boundary.
Protected dispatch must name Authority / Dan boundary.
Publication dispatch must name claim risk and rectification path.
```

### 5.4 Forbidden Dispatch Content

Dispatch packets must not contain:

```txt
raw secret values
unbounded shell strings without scope
implicit apply mode
hidden provider mutation
unreviewed public claim
receipt closure claim
broad verification claim
model output as evidence
Dan approval by implication
```

---

## 6. Dispatch Packet Types

### 6.1 Inspection

Read-only gathering of state or source material.

Examples:

```txt
repo tree inspection
LAB inventory inspection
recent events inventory
claim surface inspection
current state review
```

Default authority:

```txt
read_only
```

Hermes may run inspection only if admitted as read-only.

### 6.2 Mutation

Proposed change to structure, config, database, provider, repo, canon, jurisdiction, or public posture.

Default authority:

```txt
proposed_mutation
```

Requires review before execution.

### 6.3 Code

Draft code change, schema, migration, validator, generator, tool, adapter, or test.

Default authority:

```txt
code_draft
```

A code packet may produce a patch. It may not claim implementation success until verification evidence exists.

### 6.4 Verification

Commands or probes that check claims.

Default authority:

```txt
verification
```

May be executable if read-only or dry-run. Protected if it mutates, deploys, deletes, migrates, or touches external state.

### 6.5 Intelligence

Local/model-assisted analysis.

Default authority:

```txt
advisory
```

May use mini-llms.rs or local models. Output remains candidate.

### 6.6 Research

Internet or internal source research, citation capture, experiment review, or standards lookup.

Default authority:

```txt
research
```

Current factual claims require citations or evidence references.

### 6.7 Publication

Drafting or preparing public-facing material.

Default authority:

```txt
publish_candidate
```

Publication packets require claim class, risk, evidence, and rectify/delete condition.

### 6.8 Communication

Dan-facing, collaborator-facing, partner-facing, or operator-facing messages.

Default authority:

```txt
advisory
```

External or reputational messages may require Dan approval.

### 6.9 Executable

A dispatch packet intended to become a Hermes workorder.

Default authority:

```txt
executable
```

Executable dispatch must pass admission and authority classification.

---

## 7. Authority Levels

### read_only

May inspect without mutation.

Must still avoid secrets and false closure.

### advisory

May analyze, summarize, recommend, classify, or propose.

May not execute.

### proposed_mutation

May describe a mutation.

Requires review/admission before effect.

### code_draft

May draft code or schema.

Generated code is artifact, not delivery.

### verification

May run or request checks.

If checks mutate state, escalate.

### publish_candidate

May draft public material.

Publication requires claim risk review and Dan approval when needed.

### executable

May become Hermes workorder after admission.

Executable does not mean protected permission exists.

### protected

Requires Authority, Gate, Dan approval, execution window, passkey window, or receipt path as applicable.

---

## 8. Admission to Hermes Workorder

A dispatch packet may become Hermes workorder only when:

```txt
1. source process exists
2. runtime_dynamics block exists
3. packet_type allows execution
4. authority level is executable or admitted verification/code task
5. Constitutional Runtime admits shape and source
6. Authority classification does not deny
7. required Dan/reviewer approval exists if needed
8. target LAB is declared
9. power/wakefulness prerequisites are known or ghosted
10. secret policy is explicit
11. evidence requirements are explicit
12. rollback/rectify path is explicit
```

If any condition is missing, do not execute.

Open or carry a ghost.

---

## 9. Power / Electricity / Wakefulness Boundary

Hermes execution depends on physical substrate.

The minimum material prerequisites are:

```txt
machine exists
machine is powered
machine is awake or wakeable
network path exists if needed
runtime process exists or can be started under admitted scope
storage path exists
secrets/config are present by name when needed
```

Power is not authority.

Electricity makes execution possible.  
It does not make execution permitted.

If power/wakefulness is unknown:

```txt
lab-power-state-unknown
lab-sleep-prevention-unverified
host-runtime-unobserved
worker-bridge-absent
```

Hermes must not hide physical uncertainty behind a software-green status.

---

## 10. Hermes Workorder Contract

### 10.1 Purpose

A Hermes Workorder is the exact packet Hermes may execute.

It must be narrower than the dispatch packet.

A dispatch packet may contain discussion, risk, alternatives, publication context, review notes, and authority notes.

A workorder contains only admitted execution instructions.

### 10.2 Conceptual Shape

```yaml
workorder_version: hermes.workorder.v0
workorder_id:
correlation_id:
created_at:

source_dispatch_packet:
source_process:
source_logline_candidate:
authority_decision_ref:
execution_window_ref:

requested_by:
operator_office:
mode: read_only | dry_run | apply
command_class: normal | protected
risk_class: low | medium | high | critical

target:
  lab_id:
  runtime_id:
  host_ref:
  working_directory:

allowed_actions: []
forbidden_actions: []

inputs:
  refs: []
  inline: {}

commands:
  - command_id:
    kind: shell | http | sql | file | model | build | test | other
    argv: []
    env_policy:
      allow_secret_names: true
      allow_secret_values: false
    timeout_seconds:
    expected_exit_codes: []

expected_outputs: []
evidence_required:
  - kind:
    required: true | false
    redaction_required: true | false

artifact_policy:
  write_allowed: true | false
  output_root:
  retention:
  hashing_required: true

secret_policy:
  secret_values_allowed_in_logs: false
  redact_before_store: true

rollback_or_rectify:
receipt_profile:
projection_targets: []
```

### 10.3 Workorder Invariants

```txt
No workorder without source dispatch packet.
No workorder without target LAB/runtime.
No workorder without mode.
No apply workorder without authority path.
No protected workorder without required approval/window.
No workorder with secret values embedded.
No workorder without evidence requirements.
No workorder may claim receipt closure.
```

---

## 11. Execution Modes

### read_only

Reads state or files.

Forbidden:

```txt
writes
deletes
provider mutation
database semantic writes
network side effects except scoped GET/inspection
```

### dry_run

Plans or simulates effect without applying it.

Allowed:

```txt
migration plan
build plan
deploy plan
route plan
schema validation
fixture run
```

### apply

Performs effect.

Requires:

```txt
Authority admission
Dan approval when required
ExecutionWindow / PasskeyWindow when required
evidence path
rollback/rectify path
receipt profile
```

Default mode is never apply.

If mode is absent:

```txt
ghost: workorder-mode-missing
```

---

## 12. Command Discipline

Hermes commands must be bounded.

Preferred command form:

```yaml
argv:
  - cargo
  - test
  - -p
  - mini-llms
```

Avoid unbounded shell strings.

Allowed only with explicit reason:

```yaml
shell: "find docs -maxdepth 3 -type f | sort"
```

Forbidden by default:

```txt
rm -rf
curl | sh
printing env
cat .env
writing secrets to logs
unbounded recursive grep over secret areas
provider mutation without authority
silent database migration
deploy without gate
public route creation
```

---

## 13. Hermes Execution Report

### 13.1 Purpose

Execution Report is Hermes' return path.

It says what happened during execution.  
It does not close proof by itself.

### 13.2 Conceptual Shape

```yaml
report_version: hermes.execution_report.v0
report_id:
workorder_id:
correlation_id:

target_lab:
runtime_id:
started_at:
finished_at:
duration_ms:

status: observed | succeeded | failed | inconclusive | ghost | rejected
mode:

commands_run:
  - command_id:
    argv_redacted: []
    started_at:
    finished_at:
    exit_code:
    stdout_ref:
    stderr_ref:
    output_summary:
    secret_redacted: true

artifacts:
  - artifact_ref:
    kind:
    path_or_uri:
    hash:
    size_bytes:
    redaction_status:

observations:
  - kind:
    summary:
    evidence_ref:

ghosts:
  - ghost_key:
    why:
    next_probe:

runtime_claims:
  dispatcher_invoked:
  database_written:
  provider_called:
  receipt_emitted: false

next_act:
```

### 13.3 Report Status Meanings

#### observed

Execution contacted reality and produced observation, but success/closure is not asserted.

#### succeeded

The command satisfied its expected local condition.

This still does not mean broad system success.

#### failed

The command failed within declared scope.

#### inconclusive

Execution happened but did not decide the claim.

#### ghost

Execution could not honestly proceed or conclude because required runtime, source, config, authority, or evidence was missing.

#### rejected

Workorder was rejected before execution.

---

## 14. Evidence Return

Hermes reports must be transformed into Evidence Records when they matter.

Evidence records may include:

```txt
command_output
http_response
sql_result
file_hash
container_state
runtime_health
model_response
work_item_attempt
screenshot
manual_observation
```

Evidence record requirements:

```txt
scope
runtime
observed_at
producer
redaction flag
payload/artifact refs
hashes when available
secret_redacted=true
```

Evidence does not become receipt automatically.

---

## 15. Receipt Candidate Path

Receipt candidate may be prepared only after evidence exists.

Receipt candidate must state:

```txt
claim
scope
evidence refs
what this may close
what this does not close
conformance state
receipt profile
ghosts
reviewer
```

Forbidden receipt candidate claims:

```txt
the system works
the app is safe
production ready
all regressions absent
all users protected
future operations guaranteed
```

Allowed narrow claims:

```txt
this command ran with this exit code on this LAB at this time
this health endpoint returned this response
this migration dry-run produced this plan
this file was generated with this hash
this model call returned ReasoningOnlyNoContent
this candidate passed schema guard
```

---

## 16. Ghost Path

If execution cannot proceed or closure cannot be honest, open or carry a ghost.

Common Hermes ghosts:

```txt
workorder-mode-missing
target-lab-missing
lab-inventory-missing
lab-power-state-unknown
lab-sleep-prevention-unverified
host-runtime-unobserved
worker-bridge-absent
authority-decision-missing
execution-window-missing
dan-approval-missing
secret-policy-missing
evidence-return-missing
artifact-hash-missing
receipt-profile-missing
conformance-unobserved
```

Ghosts must name:

```txt
what is missing
why it blocks execution or closure
owner / organ
next act
closure condition
```

---

## 17. Database / Projection Boundary

Hermes may write operational execution records only through admitted paths.

Projection targets may include:

```txt
ops.logline_acts
registry.entities
registry.links
audit views
mini_llms.runtime_observations
mini_llms.logline_candidates
Evidence Registry
Ghost Registry
Receipt Registry
Current State
LAB Heartbeat Log
Work Request Ledger
```

Rules:

```txt
Database projection is not authority.
Semantic database writes require LogLine-shaped acts.
Hermes output may be evidence input.
Hermes output may not directly mutate semantic state without admitted projection path.
```

---

## 18. Relationship to mini-llms.rs

mini-llms.rs may be invoked by a Hermes workorder when local/private inference is the task.

Allowed Hermes mini-LLM jobs:

```txt
classify events
extract LogLineCandidate
summarize source packet
detect ghosts
suggest probes
produce Finding / GhostCandidate / DecisionRequest projections
evaluate profile samples
```

Forbidden Hermes mini-LLM jobs:

```txt
approve protected action
execute shell through model output
close receipt
promote canon
write semantic state directly
call model generation evidence
```

If mini-llms.rs returns:

```txt
ReasoningOnlyNoContent
```

Hermes must report it as observation, not failure theater and not candidate success.

---

## 19. Relationship to Process Catalog

Every executable process must point to this contract.

Process entries must declare:

```txt
dispatch required?
Hermes allowed?
mode default?
target LAB?
authority class?
evidence return?
closure path?
ghosts if missing?
```

A process without Hermes boundary must not accidentally become executable.

---

## 20. Relationship to Morning State

Morning State may report Hermes state:

```txt
pending workorders
last executions
failed/inconclusive runs
open Hermes ghosts
evidence returned
receipt candidates pending
LAB availability
```

Morning State may not say:

```txt
Hermes completed the system
Hermes verified the claim
Hermes closed receipt
```

unless receipts or scoped evidence support the exact claim.

---

## 21. Minimal First Vertical Slice

First lawful Hermes slice:

```txt
Process: LAB health check
Dispatch: verification/read-only packet
Admission: dry-run/read-only
Authority: normal, no protected command
Hermes Workorder: run harmless runtime observation
LAB: declared target
Evidence: command output / timestamp / redaction flag
Receipt: none unless scoped receipt path exists
Projection: Current State + Ghost Registry
```

Success criteria:

```txt
workorder accepted
command attempted or ghosted honestly
secret values not printed
evidence returned or missing evidence ghosted
no receipt closure claimed
Current State updated only as projection
```

---

## 22. Implementation Phases

### Phase 0 — Manual Dispatch

Dan manually executes work described by dispatch packets.

Hermes contract is used as checklist.

### Phase 1 — Hermes Dry-Run Worker

Hermes accepts only read-only and dry-run workorders.

No provider mutation, DB semantic write, deploy, route, or public action.

### Phase 2 — Evidence Store

Hermes writes evidence records or exports evidence packets through admitted path.

### Phase 3 — Verification / Build Jobs

Hermes runs tests, builds, schema validation, conformance checks.

### Phase 4 — Limited Apply

Apply mode allowed only with Authority, Dan approval, ExecutionWindow, rollback/rectify path, and receipt profile.

### Phase 5 — App Park Integration

Hermes becomes execution hand for admitted App Park operations.

No App Park deploy without App Park admission.

---

## 23. Security Rules

```txt
No secret values in workorders.
No secret values in logs.
No secret values in reports.
No secret values in receipts.
No secret values in browser payloads.
No env dump.
Secret names may appear when allowed.
Secret presence may be checked.
Secret value inspection is forbidden.
```

Hermes must redact before persistence.

If redaction cannot be guaranteed:

```txt
ghost: secret-redaction-unverified
```

---

## 24. Open Ghosts

```txt
hermes-runtime-not-implemented
hermes-workorder-schema-not-promoted
hermes-execution-report-schema-not-promoted
worker-bridge-absent
lab-inventory-missing
lab-heartbeat-missing
lab-power-state-unknown
host-runtime-unobserved
evidence-store-missing
receipt-registry-missing
execution-window-path-missing
hermes-secret-redaction-unverified
current-state-projection-path-unverified
```

---

## 25. Acceptance Criteria

This contract is accepted when:

```txt
1. Dan promotes or amends it.
2. Dispatch packets reference this contract.
3. Process Catalog entries declare Hermes boundary.
4. 09 Vertical Runtime Doctrine references this contract.
5. Hermes Workorder schema exists or is explicitly ghosted.
6. Hermes Execution Report schema exists or is explicitly ghosted.
7. First read-only/dry-run LAB probe is run or ghosted honestly.
8. Returned evidence is preserved without receipt overclaim.
9. Current State can display Hermes/LAB ghosts.
```

---

## 26. Final Formulation

```txt
Hermes is not the institution.
Hermes is the hand.

A hand does not decide what should be done.
A hand performs admitted work.
A hand returns traces.
A hand does not turn traces into proof.

Minilab decides through runtime and authority.
Hermes executes through workorders.
LABs provide body.
Evidence returns from reality.
Receipts close scope.
Ghosts keep the system honest.
Dan signs consequence.
```

Portuguese:

```txt
Hermes não é a instituição.
Hermes é a mão.

A mão não decide o que deve ser feito.
A mão executa trabalho admitido.
A mão devolve rastros.
A mão não transforma rastros em prova.

Minilab decide por runtime e autoridade.
Hermes executa por workorders.
LABs dão corpo.
Evidência volta da realidade.
Receipts fecham escopo.
Ghosts mantêm o sistema honesto.
Dan assina consequência.
```

