# 07 — Ghost Registry v0

## Status

`bootstrap projection / LogLine act graph view / founding state`

## 1. Purpose

Ghost Registry is the institutional projection of ghosts from the LogLine act graph.

A ghost is not an independently authored truth object.

A ghost is not a CRUD row.

A ghost is a LogLine-shaped act, or a derived state from a set of LogLine-shaped acts, whose closure is blocked by missing proof, authority, runtime, source, signer, context, schema, evidence path, or receipt path.

The Ghost Registry exists so missing proof remains visible, queryable, composable, and content-addressed.

## 2. Core Law

```txt
Ghost Registry is a projection of composable LogLine acts.
```

The source is the act graph.

The projection is only a view.

```txt
ops.logline_acts = act spine
content-addressed act refs = durable identity
registry.ghosts = current projection
audit.open_ghosts = readable view
Morning State = rendered report
```

Direct semantic writes to Ghost Registry are forbidden.

## 3. Canonical Basis

Every ghost-related state must reduce to the canonical nine-slot LogLine act shape:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

The act identity is content-addressed.

Minimum identity discipline:

```txt
tuple_hash = hash over the canonical nine-slot tuple
content_hash = hash over receipt/evidence/content as defined by Foundation profile
envelope_hash = transport wrapper hash, when applicable, outside semantic core
```

Minilab must not invent local hash semantics.

## 4. Act Graph, Not Lifecycle Row

Ghost state is derived from a graph of acts.

Examples:

```txt
act A: proposed operational claim
act B: routes A to if_doubt because evidence missing
act C: opens ghost for missing evidence, referencing A and B
act D: captures evidence, referencing C
act E: closes or narrows ghost, referencing C and D
```

The projection may show one current ghost record, but the record is a view over these acts.

The projection must preserve references to the underlying acts.

## 5. Source of Truth

Primary source:

```txt
ops.logline_acts
```

Primary identities:

```txt
tuple_hash
content_hash where applicable
receipt_hash / receipt_ref where applicable
evidence_ref where applicable
```

Projection surfaces:

```txt
registry.ghosts
audit.open_ghosts
GHOST_REGISTRY.md
Morning State ghost section
ChatGPT Ghost Keeper reports
```

Bootstrap source before database exists:

```txt
Current State v0
founding LogLine-shaped records
Dan-reviewed bootstrap ghost projections
```

Bootstrap projections must later reconcile into the act graph or be retired.

## 6. Database Principle

All semantic ghost state is projected from LogLine acts.

Forbidden:

```sql
insert into registry.ghosts (...) values (...);
update registry.ghosts set status = 'closed' where ...;
```

Correct:

```txt
insert LogLine-shaped act into ops.logline_acts
→ compute / store tuple_hash
→ reference prior acts by hash where needed
→ projector derives registry.ghosts
→ audit.open_ghosts renders current view
```

A ghost projection without source act refs is invalid except as explicitly marked bootstrap material.

## 7. Composability Rule

LogLine acts may reference other LogLine acts.

References should use content-addressed identities whenever possible.

Allowed reference forms:

```txt
this: ghost://sha256:<tuple_hash>
this: act://sha256:<tuple_hash>
confirmed_by: receipt://sha256:<content_hash>
confirmed_by: evidence://sha256:<content_hash>
if_doubt: ghost://sha256:<tuple_hash>
if_ok: act://sha256:<tuple_hash>
if_not: rejection://sha256:<tuple_hash>
aux.refs.caused_by: [act refs]
aux.refs.blocks: [act refs]
aux.refs.evidence: [evidence refs]
aux.refs.receipts: [receipt refs]
```

The nine slots remain canonical.

Auxiliary references may compose the graph, but may not redefine slot semantics.

## 8. Ghost-Relevant Act Verbs

Ghost-related acts may include:

```txt
open_ghost
carry_ghost
accept_ghost
block_ghost
narrow_ghost
merge_ghost
supersede_ghost
retire_ghost
close_ghost
reject_ghost
reject_ghost_closure
```

These are acts in the graph.

They are not direct mutations of the projection.

## 9. Example: Opening a Ghost

```yaml
who: morning_scribe
did: open_ghost
this: ghost://lab-heartbeat-missing
when: 2026-05-26T00:00:00Z
confirmed_by: act://sha256:<current_state_tuple_hash>
if_ok: project_to_registry_ghosts
if_doubt: request_missing_evidence
if_not: reject_duplicate_ghost
status: ghost
aux:
  ghost_key: lab-heartbeat-missing
  organ: LAB
  priority: P1
  blocks:
    - knowing whether LAB machines are alive over time
  missing:
    - heartbeat source
    - manual heartbeat log
  refs:
    caused_by:
      - act://sha256:<current_state_tuple_hash>
    evidence: []
    receipts: []
  owner: LAB Reporter / Dan
  next_act: define manual heartbeat log first, automation later
  closure_condition: heartbeat evidence act or receipt exists and references this ghost
```

The ghost is not identified by a database integer.

It is identified by its LogLine act tuple hash and any canonical ghost key projected from the act.

## 10. Example: Carrying a Ghost

```yaml
who: morning_scribe
did: carry_ghost
this: ghost://sha256:<open_ghost_tuple_hash>
when: 2026-05-27T08:00:00Z
confirmed_by: act://sha256:<morning_state_tuple_hash>
if_ok: keep_projected_open
if_doubt: request_dan_observation
if_not: mark_stale_or_rejected
status: ghost
aux:
  carried_from: act://sha256:<open_ghost_tuple_hash>
  reason: no heartbeat evidence supplied since last Morning State
  refs:
    related:
      - act://sha256:<morning_state_tuple_hash>
```

Carrying a ghost creates a new act that references the original ghost act.

The projection may keep one row current, but the history remains an act chain.

## 11. Example: Closing a Ghost

```yaml
who: dan
did: close_ghost
this: ghost://sha256:<open_ghost_tuple_hash>
when: 2026-05-27T09:00:00Z
confirmed_by: evidence://sha256:<heartbeat_evidence_content_hash>
if_ok: project_ghost_closed
if_doubt: keep_ghost_open
if_not: reject_closure
status: closed
aux:
  closes: act://sha256:<open_ghost_tuple_hash>
  closure_scope: manual heartbeat source exists and first observation was recorded
  does_not_close:
    - automated heartbeat
    - sleep prevention
    - worker bridge readiness
  refs:
    evidence:
      - evidence://sha256:<heartbeat_evidence_content_hash>
    receipts: []
```

Closing a ghost is another LogLine act that references the ghost act and the evidence or receipt that supports closure.

A ghost does not close because a report says it is solved.

## 12. Projection Shape

A projected ghost record may have this shape:

```yaml
ghost_projection_id:
ghost_key:
root_ghost_act_ref:
root_ghost_tuple_hash:
current_status:
current_status_act_ref:
latest_act_ref:
organ:
priority:
blocks:
missing:
evidence_state:
opened_at:
opened_by:
owner:
next_act:
closure_condition:
carried_by_act_refs:
blocked_by_act_refs:
caused_by_act_refs:
superseded_by_act_ref:
closed_by_act_ref:
evidence_refs:
receipt_refs:
related_act_refs:
last_projected_at:
projection_version:
bootstrap: true | false
```

This projection is read-oriented.

It may be used by:

- Morning State;
- Ghost Keeper;
- Evidence / Receipts / Ghosts;
- Cockpit;
- UI views;
- reports;
- audit views.

It may not become primary semantic truth.

## 13. Projection Invariants

A database-backed ghost projection must satisfy:

```txt
every projected ghost has root_ghost_act_ref or bootstrap=true
every projected ghost has root_ghost_tuple_hash or bootstrap=true
current_status is derived from the latest valid status act
closed ghosts reference a closing act
closed ghosts preserve closure scope
carried ghosts preserve the original ghost act ref
superseded ghosts point to the superseding act or ghost
priority changes are acts, not edits
receipt refs do not expand closure scope
evidence refs do not become receipts
```

## 14. Status Values

Projected ghost lifecycle states:

```txt
open
accepted
blocked
monitoring
closed
retired
superseded
rejected
```

### open

The ghost is active and blocks closure or continuity.

### accepted

The ghost is known and intentionally tolerated for now.

### blocked

The ghost cannot be resolved until another condition changes.

### monitoring

The ghost may be resolving but needs repeated observation.

### closed

A closing LogLine act has resolved the missing condition within declared scope.

### retired

The related work was retired, so the ghost no longer matters operationally.

### superseded

A newer ghost or act replaces this ghost for current operation while preserving the history.

### rejected

A proposed ghost was rejected as duplicate, invalid, wrongly scoped, or not actually blocking closure.

## 15. Bootstrap Mode

Before database projection exists, Ghost Registry may be maintained as a bootstrap projection.

Bootstrap mode rules:

```txt
1. Every listed ghost must be phrased as a future LogLine act.
2. Every ghost must name its future act did.
3. Every ghost must have a stable ghost_key.
4. Every ghost must later reconcile to tuple_hash identities or be retired.
5. No ghost is closed without a closure act or Dan-reviewed bootstrap closure record.
6. Bootstrap Ghost Registry is not an independent truth system.
```

Bootstrap fields:

```yaml
ghost_id:
future_act_did:
ghost_key:
future_this_ref:
organ:
priority:
status:
blocks:
missing:
evidence_state:
opened_at:
opened_from:
owner:
next_act:
closure_condition:
projection_note:
```

## 16. Founding Bootstrap Ghosts

The following ghosts are bootstrap projections.

They should later be materialized as LogLine acts, or retired, if Minilab moves into database-backed operation.

### P0 — Foundational blockers

```yaml
- ghost_key: founding-packet-not-promoted
  future_act_did: open_ghost
  future_this_ref: ghost://founding-packet-not-promoted
  organ: Constitution
  priority: P0
  status: open
  blocks: founding documents from becoming governing initial sources
  missing: Dan review and promotion decision
  closure_condition: promotion act exists or amendment decision is recorded

- ghost_key: promotion-record-missing
  future_act_did: open_ghost
  future_this_ref: ghost://promotion-record-missing
  organ: Constitution
  priority: P0
  status: open
  blocks: durable distinction between draft and promoted source
  missing: PROMOTION_RECORD v0 or equivalent promotion act
  closure_condition: promotion record or promotion LogLine act exists

- ghost_key: durable-canon-storage-undecided
  future_act_did: open_ghost
  future_this_ref: ghost://durable-canon-storage-undecided
  organ: Constitution
  priority: P0
  status: open
  blocks: stable long-term canonical source management
  missing: durable storage decision
  closure_condition: source-of-truth decision act exists

- ghost_key: lab-inventory-missing
  future_act_did: open_ghost
  future_this_ref: ghost://lab-inventory-missing
  organ: LAB
  priority: P0
  status: open
  blocks: all LAB state reporting and heartbeat planning
  missing: LAB_INVENTORY v0 as LogLine act or projection
  closure_condition: LAB inventory act(s) exist and are projected

- ghost_key: experiment-registry-missing
  future_act_did: open_ghost
  future_this_ref: ghost://experiment-registry-missing
  organ: Santo André Laboratory
  priority: P0
  status: open
  blocks: professional research continuity
  missing: experiment registry act(s) or projection
  closure_condition: first experiment registry act exists
```

### P1 — Daily operation blockers

```yaml
- ghost_key: cockpit-project-unconfirmed
  future_act_did: open_ghost
  organ: Cockpit
  priority: P1
  status: open
  blocks: stable ChatGPT jurisdiction for Morning State
  missing: confirmation that ChatGPT Project exists and is configured

- ghost_key: project-instructions-unconfirmed
  future_act_did: open_ghost
  organ: Cockpit
  priority: P1
  status: open
  blocks: stable behavior of ChatGPT cockpit
  missing: installed Project instructions

- ghost_key: morning-state-not-yet-run
  future_act_did: open_ghost
  organ: Cockpit
  priority: P1
  status: open
  blocks: proof that daily rite can operate
  missing: first completed Morning State report act

- ghost_key: home-routine-missing
  future_act_did: open_ghost
  organ: Casa
  priority: P1
  status: open
  blocks: household continuity planning
  missing: minimum weekly home routine act

- ghost_key: cleaning-plan-missing
  future_act_did: open_ghost
  organ: Casa
  priority: P1
  status: open
  blocks: desired house cleaning continuity
  missing: cleaning plan, cadence, responsible actor, confirmation method

- ghost_key: lab-heartbeat-missing
  future_act_did: open_ghost
  organ: LAB
  priority: P1
  status: open
  blocks: knowing whether LAB machines are alive over time
  missing: heartbeat source or manual heartbeat log

- ghost_key: lab-power-state-unknown
  future_act_did: open_ghost
  organ: LAB
  priority: P1
  status: open
  blocks: confidence that computers did not shut down or sleep
  missing: power / sleep observations

- ghost_key: research-track-not-selected
  future_act_did: open_ghost
  organ: Santo André Laboratory
  priority: P1
  status: open
  blocks: first professional research loop
  missing: first active research track or question

- ghost_key: registry-storage-undecided
  future_act_did: open_ghost
  organ: Registry / Estado
  priority: P1
  status: open
  blocks: stable entity/current-state management
  missing: decision on registry storage location

- ghost_key: workspace-project-state-unconfirmed
  future_act_did: open_ghost
  organ: Cockpit
  priority: P1
  status: open
  blocks: accurate operational use of ChatGPT Projects
  missing: actual list of created ChatGPT Projects and their instructions

- ghost_key: ghost-registry-bootstrap-only
  future_act_did: open_ghost
  organ: Evidence / Receipts / Ghosts
  priority: P1
  status: open
  blocks: database-backed ghost lifecycle
  missing: projection from ops.logline_acts
```

### P2 — Evidence / continuity blockers

```yaml
- ghost_key: home-execution-log-missing
  future_act_did: open_ghost
  organ: Casa
  priority: P2
  status: open
  blocks: knowing whether home tasks actually happened
  missing: HOME_EXECUTION_LOG as acts/projection

- ghost_key: maintenance-plan-missing
  future_act_did: open_ghost
  organ: Casa
  priority: P2
  status: open
  blocks: household maintenance continuity
  missing: recurring maintenance map

- ghost_key: lab-sleep-prevention-unverified
  future_act_did: open_ghost
  organ: LAB
  priority: P2
  status: open
  blocks: claim that machines will stay awake independently
  missing: configured and observed sleep-prevention mechanism

- ghost_key: host-runtime-unobserved
  future_act_did: open_ghost
  organ: LAB
  priority: P2
  status: open
  blocks: any claim of local execution readiness
  missing: host runtime observation

- ghost_key: authority-ledger-missing
  future_act_did: open_ghost
  organ: Authority
  priority: P2
  status: open
  blocks: durable record of decisions requiring authority
  missing: authority decision acts/projection

- ghost_key: evidence-registry-missing
  future_act_did: open_ghost
  organ: Evidence / Receipts / Ghosts
  priority: P2
  status: open
  blocks: referenceable observations
  missing: evidence registry / content-addressed evidence records

- ghost_key: receipt-registry-missing
  future_act_did: open_ghost
  organ: Evidence / Receipts / Ghosts
  priority: P2
  status: open
  blocks: closure tracking
  missing: receipt index / receipt candidate registry

- ghost_key: stable-entity-ids-missing
  future_act_did: open_ghost
  organ: Registry / Estado
  priority: P2
  status: open
  blocks: durable registry identity
  missing: stable entity ID scheme
```

### P3 — Later runtime / scaling blockers

```yaml
- ghost_key: worker-bridge-absent
  future_act_did: accept_ghost
  organ: LAB
  priority: P3
  status: accepted
  blocks: autonomous or remote worker execution
  missing: worker bridge design and implementation

- ghost_key: publication-path-unset
  future_act_did: accept_ghost
  organ: Santo André Laboratory
  priority: P3
  status: accepted
  blocks: long-term recognition path
  missing: publication / external recognition strategy

- ghost_key: command-envelope-not-active
  future_act_did: accept_ghost
  organ: Authority
  priority: P3
  status: accepted
  blocks: formal command mutation path
  missing: active CommandEnvelope contract in current source

- ghost_key: gate-path-missing
  future_act_did: accept_ghost
  organ: Authority
  priority: P3
  status: accepted
  blocks: execution admission runtime
  missing: gate decision path

- ghost_key: execution-window-missing
  future_act_did: accept_ghost
  organ: Authority
  priority: P3
  status: accepted
  blocks: protected execution with bounded permission
  missing: ExecutionWindow mechanism

- ghost_key: passkey-window-missing
  future_act_did: accept_ghost
  organ: Authority
  priority: P3
  status: accepted
  blocks: human-approved protected power window
  missing: PasskeyWindow mechanism

- ghost_key: real-receipt-path-missing
  future_act_did: accept_ghost
  organ: Evidence / Receipts / Ghosts
  priority: P3
  status: accepted
  blocks: audit-grade closure
  missing: Foundation-conformant receipt generation/storage/conformance path

- ghost_key: conformance-unobserved
  future_act_did: accept_ghost
  organ: Evidence / Receipts / Ghosts
  priority: P3
  status: accepted
  blocks: claims of conformance
  missing: conformance run output

- ghost_key: projection-path-missing
  future_act_did: accept_ghost
  organ: Registry / Estado
  priority: P3
  status: accepted
  blocks: database/app current-state projection
  missing: projection path from sources to view/database

- ghost_key: archive-location-undecided
  future_act_did: open_ghost
  organ: Archive
  priority: P3
  status: open
  blocks: reliable retirement/supersession storage
  missing: archive location decision

- ghost_key: supersession-map-missing
  future_act_did: open_ghost
  organ: Archive
  priority: P3
  status: open
  blocks: knowing which prior docs are current vs superseded
  missing: supersession map
```

## 17. Next Closure Targets

Do not try to close all ghosts.

Close or materialize in this order:

```txt
1. founding-packet-not-promoted
2. promotion-record-missing
3. lab-inventory-missing
4. home-routine-missing
5. experiment-registry-missing
6. morning-state-not-yet-run
```

These six turn Minilab from founding draft into first operational institution state.

## 18. Registry Maintenance Rule

Every Morning State must check this projection.

Morning State may:

- add ghost candidates;
- carry ghosts forward as new acts;
- propose closure acts;
- propose retirement acts;
- update next-act recommendations.

Morning State may not:

- close ghosts without a closing act or Dan-reviewed bootstrap closure;
- hide ghosts for readability;
- merge ghosts without preserving act refs;
- downgrade P0/P1 ghosts without Dan review;
- write semantic ghost state directly into a projection.

## 19. Future Database Projection Rule

When database-backed Minilab exists:

```txt
ops.logline_acts = source act graph
registry.ghosts = current ghost projection
audit.open_ghosts = readable view
```

Projection derives from content-addressed act references, not row mutation alone.

Required projection invariants:

```txt
every projected ghost has root_ghost_act_ref or bootstrap=true
every projected ghost has root_ghost_tuple_hash or bootstrap=true
every carry/close/supersede act references prior act hash
current_status is derived from latest valid graph act
closed ghosts preserve closure scope
receipt refs do not expand closure scope
evidence refs do not become receipts
```

## 20. Next Document

The next document should be one of:

```txt
08 — Promotion Record v0
```

or:

```txt
08 — LAB Inventory v0
```

Recommended next:

```txt
08 — Promotion Record v0
```

because founding sources need a promotion boundary before they become durable law.

