# 03 — Source of Truth Map

## Status

`draft fundador`

## 1. Purpose

This document defines which source governs each class of truth inside Minilab.

Its job is to prevent chats, files, memories, dashboards, database rows, provider responses, reports, and LLM outputs from competing as truth.

Minilab does not have one undifferentiated source of truth.

Minilab has a source of truth per class.

The question is never only:

```txt
Is this true?
```

The question is:

```txt
True according to which source, for which class, with what evidence state?
```

## 2. Core Law

```txt
Every truth class has one governing source.
Every governing source has a scope.
Every scoped truth has an evidence state.
Every missing source becomes a ghost.
```

Forbidden:

```txt
Chat said it, therefore true.
File exists, therefore canonical.
Database row exists, therefore authorized.
Provider returned success, therefore done.
Report sounds confident, therefore verified.
LLM remembers it, therefore canon.
```

Allowed:

```txt
This is current according to Current State.
This is canonical according to Constitution.
This is observed according to Evidence Registry.
This is closed according to Receipt Registry.
This is planned according to Home Ops Plan.
This is unknown because no governing source exists.
```

## 3. Evidence States

All truth claims must carry one of these states:

```txt
unknown
planned
declared
observed
evidence_captured
verified
ghost
retired
superseded
```

### unknown

No governing source or evidence is available.

### planned

A plan exists, but execution has not been observed.

### declared

A source declares the thing, but runtime/evidence has not confirmed it.

### observed

An observation exists, but it does not close the claim.

### evidence_captured

Evidence exists and is referenceable, but closure has not been judged.

### verified

A scoped receipt, conformance result, or accepted external authority supports the claim.

### ghost

A missing source, proof, authority, runtime, signature, or context prevents honest closure.

### retired

The thing is no longer active, but preserved historically.

### superseded

A newer promoted source replaces this source for current operation.

## 4. Source Classes

Minilab uses the following source classes:

1. Constitutional truth
2. Current operational state
3. Identity and registry truth
4. Authority truth
5. Evidence truth
6. Receipt truth
7. Research truth
8. Home operations truth
9. LAB operations truth
10. Config / secret truth
11. Work / request truth
12. Publication / external recognition truth
13. ChatGPT cockpit truth
14. Archive truth

---

# 5. Constitutional Truth

## Governing Source

```txt
doctrine/source/*
```

or, before repo materialization:

```txt
promoted constitutional documents mounted in the Constitution jurisdiction
```

## Governs

- what Minilab is;
- hierarchy;
- organs;
- authority vocabulary;
- evidence vocabulary;
- receipt discipline;
- database projection law;
- config law;
- App Park law;
- research doctrine.

## Does Not Govern

- live runtime state;
- whether a LAB is online;
- whether the house was cleaned;
- whether a command ran;
- whether a paper was accepted;
- whether a provider mutation succeeded.

## Promotion Rule

A constitutional document becomes governing only when Dan promotes it.

Before promotion, it is:

```txt
canon_candidate
```

After promotion, it is:

```txt
canon_current
```

## Ghosts

- canon document not promoted;
- conflicting doctrine;
- superseded doctrine still used;
- constitutional claim without source.

---

# 6. Current Operational State

## Governing Source

```txt
CURRENT_STATE
```

Initial form may be a promoted markdown document or a maintained ChatGPT ledger.

Future form may be database projection.

## Governs

- what currently exists;
- what is active;
- what is stale;
- what is blocked;
- what needs Dan;
- what is unknown;
- what was last observed.

## Does Not Govern

- canon;
- authority approval;
- receipt closure;
- hidden runtime truth;
- secret values.

## Update Rule

CURRENT_STATE may be updated from:

- Dan observation;
- evidence record;
- receipt;
- registry projection;
- verified external source;
- explicit ghost.

It must not be updated from:

- model confidence;
- memory alone;
- unstated assumption;
- provider success without evidence;
- report narrative without source.

## Ghosts

- current state not initialized;
- state stale;
- source missing;
- observed state not recorded;
- reported state without evidence.

---

# 7. Identity and Registry Truth

## Governing Source

```txt
REGISTRY
```

Initial form:

```txt
Registry / Estado ledger
```

Future form:

```txt
registry.entities
registry.links
```

## Governs

- what entities exist;
- stable IDs;
- names;
- kinds;
- roles;
- relations;
- lifecycle status;
- evidence status.

## Does Not Govern

- permission;
- execution;
- authority;
- proof closure;
- moral importance;
- operational readiness.

## Core Rule

```txt
Identity is addressability.
Identity is not authority.
```

## Ghosts

- missing identity;
- duplicate identity;
- unstable name;
- relation unclear;
- entity exists but evidence state unknown.

---

# 8. Authority Truth

## Governing Source

```txt
AUTHORITY_LEDGER
```

and future:

```txt
Authority Core decisions
Gate decisions
Execution windows
Passkey windows
Dan signatures
```

## Governs

- whether a proposed effect may proceed;
- command class;
- risk class;
- approval requirement;
- execution window;
- passkey requirement;
- Dan signature requirement;
- denial or ghost.

## Does Not Govern

- whether execution succeeded;
- whether evidence exists;
- whether receipt closed;
- whether provider returned success;
- whether runtime is healthy.

## Core Rule

```txt
Permission is not execution.
Execution is not closure.
```

## Ghosts

- missing policy;
- missing Dan approval;
- missing execution window;
- ambiguous risk;
- authority path absent;
- protected command attempted without gate.

---

# 9. Evidence Truth

## Governing Source

```txt
EVIDENCE_REGISTRY
```

Future form:

```txt
evidence records
artifact store
probe outputs
redacted command logs
HTTP observations
SQL observations
runtime health observations
```

## Governs

- what was observed;
- when it was observed;
- by whom or what;
- with what command/request/probe;
- what output was captured;
- what artifact reference exists;
- what was redacted.

## Does Not Govern

- closure by itself;
- broad truth;
- production safety;
- authority;
- canon.

## Core Rule

```txt
Observation is evidence input.
Observation is not closure.
```

## Ghosts

- no evidence record;
- evidence not referenceable;
- output redacted beyond usefulness;
- probe not tied to claim;
- evidence too narrow for claim.

---

# 10. Receipt Truth

## Governing Source

```txt
RECEIPT_REGISTRY
```

Future form:

```txt
Foundation-conformant receipt store
receipt index
conformance result
hash registry
```

## Governs

- what claim is closed;
- what scope is closed;
- what evidence supports closure;
- which receipt profile applies;
- hashes;
- conformance status;
- closure state.

## Does Not Govern

- claims outside declared scope;
- future behavior;
- production safety unless explicitly scoped;
- hidden facts;
- unobserved systems.

## Core Rule

```txt
Receipt closes only declared scope.
```

## Ghosts

- receipt store absent;
- conformance not run;
- hash profile unclear;
- receipt candidate mistaken for receipt;
- broad claim from narrow receipt.

---

# 11. Research Truth

## Governing Source

```txt
SANTO_ANDRE_EXPERIMENT_REGISTRY
```

and promoted:

```txt
technical notes
published papers
external review records
accepted submissions
citation records
```

## Governs

- research tracks;
- experiment status;
- thesis;
- invariants;
- probes;
- observations;
- scoped claims;
- publication candidates;
- external recognition.

## Does Not Govern

- operational readiness;
- production behavior;
- broad doctrine without promotion;
- international recognition without external evidence.

## Core Rule

```txt
No discovery without invariant, probe, evidence, scoped claim, and ghosts named.
```

## Ghosts

- thesis not falsifiable;
- invariant missing;
- probe missing;
- observation missing;
- external recognition unverified;
- paper draft mistaken for accepted work.

---

# 12. Home Operations Truth

## Governing Source

```txt
HOME_OPS_PLAN
HOME_EXECUTION_LOG
```

Future sources may include:

```txt
calendar entries
service provider confirmations
photos or manual observations
receipts / invoices
maintenance logs
```

## Governs

- household routines;
- cleaning plan;
- maintenance plan;
- supplies;
- scheduled service;
- execution confirmation;
- household ghosts.

## Does Not Govern

- LAB runtime;
- research truth;
- authority for protected technical action;
- proof beyond household scope.

## Core Rule

```txt
Plan is not execution.
```

## Ghosts

- no routine;
- no responsible actor;
- no execution confirmation;
- schedule unclear;
- recurring task unowned.

---

# 13. LAB Operations Truth

## Governing Source

```txt
LAB_INVENTORY
LAB_HEARTBEAT_LOG
LAB_HEALTH_RECORDS
```

Future sources may include:

```txt
host runtime checks
power/sleep checks
uptime observations
worker manifests
machine evidence records
```

## Governs

- machine identity;
- physical / digital host state;
- heartbeat;
- uptime;
- sleep state;
- worker readiness;
- health checks;
- operational incidents.

## Does Not Govern

- authority;
- permission;
- proof closure;
- research claims;
- provider truth.

## Core Rule

```txt
LABs execute. They do not govern.
```

## Ghosts

- no inventory;
- heartbeat missing;
- power state unknown;
- machine identity unstable;
- worker bridge absent;
- health check unobserved.

---

# 14. Config / Secret Truth

## Governing Source

```txt
DOPPLER
CONFIG_SCHEMA
CONFIG_DOCTOR
```

## Governs

- secret presence;
- config key existence;
- environment config;
- brakes;
- runtime material availability;
- provider credentials presence.

## Does Not Govern

- authority;
- institutional meaning;
- receipt closure;
- permission to mutate;
- provider truth.

## Core Rule

```txt
Doppler supplies material.
Doppler does not authorize consequence.
```

## Ghosts

- config schema missing;
- secret presence unobserved;
- brake unknown;
- secret leaked;
- environment name ambiguous;
- config mistaken for authority.

---

# 15. Work / Request Truth

## Governing Source

```txt
WORK_REQUEST_LEDGER
```

Initial form may be ChatGPT thread state.
Future form may be issue tracker, database table, or queue.

## Governs

- what Dan asked;
- where it was routed;
- who or what owns it;
- status;
- blockers;
- next act;
- evidence requirement;
- closure requirement.

## Does Not Govern

- execution success;
- proof closure;
- authority by itself;
- canon.

## Core Rule

```txt
A request is not execution.
```

## Ghosts

- request not captured;
- owner missing;
- jurisdiction unclear;
- next act missing;
- completion claimed without evidence.

---

# 16. Publication / External Recognition Truth

## Governing Source

```txt
EXTERNAL_RECOGNITION_REGISTRY
```

Valid sources include:

```txt
DOI
conference acceptance
journal acceptance
standards body record
institutional correspondence
public citation
review record
collaboration agreement
published artifact URL
```

## Governs

- publication status;
- accepted papers;
- external review;
- institutional recognition;
- citations;
- standards participation;
- collaborations.

## Does Not Govern

- internal proof;
- runtime behavior;
- broad correctness;
- authority inside Minilab.

## Core Rule

```txt
Recognition requires external record.
```

## Ghosts

- paper draft not submitted;
- submission status unknown;
- claimed recognition without record;
- citation unverified;
- collaboration informal.

---

# 17. ChatGPT Cockpit Truth

## Governing Source

```txt
ChatGPT Project threads and mounted files
```

## Governs

- active conversation context;
- working interpretation;
- temporary role behavior;
- draft reports;
- routing suggestions;
- questions to Dan.

## Does Not Govern

- canon by itself;
- live runtime state;
- receipt closure;
- external recognition;
- secret truth;
- database truth;
- execution success.

## Core Rule

```txt
ChatGPT is cockpit, not canon.
```

## Ghosts

- memory drift;
- missing mounted source;
- thread state stale;
- model occupies office without mandate;
- answer not promoted.

---

# 18. Archive Truth

## Governing Source

```txt
ARCHIVE
```

## Governs

- retired documents;
- superseded plans;
- historical decisions;
- rejected candidates;
- inactive Projects;
- old reports.

## Does Not Govern

- current state;
- active canon unless explicitly revived;
- current authority;
- current operations.

## Core Rule

```txt
Archived material preserves history. It does not govern current action.
```

## Ghosts

- superseded status unclear;
- archived material used as current;
- historical context missing;
- old assumption revived without review.

---

# 19. Conflict Resolution

When two sources conflict, use this order:

```txt
1. Receipt truth governs scoped closure.
2. Evidence truth governs what was observed.
3. Authority truth governs whether action may proceed.
4. Constitutional truth governs meaning and law.
5. Registry truth governs identity and projection.
6. Current State governs latest operational view.
7. Research Registry governs experiment state.
8. Home / LAB logs govern their local operational states.
9. ChatGPT governs only working cockpit context.
10. Archive governs only historical material.
```

If conflict remains:

```txt
state = ghost
```

and route to Evidence / Receipts / Ghosts.

---

# 20. Update Rights

## Dan May Update Directly

- founding declarations;
- promoted canon;
- Dan manual decisions;
- risk acceptance;
- consequence signature;
- jurisdiction creation;
- source of truth promotion.

## ChatGPT May Prepare

- reports;
- drafts;
- routing suggestions;
- ghost records;
- source maps;
- decision packets;
- registry candidates;
- research records;
- home plans;
- LAB checklists.

## ChatGPT May Not Promote Alone

- canon;
- receipts;
- verified status;
- external recognition;
- authority approval;
- execution closure;
- source of truth changes.

## Runtime May Update Through Evidence

- observations;
- probe results;
- health checks;
- command outputs;
- status records;
- evidence records.

## Database May Project

- current state;
- registry entities;
- relations;
- indexes;
- views;
- audit surfaces.

Database projection is not original authority.

---

# 21. Minimum Initial Sources

At foundation, these sources must exist conceptually:

```txt
MINILAB_FOUNDING_ACT
ORGANS_AND_JURISDICTIONS
SOURCE_OF_TRUTH_MAP
CURRENT_STATE
GHOST_REGISTRY
MORNING_STATE_RITUAL
LLM_OFFICES
```

They may initially live in ChatGPT canvas or Project files.

They should later be promoted to durable storage.

---

# 22. Source Promotion Rule

A draft becomes a source only when Dan promotes it.

Promotion record:

```txt
Source:
Class:
Scope:
Promoted by:
Promoted at:
Replaces:
Evidence state:
Ghosts:
Next review:
```

No document promotes itself.

No LLM promotes a document by writing confidently.

---

# 23. Next Document

The next founding document is:

```txt
04 — LLM Offices
```

It must define how LLMs occupy roles without owning authority, truth, office identity, or closure.

