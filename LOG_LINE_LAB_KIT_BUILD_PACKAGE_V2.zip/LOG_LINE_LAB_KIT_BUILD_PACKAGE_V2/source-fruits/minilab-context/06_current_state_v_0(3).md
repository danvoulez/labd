# 06 — Current State v0

## Status

`initial state / zero operational state`

## 1. Purpose

Current State is the first operational state source of Minilab.

It records what is known now, what is unknown, what has only been declared, what has evidence, what remains ghost, and what needs Dan.

Current State is not canon.
Current State is not a receipt.
Current State is not proof by itself.

Current State is the current operational view.

Its job is to prevent Minilab from restarting from memory, mood, scattered files, or LLM interpretation.

## 2. Current State Law

```txt
If it is not recorded here or in a named source, it is not current state.
If it has no evidence, it is not verified.
If it blocks honest closure, it is a ghost.
```

Allowed states:

```txt
unknown
planned
declared
observed
evidence_captured
verified
ghost
retired
superseded
```

Default state at foundation:

```txt
unknown
```

## 3. Timestamp

```txt
created_at: 2026-05-26
created_by: Dan / ChatGPT Cockpit
state_scope: Minilab foundation v0
```

## 4. Overall State

```txt
state: founding
operational_level: zero operational state
primary_cockpit: ChatGPT
institution_declared: draft
sources_promoted: none yet
runtime_verified: false
receipt_path_exists: false
evidence_store_exists: false
```

Summary:

Minilab is in founding state. The institutional intent, organs, source map, LLM office discipline, and Morning State ritual have been drafted. No operational runtime, heartbeat, receipt store, evidence store, database projection, App Park, or autonomous execution path is verified.

This is not a failure. This is the first honest state.

---

# 5. Founding Sources

## 5.1 Drafted Sources

```txt
01 — Minilab Founding Act
02 — Organs and Jurisdictions
03 — Source of Truth Map
04 — LLM Offices
05 — Morning State Ritual
```

Evidence state:

```txt
declared
```

Promotion state:

```txt
not yet promoted by Dan
```

Ghosts:

```txt
founding-packet-not-promoted
promotion-record-missing
```

Next:

Dan reviews and either promotes, amends, or rejects the founding packet.

## 5.2 Missing Initial Sources

```txt
CURRENT_STATE v0
GHOST_REGISTRY v0
LAB_INVENTORY v0
HOME_OPS_PLAN v0
SANTO_ANDRE_EXPERIMENT_REGISTRY v0
DAN_MANUAL_ACTIONS v0
PROMOTION_RECORD v0
```

Evidence state:

```txt
ghost
```

Next:

Create these sources in operational order.

---

# 6. Organ States

## 6.1 Constitution

```txt
state: declared
evidence_state: declared
primary_sources: founding packet 01–05 + uploaded canon documents
promoted: false
```

Known:

- Minilab is intended as Dan’s long-lived operational institution.
- ChatGPT is the first cockpit, not the institution itself.
- Organs have been drafted.
- Source classes have been drafted.
- LLM office discipline has been drafted.

Unknown:

- Which documents Dan has formally promoted.
- Where durable canonical storage will live.
- Whether a repo is currently active.

Ghosts:

```txt
canon-promotion-missing
durable-canon-storage-undecided
```

Next:

Create promotion record for founding packet.

---

## 6.2 Cockpit

```txt
state: declared
evidence_state: declared
primary_surface: ChatGPT
operational: not yet proven
```

Known:

- ChatGPT is selected as first cockpit.
- Morning State ritual has been drafted.
- LLM offices have been drafted.

Unknown:

- Whether a ChatGPT Project has been created for Cockpit / Morning State.
- Whether Project instructions have been installed.
- Whether any mounted files exist.
- Whether a daily rite has run more than once.

Ghosts:

```txt
cockpit-project-unconfirmed
project-instructions-unconfirmed
morning-state-not-yet-run
```

Next:

Dan creates or confirms the first Cockpit jurisdiction when ready.

---

## 6.3 Casa

```txt
state: unknown
evidence_state: unknown
```

Known:

- Casa is a founding organ.
- Casa governs domestic continuity: cleaning, maintenance, supplies, household schedule, and recurring obligations.

Unknown:

- Current household routine.
- Cleaning schedule.
- Maintenance obligations.
- Supply state.
- Execution confirmation mechanism.

Ghosts:

```txt
home-routine-missing
home-execution-log-missing
cleaning-plan-missing
maintenance-plan-missing
```

Next:

Create HOME_OPS_PLAN v0.

Minimum required fields:

```txt
weekly routine
monthly routine
urgent maintenance
recurring obligations
confirmation method
```

---

## 6.4 LAB

```txt
state: unknown
evidence_state: unknown
```

Known:

- LAB is a founding organ.
- LAB governs physical-digital execution environments.
- LABs execute; they do not govern.

Unknown:

- Which machines physically exist.
- Which machines are powered on.
- Which machines sleep or shut down.
- Whether heartbeat exists.
- Whether host runtime exists.
- Whether any worker bridge exists.

Ghosts:

```txt
lab-inventory-missing
lab-heartbeat-missing
lab-power-state-unknown
lab-sleep-prevention-unverified
host-runtime-unobserved
worker-bridge-absent
```

Next:

Create LAB_INVENTORY v0.

Minimum required fields per machine:

```txt
lab_id
human_name
machine_type
location
intended_role
power_state_known
sleep_risk
heartbeat_exists
last_observed
notes
```

---

## 6.5 Santo André Laboratory

```txt
state: declared
evidence_state: declared
```

Known:

- Santo André Laboratory is the research organ.
- Its method is: intuition → thesis → invariant → probe → observation → evidence → scoped claim → doctrine/system.
- It must not let beauty outrun evidence.

Unknown:

- First active research track.
- First experiment record in this new institution state.
- Current invariant under test.
- Current probe.
- Publication path.

Ghosts:

```txt
research-track-not-selected
experiment-registry-missing
first-experiment-missing
probe-missing
publication-path-unset
```

Next:

Create SANTO_ANDRE_EXPERIMENT_REGISTRY v0.

Minimum first record:

```txt
track
question
thesis
invariant_candidate
probe_candidate
evidence_state
ghosts
next_research_act
```

---

## 6.6 Authority

```txt
state: declared
evidence_state: declared
operational: false
```

Known:

- Authority is a founding organ.
- It separates intent, candidate, request, decision, execution window, effect, evidence, and closure.
- Dan remains signer of consequence.

Unknown:

- Whether any Authority Ledger exists.
- Whether CommandEnvelope schema exists in active source.
- Whether gate decision path exists.
- Whether PasskeyWindow or ExecutionWindow exists.

Ghosts:

```txt
authority-ledger-missing
command-envelope-not-active
gate-path-missing
execution-window-missing
passkey-window-missing
```

Next:

Create DAN_MANUAL_ACTIONS v0 before implementing any authority runtime.

---

## 6.7 Evidence / Receipts / Ghosts

```txt
state: declared
evidence_state: declared
operational: partial / conceptual
```

Known:

- Evidence, receipt, and ghost discipline exists in doctrine.
- Reports are not receipts.
- Ghosts preserve missing proof.

Unknown:

- Whether a Ghost Registry exists.
- Whether an Evidence Registry exists.
- Whether a Receipt Registry exists.
- Whether any real receipt exists.
- Whether conformance has ever run in this institution context.

Ghosts:

```txt
ghost-registry-missing
evidence-registry-missing
receipt-registry-missing
real-receipt-path-missing
conformance-unobserved
```

Next:

Create GHOST_REGISTRY v0 using the ghosts listed in Current State.

---

## 6.8 Registry / Estado

```txt
state: declared
evidence_state: declared
operational: this document initializes it
```

Known:

- Registry / Estado governs what exists and its evidence status.
- Current State v0 is the first operational state source.

Unknown:

- Stable IDs for entities.
- Registry storage location.
- Whether future projection will be markdown, repo, database, or hybrid.

Ghosts:

```txt
registry-storage-undecided
stable-entity-ids-missing
projection-path-missing
```

Next:

Create minimal entity list after Dan confirms machine inventory and durable source location.

---

## 6.9 Archive

```txt
state: declared
evidence_state: declared
```

Known:

- Archive preserves retired, superseded, inactive, and historical material.

Unknown:

- Archive location.
- Supersession rules for current uploaded documents.
- What prior material is current vs superseded.

Ghosts:

```txt
archive-location-undecided
supersession-map-missing
```

Next:

Create archive rule only after source map is promoted.

---

# 7. Current Known Entities

## 7.1 Human

```txt
id: dan
name: Dan
kind: human founder
status: declared
evidence_state: declared
role: founder, sovereign operator, consequence signer
```

Ghosts:

```txt
none for identity in this context
```

## 7.2 Institution

```txt
id: minilab
name: Minilab
kind: operational institution
status: founding
evidence_state: declared
```

Ghosts:

```txt
founding-packet-not-promoted
```

## 7.3 Cockpit

```txt
id: chatgpt-cockpit
name: ChatGPT Cockpit
kind: cockpit
status: declared
evidence_state: declared
```

Ghosts:

```txt
workspace-project-state-unconfirmed
```

## 7.4 LAB Machines

```txt
state: unknown
entities: none registered
```

Ghosts:

```txt
lab-inventory-missing
```

## 7.5 Casa

```txt
id: casa
name: Casa
kind: physical / domestic domain
status: declared
evidence_state: declared
```

Ghosts:

```txt
home-routine-missing
```

## 7.6 Santo André Laboratory

```txt
id: santo-andre-laboratory
name: Santo André Laboratory
kind: research organ
status: declared
evidence_state: declared
```

Ghosts:

```txt
experiment-registry-missing
```

---

# 8. Current Ghosts

Initial ghost list:

```txt
founding-packet-not-promoted
promotion-record-missing
canon-promotion-missing
durable-canon-storage-undecided
cockpit-project-unconfirmed
project-instructions-unconfirmed
morning-state-not-yet-run
home-routine-missing
home-execution-log-missing
cleaning-plan-missing
maintenance-plan-missing
lab-inventory-missing
lab-heartbeat-missing
lab-power-state-unknown
lab-sleep-prevention-unverified
host-runtime-unobserved
worker-bridge-absent
research-track-not-selected
experiment-registry-missing
first-experiment-missing
probe-missing
publication-path-unset
authority-ledger-missing
command-envelope-not-active
gate-path-missing
execution-window-missing
passkey-window-missing
ghost-registry-missing
evidence-registry-missing
receipt-registry-missing
real-receipt-path-missing
conformance-unobserved
registry-storage-undecided
stable-entity-ids-missing
projection-path-missing
archive-location-undecided
supersession-map-missing
workspace-project-state-unconfirmed
```

Priority ghosts:

```txt
1. founding-packet-not-promoted
2. lab-inventory-missing
3. home-routine-missing
4. experiment-registry-missing
5. ghost-registry-missing
6. durable-canon-storage-undecided
```

---

# 9. Needs Dan

Dan actions required:

```txt
1. Review founding packet 01–05.
2. Decide whether to promote the founding packet as initial Minilab source.
3. Decide durable storage location for founding sources.
4. List physical LAB machines.
5. Define minimum home routine.
6. Select first active Santo André research track.
7. Confirm whether ChatGPT Project jurisdictions should be created now or after source promotion.
```

No protected runtime action is required yet.

No coding is required yet.

No external automation is required yet.

---

# 10. Next Acts

## Act 1 — Promote or Amend Founding Packet

```txt
organ: Constitution
owner: Dan
evidence needed: review of documents 01–05
expected output: PROMOTION_RECORD v0 or amendment notes
```

## Act 2 — Create Ghost Registry v0

```txt
organ: Evidence / Receipts / Ghosts
owner: Ghost Keeper / Dan review
evidence needed: Current State v0 ghost list
expected output: GHOST_REGISTRY v0
```

## Act 3 — Create LAB Inventory v0

```txt
organ: LAB
owner: Dan
evidence needed: list of physical machines
expected output: LAB_INVENTORY v0
```

## Act 4 — Create Home Ops Plan v0

```txt
organ: Casa
owner: Dan
evidence needed: minimum weekly domestic routine
expected output: HOME_OPS_PLAN v0
```

## Act 5 — Create Santo André Experiment Registry v0

```txt
organ: Santo André Laboratory
owner: Research Registrar / Dan review
evidence needed: first research track or question
expected output: SANTO_ANDRE_EXPERIMENT_REGISTRY v0
```

---

# 11. Promote

Promotion candidates:

```txt
01 — Minilab Founding Act
02 — Organs and Jurisdictions
03 — Source of Truth Map
04 — LLM Offices
05 — Morning State Ritual
06 — Current State v0
```

Promotion state:

```txt
candidate
```

Dan action:

```txt
review / amend / promote
```

---

# 12. Closing State

Current State v0 establishes:

```txt
Minilab is founded in draft state.
The institution has declared organs.
ChatGPT is declared as first cockpit.
No runtime truth is verified.
No LAB is observed.
No home routine is confirmed.
No research experiment is registered.
No evidence or receipt store exists.
Ghosts are explicit.
The next act is promotion review and first operational inventories.
```

Status:

```txt
founding / draft / zero operational state
```

Evidence:

```txt
founding documents drafted in cockpit
```

Ghosts:

```txt
listed above
```

Next act:

```txt
Create 07 — Ghost Registry v0 or promotion record, depending on Dan's choice.
```

