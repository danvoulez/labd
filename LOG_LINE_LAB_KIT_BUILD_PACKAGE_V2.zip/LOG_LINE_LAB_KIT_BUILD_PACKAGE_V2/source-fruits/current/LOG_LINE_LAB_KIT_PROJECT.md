# LogLine Lab Kit

## Project Definition and Build Pack v0

**Project name:** `logline-lab-kit`  
**Build pack:** `LABKIT_V0_BUILD_PACK`  
**Status:** buildable architecture, v0 target  
**Purpose:** externalize the full architecture into one project that can be built without reopening naming, ownership, or product-boundary debates.

---

## 0. One Sentence

**LogLine Lab Kit is an installable Act machine.**

It lets a person or system create a Lab that can emit Acts, validate them, store them, project them, block them, attach evidence, prepare scoped receipts, load packs and profiles, call workers, expose CLI/API/MCP surfaces, and produce reports.

It is not a dashboard.  
It is not Dan's private Minilab.  
It is not Santo André.  
It is not Manhattan.  
It is not a pile of scripts.  
It is not a philosophy document.

It is the generic installable machinery that makes a LogLine Lab real.

---

## 1. Core Rule

The project has exactly one root:

```txt
logline-lab-kit
```

Everything else is subordinate:

```txt
Foundation        = protocol reference / canon / conformance
Lab Kit           = installable generic machinery
Pack              = opinionated conventions
Profile           = infrastructure choice
Lab instance      = identity + config + runtime state
App / adapter     = optional interface or integration
Deployment        = real-world machine/cloud configuration
```

No more new project names.

---

## 2. Product Boundary

### Ships as Lab Kit core

```txt
Act model
exact nine-slot validation
candidate mode
canonical JSON
hashing
branch / verdict behavior
local cache / outbox
spine adapter interface
Supabase / Postgres profile adapter
projection runner
blocked Act machinery
evidence machinery
receipt candidate machinery
clock / due checks
hook runner
generic CLI
labd host
generic MCP server
worker contract
report generator
schemas
conformance hooks
acceptance tests
recovery scans
```

### Ships in the same repo but is not core

```txt
packs/demo
packs/santo-andre
packs/manhattan
packages/model-middleware
packages/mcp-server
packages/ts-spine-client
apps/pitwall-adapter
apps/cockpit-adapter
runtimes/shell-worker
runtimes/hermes-adapter
runtimes/openclaw-adapter
runtimes/manhattan
deploy/local
deploy/supabase
deploy/cloudflare
deploy/lab8gb
deploy/lab512
deploy/lab256
```

### Does not become the product

```txt
Santo André
Manhattan
Minilab
minilab.work
Cockpit
Pitwall
Hermes
OpenClaw
Supabase
Cloudflare
LAB_8GB / LAB_512 / LAB_256
```

Those are packs, apps, runtimes, profiles, or deployments.

---

## 3. Non-Negotiable Principles

### 3.1 Act first

Nothing consequential happens unless it can be represented as a LogLine Act.

The canonical Act has exactly nine slots:

```txt
who
did
this
when
confirmed_by
if_ok
if_doubt
if_not
status
```

Hashes, signatures, runtime data, selected branch, storage timestamps, and envelopes live around the Act, not inside it.

### 3.2 Capture first, judge later

The system may preserve ugly or incomplete candidates. Strictness belongs at admission, execution, receipt, and closure.

A candidate is allowed to be ugly.  
A receipt is not.

### 3.3 Claim is not evidence

```txt
claim        ≠ evidence
plan         ≠ execution
execution    ≠ success
provider 200 ≠ closure
observation  ≠ verification
report       ≠ receipt
```

### 3.4 Projection is not truth

A projection is a read model derived from Acts. It may be useful, fast, and beautiful, but it is never the source of semantic truth.

### 3.5 Worker does not govern

A worker may execute an allowed Act and return evidence. It must not decide whether the work should exist, whether permission is sufficient, or whether the result closes scope.

### 3.6 Pack does not edit core

A pack may add conventions, verbs, projections, policies, reports, prompts, benches, and defaults. It must never modify the Act shape or the generic Lab Kit core.

### 3.7 Profile does not define meaning

A profile chooses infrastructure: local-only, SQLite cache, Postgres, Supabase, filesystem export, etc. It does not define institutional truth.

### 3.8 UI does not govern

Cockpits, benches, dashboards, terminals, and apps may propose Acts and read projections. They do not own truth, authority, receipts, or the spine.

---

## 4. Final Architecture Tree

```txt
logline-lab-kit/
  README.md
  Cargo.toml
  LICENSE
  CHANGELOG.md

  build-pack/
    00_BUILD_CONTEXT.md
    01_FINAL_ARCHITECTURE_TREE.md
    02_REPO_STRUCTURE.md
    03_MODULE_OWNERSHIP_MATRIX.md
    04_BUILD_ORDER.md
    05_ACCEPTANCE_TESTS.md
    06_GHOSTS_AND_OPEN_DECISIONS.md
    07_ARCHIVE_AND_DEBRIS_POLICY.md

  foundation/
    refs/
    conformance/
      valid/
      invalid/
      ambiguous/
    hash-profiles/

  crates/
    logline-act/
    logline-lab-core/
    logline-lab-local/
    logline-lab-spine/
    logline-lab-supabase/
    logline-lab-projectors/
    logline-lab-clock/
    logline-lab-hooks/
    logline-lab-dispatch/
    logline-lab-reports/
    logline-lab-cli/
    logline-lab-labd/

  schemas/
    logline-act.schema.json
    runtime-envelope.schema.json
    lab-manifest.schema.json
    pack-manifest.schema.json
    profile-manifest.schema.json
    convention-table.schema.json
    projection.schema.json
    blocked-act.schema.json
    evidence.schema.json
    receipt-candidate.schema.json
    dispatch-packet.schema.json
    workorder.schema.json
    execution-report.schema.json

  conventions/
    base.conventions.yaml
    receipt.conventions.yaml
    blocked-act.conventions.yaml
    evidence.conventions.yaml
    report.conventions.yaml
    grant.conventions.yaml
    runtime.conventions.yaml
    app.conventions.yaml

  profiles/
    local-only/
    postgres/
    supabase/
      profile.yaml
      migrations/
    filesystem-manual/

  packs/
    demo/
    santo-andre/
    manhattan/

  manifests/
    templates/
    examples/

  projectors/
    registry/
    audit/
    blocked/
    evidence/
    receipts/
    reports/

  hooks/
    default/
    examples/

  benches/
    acts/
    runtimes/
    engines/
    projections/
    blocked/
    receipts/
    intervals/
    experiments/
    ai-to-act-translation/
    promotion-control/
    what-runs-natively/

  reports/
    templates/
    examples/

  examples/
    acts/
    candidates/
    blocked/
    evidence/
    receipts/
    reports/
    manifests/
    profiles/
    packs/
    first-session/

  tests/
    test_install.sh
    test_first_session.sh
    test_emit_act.sh
    test_projections.sh
    test_blocked_acts.sh
    test_evidence.sh
    test_receipts.sh
    test_reports.sh
    test_benches.sh
    test_canon_conformance.sh
    test_schema_conformance.sh
    test_supabase_spine.sh
    test_local_buffer.sh
    test_no_file_spine.sh

  generator/
    product.yaml
    commands.yaml
    schemas.yaml
    migrations.yaml
    projectors.yaml
    benches.yaml
    acceptance.yaml
    constraints.yaml

  recovery/
    recovery-protocol.md
    corpus-classification.yaml
    repair-notes.md
    false-authority-scan.yaml
    storage-language-scan.yaml
    ghost-marking.yaml
    recovery-receipt.template.yaml

  packages/
    mcp-server/
    model-middleware/
    ts-spine-client/

  apps/
    pitwall-adapter/
    cockpit-adapter/

  runtimes/
    shell-worker/
    hermes-adapter/
    openclaw-adapter/
    manhattan/

  deploy/
    local/
    supabase/
    cloudflare/
    lab8gb/
    lab512/
    lab256/

  install/
    install.sh
    uninstall.sh
    launchd/
    systemd/

  release/
    checksums/
    homebrew/
    github-actions/

  docs/
    simple/
    reference/
    recovery/
    archive-context/
```

---

## 5. Code Structures

| Structure | Language / SDK | Function |
|---|---|---|
| `logline-act` | Rust | Act model, validation, canonicalization, hashing, branch semantics |
| `logline-lab-core` | Rust | Lab manifest, packs, profiles, admission, conventions |
| `logline-lab-local` | Rust / SQLite | Local provisional cache and outbox |
| `logline-lab-spine` | Rust | Generic spine trait, ingest, idempotency, sync |
| `logline-lab-supabase` | Rust / SQL | Supabase/Postgres profile adapter |
| `logline-lab-projectors` | Rust / SQL | Registry, audit, blocked Acts, evidence, receipt and report projections |
| `logline-lab-clock` | Rust | Tick, due Acts, scheduler, intervals, capacity band |
| `logline-lab-dispatch` | Rust | Dispatch packet, workorder, execution report, worker contract |
| `logline-lab-cli` | Rust | User command surface |
| `logline-lab-labd` | Rust | Lab host daemon/API |
| `mcp-server` | TypeScript MCP SDK | Generic MCP surface |
| `model-middleware` | TypeScript / Vercel AI SDK | Redaction, Act framing, claim capture, canon verdict |
| `pitwall-adapter` | TypeScript | Bench events and claim/evidence flow into Acts |
| `cockpit-adapter` | TypeScript | UI proposals and projection reads |
| `manhattan-runtime` | Python / shell / macOS launchd | Physical fleet probes, repairs and evidence |

---

## 6. Build Pack

The build pack lives inside the project:

```txt
logline-lab-kit/build-pack/
```

It is not a second project. It is the closure layer for builders.

### Files

```txt
00_BUILD_CONTEXT.md
01_FINAL_ARCHITECTURE_TREE.md
02_REPO_STRUCTURE.md
03_MODULE_OWNERSHIP_MATRIX.md
04_BUILD_ORDER.md
05_ACCEPTANCE_TESTS.md
06_GHOSTS_AND_OPEN_DECISIONS.md
07_ARCHIVE_AND_DEBRIS_POLICY.md
```

### Function

```txt
Tell builders exactly:
  what exists
  what to build
  what not to build
  what ships as core
  what ships as pack/profile/app/runtime/deploy
  what proves v0
  what remains ghosted
  what old material is debris
```

---

## 7. Build Order

### Phase 0 — Freeze the project boundary

```txt
install reduced docs
install ATLAS
install build-pack
install repo structure
install ownership matrix
mark all ghosts
demote old transcripts and assistant-generated authority
```

### Phase 1 — Act core

```txt
Act struct
exact nine-slot validation
candidate mode
canonical bytes
hashing
branch / verdict behavior
conformance tests
```

### Phase 2 — Local Lab

```txt
local SQLite cache/outbox
emit Act
list Acts
idempotent local write
no local truth claim
```

### Phase 3 — Spine profile

```txt
generic spine trait
Supabase/Postgres adapter
ops.logline_acts migration
idempotent ingest
remote readback
sync from outbox
```

### Phase 4 — Projections

```txt
recent Acts
registry
blocked Acts
evidence
receipt candidates
reports
staleness
```

### Phase 5 — Lab host and CLI

```txt
lab manifest
pack loader
profile loader
labd API
CLI commands
doctor checks
```

### Phase 6 — Evidence, blocked Acts, receipts

```txt
evidence add/list
blocked Act open/list/close
receipt candidate prepare/list
report does not equal receipt
claim does not equal evidence
```

### Phase 7 — Clock and hooks

```txt
tick
due Acts
reschedule Act
daily report hook
capacity band placeholder
hook runner
```

### Phase 8 — Worker boundary

```txt
dispatch packet
workorder
execution report
shell worker
dry-run mode
real command mode
evidence return
```

### Phase 9 — MCP and model boundary

```txt
generic MCP server
register app/entity
issue grant
tool call to draft Act
unauthorized app blocked
model middleware
redaction
claim capture
canon verdict
```

### Phase 10 — Packs

```txt
demo pack
Santo André pack
Manhattan pack
pack loading without core mutation
```

### Phase 11 — Manhattan proof

```txt
L-06 Act
gate decision
real Ethernet ping
evidence capture
scoped receipt
projection healthy
```

### Phase 12 — Install/release

```txt
install.sh
uninstall.sh
doctor
checksums
release artifacts
recovery receipt
```

---

## 8. Acceptance Tests

A right v0 is complete when these pass:

```txt
A1   Act with exactly nine slots validates.
A2   Act with a missing slot fails.
A3   Act with a tenth canonical slot fails.
A4   Same Act produces same canonical hash.
A5   Ugly candidate can be preserved.
A6   Local emit stores Act in local cache/outbox.
A7   Re-emitting same Act is idempotent.
A8   Sync writes Act to configured spine.
A9   Projection reads Act from spine.
A10  Blocked Act appears when evidence or permission is missing.
A11  Evidence can be attached to scope.
A12  Receipt candidate names exact scope.
A13  Report does not pretend to be receipt.
A14  Pack loads without changing core.
A15  Profile loads without changing core.
A16  App/MCP call becomes draft Act.
A17  Unauthorized app action is blocked.
A18  Worker cannot execute without allow.
A19  Worker returns evidence, not closure.
A20  Clock tick emits or evaluates due Acts.
A21  Due Act resolves or creates reschedule Act.
A22  Lab report renders state from projections.
A23  Demo pack completes first session.
A24  Santo André pack loads without becoming core.
A25  Manhattan pack loads without becoming core.
A26  Manhattan L-06 emits evidence.
A27  L-06 receipt closes only L-06.
A28  Projection shows L-06 health from Acts.
A29  Recovery scan catches false authority.
A30  Storage scan rejects file/SQLite truth language.
```

---

## 9. v0 Done

v0 is done when:

```txt
A user installs LogLine Lab Kit.
The user initializes a Lab with a profile and pack.
The user emits an Act.
The Act validates as exactly nine canonical slots.
The Act is canonicalized and hashed.
The Act is stored in the local outbox.
The Act syncs to the configured spine.
The Act is read through projections.
A blocked Act is opened or carried.
Evidence is attached.
A scoped receipt candidate is prepared.
A Lab report is generated.
One worker dry-run runs.
One real worker command runs.
One MCP app is registered.
One grant is issued.
One unauthorized app action is rejected.
One clock tick runs.
One due Act is evaluated.
One demo pack loads.
The Santo André pack loads without changing core.
The Manhattan pack loads without changing core.
Manhattan L-06 runs as the serious proof:
  Act → gate → worker ping → evidence → scoped receipt → projection.
```

---

## 10. First Serious Proof

The first serious proof is:

```txt
Manhattan L-06
```

Target:

```txt
LAB_8GB emits an Act to check the Ethernet peer link.
The gate admits it.
The worker runs the real ping over Ethernet.
Evidence returns.
A scoped receipt closes only L-06.
The configured spine stores the Act and receipt candidate.
A projection shows the machine healthy.
```

This does not make Manhattan the product.

It proves that Lab Kit can operate a serious real-world pack without becoming that pack.

---

## 11. Ghosts and Open Decisions

Known ghosts:

```txt
final lab manifest schema
final pack manifest schema
final profile manifest schema
Convention Table schema
receipt candidate schema
blocked Act projection schema
Rust CLI vs TypeScript/oClif final CLI strategy
Hermes vs OpenClaw primary runtime
Supabase migrations exact shape
MCP server package boundary
model middleware package boundary
pitwall adapter boundary
cockpit adapter boundary
Manhattan runtime install status
LAB_8GB package installation
Manhattan L-06 receipt
capacity band formula
first release distribution channel
```

Rule:

```txt
A ghost is not failure.
A ghost is named missing proof.
```

---

## 12. Archive and Debris Policy

### Preserve

```txt
current reduced docs
ATLAS
Foundation refs
conformance vectors
working code
recovery notes
receipts
evidence
current build-pack
```

### Demote

```txt
transcripts
assistant-generated ADRs
old zips
false authority files
stale architecture drafts
duplicated docs
old primitive/artifact/ledger language
```

### Remove

```txt
build outputs
generated junk
.DS_Store
__MACOSX/
target/
dead manifests
fake checksums
files pretending to be source of truth
```

Never call disposable junk archive.

---

## 13. Final Sentence

```txt
LogLine Lab Kit is the instrument.
Packs are the music.
Profiles are the stage.
Workers are the hands.
Apps are the doors.
Labs are the performances.
Acts are the record.
Receipts close only what was proven.
```
