# Incoming ZIPs not included in lean package

The large original uploaded ZIPs were intentionally excluded from this lean package to keep it downloadable.

Preserved instead:
- extracted smaller source fruits under `source-fruits/extracted/`
- inventories under `source-fruits/inventories/`
- recovery order under `source-fruits/recovery-notes/`

Excluded from this lean package:
- `Archive(1)(1).zip` (~291 MB raw archive)
- original smaller ZIP files already represented by extracted folders

To recover from the huge archive later, bring `Archive(1)(1).zip` back into `source-fruits/incoming-zips/` and run the recovery protocol. Do not promote it directly into core.
