PROJECT MANHATTAN v2 — Implementation Plan
LAB 8GB first. Scope: LAB_8GB only until receipts.
Status: Planning document — not execution. Awaiting Daniel sign-off.
Prepared from: LIST v2 canonical (L-01..L-30, G-01..G-08, BUG-01..BUG-07)

1. Implementation Principles
P-IMPL-01 — v2 implements LIST v2, not local garbage
Every change in v2 traces to a specific L-item, BUG-item, or ghost resolution in LIST v2. If a behavior cannot be traced to that document, it does not enter v2. Local drift found during Phase 0 is evidence — it does not expand the canonical set.

P-IMPL-02 — LAB 8GB first, receipts required before porting
LAB_512 and LAB_256 are not touched until LAB_8GB has Phase 10 receipts: PROJECT_MANHATTAN_POST_REBOOT_SURVIVAL_OK, PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED, and a clean audit showing rogue=0, stale=0, drift_items=0.

P-IMPL-03 — No helper plist sprawl
Every proposed behavior that might tempt a new plist is audited in Section 6 below. All new behavior enters through the Manhattan daemon loop, the Manhattan user_agent loop, or an admitted vendor/service plist. Gate enforces physically.

P-IMPL-04 — Receipts are the proof of record
No phase is complete without its receipts. A receipt requires runtime probe evidence. A command that returned 0 is not a receipt. A plist write is not a receipt. Success is a measured state, not an attempted action.

P-IMPL-05 — Stop conditions are hard gates
The stop conditions in Section 7 are not warnings. When one fires, the current phase stops. The next phase does not begin. Human decision is required before resuming.

P-IMPL-06 — Phases within LAB 8GB are sequential
No phase begins until the previous phase's success criteria are met and receipts are written. Ghost-blocked phases wait for ghost resolution — they do not proceed on assumption.

2. Phase Map
Phase 0 — Baseline v1 Read-Only Evidence

Phase ID:         PH-00
Name:             Baseline v1 Read-Only Evidence
Goal:             Capture complete current state of Manhattan v1 on LAB 8GB.
                  Confirm what exists, what is broken, and what is missing.
                  No interpretation that could be mistaken for canon.
Mutates system?   NO
Requires gate?    NO
Depends on ghosts: none
Files read (not changed):

/usr/local/project-manhattan/etc/manhattan.json
/usr/local/project-manhattan/etc/registry/*.json
/usr/local/project-manhattan/var/receipts/ (all recent)
/usr/local/project-manhattan/var/drift.json
All manhattan binary scripts in /usr/local/project-manhattan/bin/
All launchd plists in /Library/LaunchDaemons/ and /Library/LaunchAgents/
Commands/probes:


# Manhattan state
/usr/local/project-manhattan/bin/manhattan audit
cat /usr/local/project-manhattan/etc/manhattan.json
ls -la /usr/local/project-manhattan/etc/registry/
ls -la /usr/local/project-manhattan/var/receipts/
cat /usr/local/project-manhattan/var/drift.json

# System state reference
scutil --get ComputerName ; scutil --get HostName ; scutil --get LocalHostName
launchctl list | grep -E "(teamviewer|cloudflared|minilab|manhattan)"
ls -la /Library/LaunchDaemons/ | grep -E "(teamviewer|minilab|manhattan)"
ls -la /Library/LaunchAgents/ | grep -E "(teamviewer|minilab|manhattan)"
ls -la ~/Library/LaunchAgents/ | grep -E "(cloudflared|minilab|manhattan)"
Receipts expected:

PH-00-BASELINE-READ-COMPLETE (manual notation, not a system receipt — confirms Phase 0 done)
Stop conditions:

If Manhattan binary is missing or non-executable → stop, investigate before proceeding
If receipts directory is missing or unreadable → stop, this is a receipts_directory_missing drift
Rollback: None needed — read-only

Success criteria:

Complete picture of current registry, config, receipts, and code
Known BUG-01..07 confirmed present in code by inspection
No surprises that change Phase 1 or Phase 2 scope
Phase 1 — Resolve No-Mutation Ghosts

Phase ID:         PH-01
Name:             No-Mutation Ghost Resolution
Goal:             Resolve all ghosts that can be answered by read-only probes.
                  Produce evidence records for G-01, G-02, G-05, G-07, G-08.
                  Write results to a ghost resolution record (not a system receipt).
Mutates system?   NO
Requires gate?    NO
Depends on ghosts: G-01, G-02, G-05, G-07, G-08
Ghost probe commands:


# G-01 — Cloudflare tunnel health endpoint
curl -sf --max-time 5 http://localhost:2000/metrics
curl -sf --max-time 5 http://localhost:2000/ready
curl -sf --max-time 5 http://localhost:2000/healthcheck
cloudflared tunnel info   # if binary accessible without tunnel-name requirement
# Examine: which returns non-empty parseable response with active connection signal?
# Record: confirmed endpoint, parse pattern for "tunnel_active=true" equivalent

# G-02 — Peer MAC addresses (requires G-08 first — interface name)
# Run after G-08 is confirmed:
ifconfig {eth_iface} | grep ether
# Record: exact MAC of LAB_8GB peer Ethernet interface

# G-05 — MDM enrollment
profiles status -type enrollment
profiles list
# Record: enrolled or not; MDM provider if enrolled; conflicts with defaults writes?

# G-07 — Remote Management state
launchctl print system/com.apple.RemoteDesktop.agent 2>&1
ls -la /System/Library/CoreServices/RemoteManagement/ARDAgent.app 2>&1
# Record: installed, not installed, running, not running

# G-08 — Ethernet interface name
networksetup -listallhardwareports
ifconfig -a | grep -A5 "10.88.0"
# Cross-reference: which BSD interface has 10.88.0.9 static assignment?
# Confirm it is not Wi-Fi, not Thunderbolt bridge
# Record: exact interface name for config (e.g., en1, en2, en3)
Receipts expected:

PH-01-GHOST-RESOLUTION-RECORD (manual notation containing confirmed values per ghost)
Individual per-ghost evidence lines:
G-01-TUNNEL-PROBE-ENDPOINT: {confirmed endpoint}
G-02-PEER-MAC-LAB8GB: {mac address}
G-05-MDM-STATUS: {enrolled|not enrolled}
G-07-REMOTE-MANAGEMENT: {installed+running|installed+stopped|not installed}
G-08-ETH-IFACE-LAB8GB: {interface name}
Stop conditions:

G-08 unresolved → Phase 2 BUG-03 cannot set correct config; Phase 6 L-06 repair blocked
G-07 shows Remote Management not installed → document as human-required before Phase 6 L-25
G-05 shows MDM active with conflicting profile → escalate to Daniel before Phase 6
Rollback: None needed — read-only

Success criteria:

G-01, G-02, G-05, G-07, G-08 each have a documented probe result
G-03 and G-04 remain open (require Daniel decision / LAB testing respectively)
Ghost resolution record exists and is reviewed by Daniel
Phase 2 — Safe Code Correctness Patches

Phase ID:         PH-02
Name:             Code Correctness Patches
Goal:             Fix BUG-01 through BUG-07 inside Manhattan code and config only.
                  No system policy changes. No new launchd entries. No registry additions.
Mutates system?   YES — Manhattan binary and config files only
Requires gate?    YES — gate must be open to edit files in gate-protected paths
Depends on ghosts: G-08 (for BUG-03 — gate paths need interface name if they depend on per-LAB config)
Files likely changed:

/usr/local/project-manhattan/bin/manhattan-audit (BUG-01, BUG-02, BUG-04, BUG-05, BUG-07)
/usr/local/project-manhattan/bin/manhattan (BUG-03)
/usr/local/project-manhattan/etc/manhattan.json (BUG-03 gate_paths key, BUG-04 scan_domains key)
Patch sequence (within gate open):


BUG-07 first — smallest change, verifiable immediately
BUG-01 second — classification fix, no config dependency
BUG-02 third — mode display fix, reads from config
BUG-04 fourth — adds scan domain, requires config key addition
BUG-03 fifth — reads gate paths from config (depends on config key existence from BUG-04 pass)
BUG-05 sixth — cloudflared plist parser fix (investigate before patching)
BUG-06 seventh — receipt retention (adds cleanup loop to daemon)
Commands/probes (after each patch):


# BUG-01 verify: gate probe in audit output must show classification = "admitted"
/usr/local/project-manhattan/bin/manhattan audit | grep -A5 "gate"

# BUG-02 verify: mode in audit output must match manhattan.json mode value
/usr/local/project-manhattan/bin/manhattan audit | grep "mode"
cat /usr/local/project-manhattan/etc/manhattan.json | grep "mode"

# BUG-03 verify: gate paths in binary no longer hardcoded; audit reads from config
grep -n "GATE_PATHS" /usr/local/project-manhattan/bin/manhattan
/usr/local/project-manhattan/bin/manhattan gate probe

# BUG-04 verify: /Library/LaunchAgents/ scan results appear in audit
/usr/local/project-manhattan/bin/manhattan audit | grep "system_launchagents"
ls /Library/LaunchAgents/ | grep teamviewer  # must now appear in audit output

# BUG-05 verify: cloudflared label in audit shows correct label, not program arg
/usr/local/project-manhattan/bin/manhattan audit | grep "cloudflared"
# Must show label = "work.minilab.cloudflared", not a path

# BUG-06 verify: cleanup logic present; test with synthetic old receipt
ls -la /usr/local/project-manhattan/var/receipts/

# BUG-07 verify: pmset probe output includes ttyskeepawake
/usr/local/project-manhattan/bin/manhattan audit | grep "ttyskeepawake"
pmset -g custom | grep ttyskeepawake
Receipts expected:

PROJECT_MANHATTAN_CODE_PATCH_BUG01_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG02_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG03_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG04_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG05_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG06_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG07_APPLIED
PROJECT_MANHATTAN_GATE_OPENED (before patching)
PROJECT_MANHATTAN_GATE_CLOSED (after patching, with sudo -K)
Stop conditions:

Gate open fails → stop, do not patch
Any patch probe shows unexpected audit output → stop, investigate before continuing
BUG-05 investigation reveals plist is structurally corrupt (not just trailing content) → escalate to Daniel; do not apply speculative fix
Rollback:

Manhattan is in a git repository. Each BUG patch is a separate commit.
Rollback = git revert {commit} per bug, then close gate
Config changes (BUG-03, BUG-04): revert JSON key additions
Success criteria:

All 7 patch probes pass
Audit output reflects corrected behavior for each bug
Gate closed with receipt
No new behaviors introduced beyond the 7 stated fixes
Phase 3 — Registry Normalization

Phase ID:         PH-03
Name:             Registry Normalization
Goal:             Bring registry to the v2 clean state specified in LIST v2 Section 7.
                  Add missing entries. Correct misclassified entries.
                  No new launchd service creation.
Mutates system?   YES — registry JSON files only
Requires gate?    YES — registry files are in gate-protected path
Depends on ghosts: G-08 (eth interface name for config entries), G-07 (Remote Management for correct admitted status)
Registry changes required:

Action	File	Change
CREATE	manhattan-agent.json	Label: com.project-manhattan.agent; status: candidate (not admitted — agent not yet created); domain: system_launchagents; plist: /Library/LaunchAgents/com.project-manhattan.agent.plist
CREATE or CORRECT	teamviewer-service.json	classification: admitted; canonical: true; managed: false; vendor_implemented: true
CREATE or CORRECT	teamviewer-agent.json	label: com.teamviewer.teamviewer; domain: system_launchagents; classification: admitted; canonical: true; vendor_implemented: true
ADD KEY	health.json	evaluate: true (pending G-06 scope decision)
VERIFY	cloudflared.json	confirmed admitted, domain gui/501
VERIFY	host-runtime.json	confirmed admitted, domain gui/501
ADD KEY	manhattan.json	gate_paths array (from BUG-03), scan_domains.system_launchagents (from BUG-04)
Note on manhattan-agent.json status: The agent plist does not yet exist at /Library/LaunchAgents/com.project-manhattan.agent.plist. The registry entry is created with status candidate to document intent. It moves to admitted only in Phase 5 when Daniel signs the agent design and the plist is created.

Commands/probes:


# After registry changes, verify audit classification
/usr/local/project-manhattan/bin/manhattan audit | grep -A3 "teamviewer"
/usr/local/project-manhattan/bin/manhattan audit | grep -A3 "manhattan-agent"
/usr/local/project-manhattan/bin/manhattan audit | grep "rogue"
# rogue count must not increase due to registry changes
Receipts expected:

PROJECT_MANHATTAN_REGISTRY_NORMALIZED
PROJECT_MANHATTAN_GATE_OPENED (if gate was closed since PH-02)
PROJECT_MANHATTAN_GATE_CLOSED
Stop conditions:

Audit after registry change shows unexpected rogue items → stop, investigate
Registry JSON parse error → stop, revert to last known good
Rollback: Revert registry JSON files from git. Gate must reopen for revert.

Success criteria:

All registry entries match LIST v2 Section 7 table
Audit shows: rogue=0, stale=0 for all known items
teamviewer.teamviewer (user agent at /Library/LaunchAgents) now classified admitted in audit output (requires BUG-04 fix from PH-02)
manhattan-agent appears in registry as candidate
Phase 4 — Probe-Only LIST v2 Audit Expansion

Phase ID:         PH-04
Name:             Probe-Only Audit Expansion
Goal:             Implement all missing L-item probes as report-only checks.
                  No repair actions yet. Each probe writes a receipt showing current state.
                  Identifies all remaining gaps and drift before repair is attempted.
Mutates system?   YES — Manhattan code only (adding probe logic); NO system state changes
Requires gate?    YES — editing Manhattan binary
Depends on ghosts: G-01 (L-16 tunnel probe), G-07 (L-25 Remote Management), G-08 (L-06 probe)
Probes to add (not yet in v1 or broken in v1):

L-item	Probe	Currently in v1?
L-01 Identity	scutil compare all 3 names vs config	Partial — add config comparison
L-02 Auto-Login	defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser	Unknown — add
L-03 FileVault	fdesetup status	Unknown — add
L-05 Wi-Fi	networksetup -getairportpower + scutil --nwi + ping	Partial — verify complete
L-06 Ethernet	networksetup -getinfo {eth_iface} (uses G-08 result)	Unknown — add
L-09 pmset	all 9 values including ttyskeepawake (BUG-07 fix)	Partial after BUG-07 fix
L-16 Tunnel Health	confirmed endpoint from G-01	Missing — add after G-01 resolved
L-25 Remote Management	launchctl print system/com.apple.RemoteDesktop.agent	Unknown — add
L-26 Bluetooth	defaults read /Library/Preferences/com.apple.Bluetooth ControllerPowerState	Unknown — add
L-27 AirDrop	ifconfig awdl0 | grep "status: active"	Unknown — add
L-28 Handoff	defaults read /Library/Preferences/com.apple.NetworkBrowser DisableHandoff	Unknown — add
All new probes: report current state + write receipt. No repair action.

Receipts expected (per probe, current state):

PROJECT_MANHATTAN_IDENTITY_VERIFIED or PROJECT_MANHATTAN_IDENTITY_MISMATCH
PROJECT_MANHATTAN_AUTO_LOGIN_OK or PROJECT_MANHATTAN_AUTO_LOGIN_DRIFT
PROJECT_MANHATTAN_FILEVAULT_OFF_OK or PROJECT_MANHATTAN_FILEVAULT_ON_HUMAN_REQUIRED
PROJECT_MANHATTAN_WIFI_OK or PROJECT_MANHATTAN_WIFI_DRIFT
PROJECT_MANHATTAN_ETHERNET_PEER_OK or PROJECT_MANHATTAN_ETHERNET_PEER_DRIFT
PROJECT_MANHATTAN_POWER_POLICY_OK or PROJECT_MANHATTAN_POWER_POLICY_REPAIRED (probe state, not repair)
PROJECT_MANHATTAN_TUNNEL_HEALTH_OK or PROJECT_MANHATTAN_TUNNEL_FAILED (if G-01 resolved)
PROJECT_MANHATTAN_REMOTE_MANAGEMENT_OK or PROJECT_MANHATTAN_REMOTE_MANAGEMENT_DRIFT
PROJECT_MANHATTAN_BLUETOOTH_OK or PROJECT_MANHATTAN_BLUETOOTH_REQUIRES_MANUAL
PROJECT_MANHATTAN_AIRDROP_OK or PROJECT_MANHATTAN_AIRDROP_DISABLED
PROJECT_MANHATTAN_HANDOFF_OK or PROJECT_MANHATTAN_HANDOFF_DISABLED
PROJECT_MANHATTAN_PH04_PROBE_COMPLETE
Stop conditions:

L-01 identity mismatch detected → stop Phase 4 immediately, write identity_mismatch drift, do not continue
G-01 still unresolved at Phase 4 execution time → skip L-16 probe, mark as cloudflare_tunnel_probe_missing in audit
Rollback: Code revert (git). No system state was changed.

Success criteria:

Full audit run produces receipts for all L-items that have probes
Items with no probe (blocked by ghost) show explicit probe_missing status in audit, not silence
audit output drift_count accurately reflects real drift (not v1 false negatives)
Phase 5 — User Agent Design and Admission Plan

Phase ID:         PH-05
Name:             User Agent Design and Admission
Goal:             Produce the exact plist and launch spec for com.project-manhattan.agent.
                  Present to Daniel for sign-off. No file creation until signed.
Mutates system?   NO (design only) → YES only when Daniel signs
Requires gate?    NO (design) → YES (creation)
Depends on ghosts: none (design is independent of ghost resolution)
Agent specification:


Label:            com.project-manhattan.agent
Plist location:   /Library/LaunchAgents/com.project-manhattan.agent.plist
Runtime domain:   gui/501/com.project-manhattan.agent
Scan domain:      system_launchagents (/Library/LaunchAgents)
Run as:           LAB user (not root)
RunAtLoad:        true
KeepAlive:        true
Program:          /usr/local/project-manhattan/bin/manhattan-agent
Owns (per LIST v2 Section 6-B):

L-04 Keychain usability (indirect probe)
L-12 Screensaver/lock screen (user domain prefs)
L-14 TeamViewer user session bootstrap
L-16 Cloudflare tunnel health probe + restart
L-17 Login survival probe
L-27 AirDrop probe + repair attempt
L-28 Handoff/Universal Control probe
Assists (not owns):

L-18 pre-restart phases (gui/501 restarts at daemon's signal)
L-20 post-reboot survival (session-bound checks)
L-23 receipt writing from user session
Receipts expected (on admission):

PROJECT_MANHATTAN_AGENT_ADMITTED (written by system_daemon when it detects agent bootstrap)
PROJECT_MANHATTAN_GATE_OPENED + PROJECT_MANHATTAN_GATE_CLOSED around plist creation
Stop conditions:

Daniel has not signed the agent design → plist NOT created
Gate cannot be opened → plist NOT created
Rollback:

If agent created but causes issues: launchctl bootout gui/501/com.project-manhattan.agent
Delete plist, gate close, update registry status back to candidate
Success criteria (design phase):

Agent spec reviewed and signed by Daniel
Registry entry moves from candidate to admitted in manhattan-agent.json
Plist created at /Library/LaunchAgents/com.project-manhattan.agent.plist
launchctl print gui/501/com.project-manhattan.agent shows state=running after bootstrap
Phase 6 — Auto-Repair Implementation, System Side

Phase ID:         PH-06
Name:             System-Side Auto-Repair
Goal:             Implement actual repair actions (not just probes) for system_daemon-owned L-items.
                  Each repair verified by post-repair probe before success receipt is written.
Mutates system?   YES — repairs mutate system state (SSH, pmset, firewall, pf, Wi-Fi, Ethernet)
Requires gate?    YES — code changes; NO — repair actions themselves don't need gate
Depends on ghosts: G-08 (L-06 Ethernet interface name), G-07 (L-25 Remote Management install state)
Repairs to implement (inside system_daemon loop):

L-item	Repair command	Post-probe	Receipt
L-08 SSH	systemsetup -setremotelogin on	systemsetup -getremotelogin	PROJECT_MANHATTAN_SSH_REPAIRED
L-09 pmset	pmset -a sleep 0 displaysleep 0 disksleep 0 standby 0 powernap 0 tcpkeepalive 1 womp 1 autorestart 1 ttyskeepawake 1	pmset -g custom all 9 values	PROJECT_MANHATTAN_POWER_POLICY_REPAIRED
L-10 Firewall	socketfilterfw --setglobalstate off	socketfilterfw --getglobalstate	PROJECT_MANHATTAN_FIREWALL_REPAIRED
L-11 pf	pfctl -d	pfctl -s info	PROJECT_MANHATTAN_PF_KILLED
L-05 Wi-Fi	networksetup -setairportpower {wifi_iface} on	networksetup -getairportpower {wifi_iface}	PROJECT_MANHATTAN_WIFI_DRIFT (if no internet: drift, not repaired)
L-06 Ethernet	networksetup -setmanual {eth_iface} {ip} {subnet} ""; networksetup -setdnsservers {eth_iface} Empty	networksetup -getinfo {eth_iface}	PROJECT_MANHATTAN_ETHERNET_PEER_REPAIRED
L-13 TeamViewer	launchctl kickstart -k system/com.teamviewer.service	launchctl print system/com.teamviewer.service	PROJECT_MANHATTAN_TEAMVIEWER_SERVICE_REPAIRED
L-25 Remote Mgmt	launchctl kickstart -k system/com.apple.RemoteDesktop.agent	launchctl print system/com.apple.RemoteDesktop.agent	PROJECT_MANHATTAN_REMOTE_MANAGEMENT_OK
Items that cannot be auto-repaired (report only, write _HUMAN_REQUIRED receipt):

L-02 Auto-Login — if MDM-locked: PROJECT_MANHATTAN_AUTO_LOGIN_REQUIRES_MDM
L-03 FileVault — detection only: PROJECT_MANHATTAN_FILEVAULT_ON_HUMAN_REQUIRED
L-26 Bluetooth — attempt repair, if fails on macOS 12+: PROJECT_MANHATTAN_BLUETOOTH_REQUIRES_MANUAL
Stop conditions:

L-08 repair fails (SSH still off after setremotelogin on) → write drift receipt, continue other repairs
L-09 repair fails (pmset values still wrong after repair command) → write drift receipt, alert
L-06 repair attempted with wrong interface name (G-08 unresolved) → stop L-06 repair, skip it
Rollback:

SSH repair: systemsetup -setremotelogin off (do not do this — would break remote access; this repair is safe to keep)
pmset repair: drift from canonical is worse than canonical; no rollback needed
pf/firewall: re-enable if intentionally enabled (operator action, not automatic)
Success criteria:

Each implemented repair triggers, re-probes, and writes a receipt
No repair claims success without a confirming probe
drift.json reflects fewer drift items than at Phase 4
Phase 7 — Auto-Repair Implementation, User Side

Phase ID:         PH-07
Name:             User-Agent-Side Auto-Repair
Goal:             Implement actual repair/maintenance actions for user_agent-owned L-items.
                  Requires com.project-manhattan.agent admitted and running (Phase 5 complete).
Mutates system?   YES — user session state (screensaver prefs, agent bootstrap, AirDrop defaults)
Requires gate?    YES — for code changes to manhattan-agent binary
Depends on ghosts: G-01 (L-16 tunnel health probe/repair), G-04 (L-26/L-27 repair reliability)
Repairs to implement in manhattan-agent loop:

L-item	Action	Receipt
L-12 Screensaver	defaults -currentHost write com.apple.screensaver askForPassword -int 0; defaults -currentHost write com.apple.screensaver idleTime -int 0	PROJECT_MANHATTAN_SCREENSAVER_REPAIRED
L-14 TeamViewer session	launchctl bootstrap gui/501 /Library/LaunchAgents/com.teamviewer.teamviewer.plist	PROJECT_MANHATTAN_TEAMVIEWER_SESSION_OK
L-15 cloudflared	launchctl bootout gui/501/work.minilab.cloudflared 2>/dev/null; launchctl bootstrap gui/501 {plist_path}	PROJECT_MANHATTAN_CLOUDFLARED_RESTARTED
L-16 Tunnel Health	probe {G-01 endpoint}; if unhealthy: restart cloudflared, wait 15s, re-probe	PROJECT_MANHATTAN_TUNNEL_REFRESHED or PROJECT_MANHATTAN_TUNNEL_FAILED
L-17 Login Survival	On RunAtLoad: verify L-13, L-14, L-15, L-16 within 60s of session start	PROJECT_MANHATTAN_LOGIN_SURVIVAL_OK or PROJECT_MANHATTAN_LOGIN_SURVIVAL_FAILED
L-27 AirDrop	defaults write com.apple.NetworkBrowser BrowseAllInterfaces -bool true	PROJECT_MANHATTAN_AIRDROP_OK or PROJECT_MANHATTAN_AIRDROP_REQUIRES_MANUAL
L-28 Handoff	defaults write /Library/Preferences/com.apple.NetworkBrowser DisableHandoff -bool false	PROJECT_MANHATTAN_HANDOFF_OK
TCC items (L-29) — report only:

Probe behavioral evidence (tool logs, error output)
Write PROJECT_MANHATTAN_TCC_HUMAN_REQUIRED if drift detected
No repair attempt
Stop conditions:

Agent not running (Phase 5 not complete) → Phase 7 does not execute
G-01 unresolved → L-16 repair not implemented; mark cloudflare_tunnel_probe_missing
G-04 test fails for AirDrop repair → write airdrop_requires_manual, do not retry in loop
Rollback:

Screensaver repair: reverse defaults writes (user can re-enable manually)
cloudflared restart: launchctl bootout gui/501/work.minilab.cloudflared (leaves down)
Success criteria:

L-17 Login Survival writes PROJECT_MANHATTAN_LOGIN_SURVIVAL_OK within 60 seconds of user session start
All agent-owned items have receipts
No infinite repair loops — each repair attempts once per audit cycle, writes receipt, does not retry until next cycle
Phase 8 — Daily Rejuvenation Scheduler

Phase ID:         PH-08
Name:             Daily Rejuvenation Scheduler
Goal:             Implement L-18 and L-19 inside the Manhattan system_daemon loop.
                  Time-based phase sequence, single daily restart at per-LAB canonical time.
                  No StartCalendarInterval. No pmset schedule. No helper plist.
Mutates system?   YES — system reboots once per day; code change inside daemon loop
Requires gate?    YES — editing daemon code
Depends on ghosts: none (restart timing is in daemon loop, not hardware)
Implementation inside system_daemon loop (no new files):


Every 300-second loop iteration:
  1. Check local time
  2. If in LAB_8GB window and no restart today (checked via last DAILY_RESTART_REQUESTED receipt):
     06:00 → kickstart TeamViewer system service      → write PHASE_TEAMVIEWER_OK
     06:10 → bootout + bootstrap cloudflared          → write PHASE_CLOUDFLARED_OK
     06:20 → probe tunnel health (G-01 endpoint)      → write PHASE_TUNNEL_OK or PHASE_TUNNEL_FAILED
     06:30 → verify all admitted remote access surfaces → write PHASE_SURFACES_OK
     06:35 → write PRE_RESTART_READY receipt
     06:40 → write DAILY_RESTART_REQUESTED → shutdown -r now
"Today" tracking: Last DAILY_RESTART_REQUESTED receipt timestamp within 23 hours → skip window.

Phase failure behavior: If a phase fails: write PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_FAILED and continue to next phase. Do NOT abort restart due to phase failure. LAB restarts daily regardless.

Receipts expected:

PROJECT_MANHATTAN_DAILY_REFRESH_STARTED
PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_OK (one per phase)
PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_FAILED (if a phase fails)
PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED (written BEFORE shutdown -r now)
Stop conditions:

DAILY_RESTART_REQUESTED receipt exists within 23h → skip window (already restarted today)
Receipt store missing or unwritable → do NOT execute restart; write to syslog; alert
Rollback: If restart behavior is wrong, disable via config flag daily_restart_enabled: false in manhattan.json without removing code.

Success criteria:

LAB 8GB restarts at 06:40 (±5 min) once per 24-hour period
DAILY_RESTART_REQUESTED receipt exists before reboot
Daemon restarts after reboot (KeepAlive=true), then L-20 fires
Phase 9 — Peer Witness LAB 8GB Side

Phase ID:         PH-09
Name:             Peer Witness (Probe-Only First)
Goal:             Implement L-07 peer witness probe logic inside system_daemon loop.
                  Report peer state. WOL only after G-02 and G-03 are resolved.
Mutates system?   YES — code change (no system state change unless peer is down)
Requires gate?    YES — editing daemon code
Depends on ghosts: G-02 (peer MAC for WOL), G-03 (WOL policy — Daniel must decide)
Probe-only implementation (no WOL yet):


ping -c 3 -q {peer_ip}                                       # packet loss = 0
nc -z -G 3 {peer_ip} 22                                      # port 22 open
curl -sf --max-time 3 http://{peer_ip}:{health_port}/health  # health endpoint
WOL implementation (added only after G-02 + G-03 resolved):


# Per G-03 policy (proposed: 3 packets, 2s apart, wait 60s, re-probe once):
for i in 1 2 3; do
  wakeonlan {peer_mac}   # or: etherwake -i {eth_iface} {peer_mac}
  sleep 2
done
sleep 60
# re-probe; if still down: write HUMAN_REQUIRED
Forbidden actions (enforced in code):

No SSH into peer
No editing peer registry
No opening peer gate
No mutating peer launchd
No claiming to be peer authority
Receipts expected:

PROJECT_MANHATTAN_PEER_OK
PROJECT_MANHATTAN_PEER_PING_FAILED
PROJECT_MANHATTAN_PEER_WOL_SENT (only after G-02+G-03 resolved)
Stop conditions:

G-02 unresolved → WOL not implemented; peer witness probe-only
G-03 unresolved → WOL not implemented; peer witness probe-only
Peer down and WOL not available → write PROJECT_MANHATTAN_PEER_PING_FAILED, no further peer action
Success criteria (probe-only):

Daemon loop includes peer probe every 300 seconds
Receipts written showing peer up/down state
No WOL code path active until G-02+G-03 resolved and Daniel confirms
Phase 10 — LAB 8GB v2 Final Audit and Reboot Survival

Phase ID:         PH-10
Name:             LAB 8GB v2 Final Audit and Reboot Survival
Goal:             Run complete v2 audit across all L-01..L-30.
                  Perform controlled daily-restart-style survival probe ONLY when Daniel signs.
                  Verify no rogue/stale/drift. Write final receipts.
Mutates system?   YES — controlled restart (requires Daniel sign-off)
Requires gate?    NO (audit is read-only; restart does not require gate)
Depends on ghosts: all resolved ghosts from PH-01; G-03 may still be open (peer WOL optional)
Audit run:


/usr/local/project-manhattan/bin/manhattan audit
# Expected output:
# rogue = 0
# stale = 0
# drift_items = 0 (or only items that are human-required: TCC, FileVault if on)
# All L-items show probe = ok or probe = human_required (honest)
Survival probe (Daniel signs before execution):


1. Confirm DAILY_RESTART_REQUESTED not in past 23h
2. Open gate (sudo required)
3. Write PRE_SURVIVAL_PROBE_READY receipt
4. Close gate (sudo -K)
5. Allow L-18/L-19 to trigger at 06:40 normally
6. After reboot: daemon starts (KeepAlive=true)
7. L-20 fires: detects uptime < 10min + DAILY_RESTART_REQUESTED within 2h
8. Full survival check: SSH, pmset, firewall, pf, gate state, Manhattan daemon
9. User session: agent starts, L-17 login survival fires
10. Write POST_REBOOT_SURVIVAL_OK or PARTIAL
Receipts expected:

PROJECT_MANHATTAN_POST_REBOOT_SURVIVAL_OK
PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED
Full audit receipt showing rogue=0, stale=0, drift_items=0 (or honest human-required items)
PH-10-LAB8GB-V2-COMPLETE (manual notation for phase completion)
Stop conditions:

Audit shows rogue > 0 → stop, investigate and resolve before survival probe
Post-reboot Manhattan not running within 5 minutes → critical stop; write post_reboot_survival_failed
Post-reboot drift_items > 0 for auto-repairable items → attempt repair, re-probe, re-write receipt
Success criteria:

Clean audit: rogue=0, stale=0
Post-reboot survival: Manhattan running, all auto-repairable items at canonical state
Receipts cover full daily cycle: pre-restart phases, restart, post-reboot survival
LAB 8GB declared v2 complete
Phase 11 — Porting Kit Update

Phase ID:         PH-11
Name:             Porting Kit Update for LAB 512 and LAB 256
Goal:             After LAB 8GB has Phase 10 receipts: update porting playbook with
                  LAB-specific config values, ghost resolutions, and v2 execution notes.
                  Do NOT execute on LAB 512 or LAB 256 in this phase.
Mutates system?   NO (documentation update only)
Requires gate?    NO
Depends on ghosts: All ghosts resolved for LAB_8GB. LAB_512 and LAB_256 ghosts (G-08, G-02 per LAB) remain open.
Porting kit contents:

Per-LAB config values confirmed on LAB_8GB (interface names, IPs, restart times)
Ghost resolution procedures (commands + expected outputs) for use on LAB_512 and LAB_256
Phase sequence with LAB_512-specific values (restart at 06:50, peer IPs reversed, etc.)
Receipt checklist per phase to confirm before porting advance
Success criteria:

Porting kit document exists and is reviewed by Daniel
No LAB_512 or LAB_256 mutations have occurred
Phase sequence for next LABs is pre-approved before execution begins
3. Suggested Phase Order

PH-00  Baseline v1 read-only evidence           (always first; no mutation; unblocked)
PH-01  No-mutation ghost resolution              (unblocked; read-only)
PH-02  Code correctness patches (BUG-01..07)    (blocked until PH-00 confirms bugs; gate required)
PH-03  Registry normalization                    (after PH-02; gate required)
PH-04  Probe-only audit expansion                (after PH-02+PH-03; some probes blocked by G-01, G-08)
PH-05  User agent design + admission             (after PH-03; Daniel sign-off required before creation)
PH-06  System-side auto-repair                   (after PH-04 shows drift; gate for code)
PH-07  User-side auto-repair                     (after PH-05 agent running; gate for code)
PH-08  Daily rejuvenation scheduler              (after PH-06+PH-07; gate for code; Daniel sign-off for restart)
PH-09  Peer witness                              (after PH-06; probe-only until G-02+G-03 resolved)
PH-10  Final audit + reboot survival             (Daniel sign-off required; all prior phases must pass)
PH-11  Porting kit                               (after PH-10 receipts only; no LAB mutation)
4. Ghost Dependency Matrix
Ghost	Blocks L-items	Blocks phases	Resolution command	Expected evidence	Receipt name
G-01 Tunnel probe endpoint	L-16	PH-04 (L-16 probe), PH-07 (L-16 repair), PH-08 (phase 06:20)	curl -sf http://localhost:2000/metrics; curl -sf http://localhost:2000/ready; examine response for active tunnel signal	Confirmed endpoint URL + parse pattern for "tunnel active"	G-01-TUNNEL-PROBE-ENDPOINT-RESOLVED
G-02 Peer MAC addresses	L-07 (WOL only)	PH-09 (WOL only — probe proceeds without MAC)	ifconfig {eth_iface} | grep ether on LAB_8GB and LAB_512 peer Ethernet interface (requires G-08 first)	Exact MAC address per LAB peer interface	G-02-PEER-MAC-RESOLVED
G-03 WOL retry/cooldown policy	L-07 repair behavior	PH-09 WOL implementation	Daniel decides: proposed = 3 packets, 2s apart, wait 60s, re-probe once, then HUMAN_REQUIRED	Daniel's written confirmation of policy parameters	G-03-WOL-POLICY-SIGNED
G-04 Bluetooth/AirDrop CLI reliability	L-26 repair confidence, L-27 repair confidence	PH-06 (L-26 repair), PH-07 (L-27 repair)	On each LAB: disable Bluetooth manually, run defaults write ... ControllerPowerState 1 && killall -HUP bluetoothd, verify state; test AirDrop similarly	Pass/fail result per LAB per macOS version	G-04-BT-REPAIR-RELIABLE or G-04-BT-REPAIR-REQUIRES-MANUAL
G-05 MDM enrollment	L-02 repair path, L-25 activation, L-29 repair	PH-01 (resolution), PH-06 (if MDM conflict)	profiles status -type enrollment; profiles list	Enrolled/not enrolled; if enrolled: MDM provider and whether it conflicts with defaults write	G-05-MDM-STATUS-RESOLVED
G-06 headless-repair + headless-watchdog replacement	com.minilab.work.headless-repair, com.minilab.work.headless-watchdog deletion	PH-03 (registry cleanup), PH-10 (clean state)	Read actual scripts run by each service; map behavior to L-items or gaps; confirm with Daniel which are canonical (absorb) and which are vestigial (delete)	Function list per service; absorption target per function	G-06-WATCHDOG-REPLACEMENT-PLAN-SIGNED
G-07 Remote Management install state	L-25 repair confidence	PH-01 (resolution), PH-04 (probe), PH-06 (repair)	launchctl print system/com.apple.RemoteDesktop.agent 2>&1	Running / stopped / not installed	G-07-REMOTE-MGMT-STATE-RESOLVED
G-08 Ethernet interface name per LAB	L-06 probe + repair, L-07 (WOL target interface)	PH-01 (resolution), PH-02 (BUG-03 config key), PH-04 (L-06 probe), PH-06 (L-06 repair)	networksetup -listallhardwareports; ifconfig -a | grep -A5 "10.88.0"	Exact BSD interface name (en1, en2, en3...) with 10.88.0.x assignment on peer Ethernet	G-08-ETH-IFACE-RESOLVED
5. Code Patch Inventory
BUG-01 — Gate probe classified as candidate

File:           /usr/local/project-manhattan/bin/manhattan-audit
Expected change: In the gate probe classification block, change the hardcoded return
                 value of "candidate" to "admitted" when gate paths exist and uchg is set.
                 Add receipt write on gate probe pass.
Risk level:     LOW — classification label only; no system mutation
Probe after:    /usr/local/project-manhattan/bin/manhattan audit | grep -A5 "gate"
                Audit output must show classification = "admitted"
Receipt:        PROJECT_MANHATTAN_GATE_PROBE_OK (written by corrected code on each audit)
Rollback:       git revert {commit}; reopen gate, apply, close gate
BUG-02 — Mode hardcoded as audit-only

File:           /usr/local/project-manhattan/bin/manhattan-audit
Expected change: Replace hardcoded "audit-only" string in output construction with
                 value read from /usr/local/project-manhattan/etc/manhattan.json["mode"].
                 If key missing: default to "audit-only" with a warning, not a crash.
Risk level:     LOW — output only; no system mutation
Probe after:    /usr/local/project-manhattan/bin/manhattan audit | grep "mode"
                cat /usr/local/project-manhattan/etc/manhattan.json | grep mode
                Both must show same value (e.g., "enforcement")
Receipt:        None specific — audit output correctness is self-evidencing
Rollback:       git revert {commit}
BUG-03 — Gate paths hardcoded in manhattan binary

File:           /usr/local/project-manhattan/bin/manhattan
                /usr/local/project-manhattan/etc/manhattan.json (add gate_paths key)
Expected change: 1. Add "gate_paths" array to manhattan.json with the three canonical paths:
                    ["/usr/local/project-manhattan/etc", "/Library/LaunchDaemons", "~/Library/LaunchAgents"]
                 2. In manhattan binary GATE_PATHS block: read from manhattan.json["gate_paths"]
                    instead of hardcoded values.
                 3. If config key missing: fall back to hardcoded values with a warning (not a crash).
Risk level:     LOW-MEDIUM — gate behavior path; test thoroughly before closing gate
Probe after:    grep -n "GATE_PATHS\|gate_paths" /usr/local/project-manhattan/bin/manhattan
                /usr/local/project-manhattan/bin/manhattan gate probe
                Both must work correctly with config-driven paths
Receipt:        PROJECT_MANHATTAN_GATE_PROBE_OK (gate probe still works after change)
Rollback:       git revert {commit}; restore manhattan.json gate_paths key; gate probe verify
BUG-04 — /Library/LaunchAgents/ not scanned

File:           /usr/local/project-manhattan/bin/manhattan-audit
                /usr/local/project-manhattan/etc/manhattan.json (add scan domain)
Expected change: 1. Add "system_launchagents": "/Library/LaunchAgents" to
                    manhattan.json scan_domains section.
                 2. In manhattan-audit: add scan loop for this domain alongside existing
                    system_launchdaemons and user_launchagents loops.
                 3. Classify items in /Library/LaunchAgents against vendor prefixes and registry.
                    Any unregistered lab-like label → rogue.
                 4. TeamViewer plist at /Library/LaunchAgents/com.teamviewer.teamviewer.plist
                    must show as "admitted" after PH-03 registry update.
Risk level:     LOW — audit expansion only; no mutation
Probe after:    /usr/local/project-manhattan/bin/manhattan audit | grep "system_launchagents"
                /usr/local/project-manhattan/bin/manhattan audit | grep "teamviewer.teamviewer"
                teamviewer.teamviewer must appear and classify as "admitted"
Receipt:        Audit receipt now includes system_launchagents scan domain
Rollback:       git revert {commit}; remove scan_domains key from manhattan.json
BUG-05 — cloudflared plist XML parse error

File:           /usr/local/project-manhattan/bin/manhattan-audit
                (possibly also: ~/Library/LaunchAgents/work.minilab.cloudflared.plist)
Expected change: INVESTIGATE FIRST (in Phase 0):
                 1. Read the cloudflared plist file directly. Identify stray content after </plist>.
                 2. If trailing content only: add parser pre-processing step to strip content
                    after </plist> before XML parsing. Apply to all plists, not just cloudflared.
                 3. If structurally corrupt: escalate to Daniel before patching.
                 4. Validate: label extracted must be "work.minilab.cloudflared", not a path string.
Risk level:     LOW-MEDIUM — parser change affects all plist reads; test against all known plists
Probe after:    /usr/local/project-manhattan/bin/manhattan audit | grep "cloudflared"
                Must show label = "work.minilab.cloudflared" not a program_arguments path
Receipt:        None specific — audit label correctness is self-evidencing
Rollback:       git revert {commit}; if plist itself was touched: restore from git
BUG-06 — Receipt retention not implemented

File:           /usr/local/project-manhattan/bin/manhattan-daemon (or equivalent daemon loop)
Expected change: Add cleanup pass as final step in daemon loop after audit run:
                 1. find receipts older than 7 days matching "audit-*" pattern → delete
                 2. Mutation receipts (gate open/close, restart, repair): NEVER delete
                 3. Pattern match for "audit" prefix distinguishes from permanent receipts
                 4. Log how many audit receipts cleaned per cycle (to daemon stderr, not to receipt)
Risk level:     LOW — filesystem cleanup; permanent receipts protected by naming convention
Probe after:    Create synthetic old audit receipt, run daemon loop, verify it is deleted.
                Verify a synthetic gate receipt is NOT deleted.
Receipt:        None specific — retention is self-verifying by absence of old audit files
Rollback:       git revert {commit} (no receipts are lost that should not be lost)
BUG-07 — ttyskeepawake not checked in power probe

File:           /usr/local/project-manhattan/bin/manhattan-audit
Expected change: Add "ttyskeepawake" to the canonical pmset values checklist (alongside
                 the existing 8 values). Expected value: 1.
                 Ensure repair command in manhattan-daemon includes "ttyskeepawake 1"
                 in the pmset -a invocation.
Risk level:     VERY LOW — adds one value to existing check + repair; additive only
Probe after:    /usr/local/project-manhattan/bin/manhattan audit | grep "ttyskeepawake"
                pmset -g custom | grep ttyskeepawake
                Both must show ttyskeepawake = 1
Receipt:        PROJECT_MANHATTAN_POWER_POLICY_OK (updated to include ttyskeepawake in check)
Rollback:       git revert {commit}
6. No-Helper-Plist Compliance Check
For each behavior that might tempt a helper plist creation, here is where it lives instead and why no new plist is created.

Daily restart
Does NOT get a helper plist. Lives inside system_daemon loop (com.project-manhattan.daemon). The 300-second loop checks local time against per-LAB restart window. The daemon is already admitted, already KeepAlive=true, already running as root. StartCalendarInterval would require a new plist. The daemon loop does not.

Tunnel health monitoring
Does NOT get a helper plist. Lives inside manhattan-agent user_agent loop. The agent probes the G-01 endpoint on every cycle. The agent is admitted (after PH-05). A separate tunnel-health watchdog plist would be parallel authority — forbidden by P-07.

TeamViewer guardian
Does NOT get a helper plist. Two ownership points: system_daemon owns L-13 (system domain kickstart). user_agent owns L-14 (gui/501 bootstrap). Both are already admitted. A "TeamViewer guardian" daemon would be a duplicate watchdog — explicitly forbidden by operator decision (Section 11 of LIST v2).

cloudflared guardian
Does NOT get a helper plist. cloudflared itself is admitted at work.minilab.cloudflared in gui/501. The agent loop monitors and restarts it. The admitted cloudflared plist is the service definition. A guardian plist would be parallel authority.

Screensaver monitor
Does NOT get a helper plist. Lives inside manhattan-agent loop. The user_agent checks currentHost screensaver prefs on each cycle and repairs if needed. A separate screensaver monitor plist would run in gui/501 alongside the agent — duplicate authority.

Peer witness
Does NOT get a helper plist. Lives as a function inside system_daemon loop. The daemon already runs as root, can ping, nc, and eventually send WOL packets. A separate peer-witness daemon plist would add a third system domain launchd entry outside the registry — forbidden.

Receipt retention
Does NOT get a helper plist. Lives as the final step in the system_daemon loop after each audit. No cron job, no separate cleaner daemon, no launchd calendar job. The daemon runs every 300 seconds — cleanup cost is negligible inline.

7. Stop Conditions
These are hard stops. When one fires, the current phase halts. Human decision is required before the next action.

Stop condition	Trigger	What to do
identity_unknown	L-01: scutil names cannot be compared to config (config missing)	Fix config, re-run PH-00
identity_mismatch	L-01: one or more scutil names do not match per-LAB config values	Human identifies which machine this is before any action continues
receipt_store_missing	L-23: receipts directory missing or unwritable	Human repairs filesystem path before any gate action
gate_open_without_receipt	L-21: gate found open but no recent GATE_OPENED receipt exists	Do NOT auto-close; human must acknowledge what was done
filevault_on	L-03: fdesetup status shows FileVault On	Human must disable FileVault physically; no auto-repair possible
remote_management_not_installed	G-07 / L-25: ARD not installed on LAB	Human must install Remote Management (App Store or system) before Phase 6 L-25
cloudflare_tunnel_probe_missing	G-01 unresolved at time of L-16 implementation	Do not implement L-16 repair; leave probe as probe_missing state
user_agent_fails_to_bootstrap	Phase 5: launchctl print gui/501/com.project-manhattan.agent shows error or not-running after bootstrap attempt	Do not proceed to Phase 7; investigate why bootstrap failed
daily_restart_receipt_missing_before_restart	Phase 8: daemon reaches restart time but receipt store is unwritable	Do not execute shutdown -r now without writing receipt first; halt restart logic
post_reboot_manhattan_not_running	Phase 10: after reboot, daemon not detected within 5 minutes	Critical stop; investigate KeepAlive configuration and launchd state
mdm_conflict	G-05: MDM profile actively overrides Manhattan's defaults write repairs	Escalate to Daniel before Phase 6; repair actions will be silently reverted
rogue_items_detected_at_final_audit	Phase 10: audit shows rogue > 0	Resolve each rogue item (admit or delete, per human decision) before survival probe
bug05_plist_structurally_corrupt	Phase 2, BUG-05 investigation: cloudflared plist is not just trailing content	Escalate to Daniel; do not apply speculative fix to parser
8. Receipts List Per Phase
Phase 0
PH-00-BASELINE-READ-COMPLETE (manual notation)
Phase 1
G-01-TUNNEL-PROBE-ENDPOINT-RESOLVED
G-02-PEER-MAC-LAB8GB
G-05-MDM-STATUS-RESOLVED
G-07-REMOTE-MGMT-STATE-RESOLVED
G-08-ETH-IFACE-RESOLVED
PH-01-GHOST-RESOLUTION-RECORD (manual notation with all confirmed values)
Phase 2
PROJECT_MANHATTAN_GATE_OPENED
PROJECT_MANHATTAN_CODE_PATCH_BUG07_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG01_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG02_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG04_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG03_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG05_APPLIED
PROJECT_MANHATTAN_CODE_PATCH_BUG06_APPLIED
PROJECT_MANHATTAN_GATE_PROBE_OK (from corrected BUG-01 code)
PROJECT_MANHATTAN_GATE_CLOSED
Phase 3
PROJECT_MANHATTAN_GATE_OPENED
PROJECT_MANHATTAN_REGISTRY_NORMALIZED
PROJECT_MANHATTAN_GATE_CLOSED
Phase 4
PROJECT_MANHATTAN_IDENTITY_VERIFIED
PROJECT_MANHATTAN_AUTO_LOGIN_OK (or _DRIFT)
PROJECT_MANHATTAN_FILEVAULT_OFF_OK (or _HUMAN_REQUIRED)
PROJECT_MANHATTAN_WIFI_OK (or _DRIFT)
PROJECT_MANHATTAN_ETHERNET_PEER_OK (or _DRIFT)
PROJECT_MANHATTAN_POWER_POLICY_OK (or _REPAIRED — probe state)
PROJECT_MANHATTAN_TUNNEL_HEALTH_OK (or _FAILED or _PROBE_MISSING if G-01 unresolved)
PROJECT_MANHATTAN_REMOTE_MANAGEMENT_OK (or _DRIFT)
PROJECT_MANHATTAN_BLUETOOTH_OK (or _REQUIRES_MANUAL)
PROJECT_MANHATTAN_AIRDROP_OK (or _DISABLED)
PROJECT_MANHATTAN_HANDOFF_OK (or _DISABLED)
PROJECT_MANHATTAN_PH04_PROBE_COMPLETE
Phase 5
PROJECT_MANHATTAN_GATE_OPENED
PROJECT_MANHATTAN_AGENT_ADMITTED
PROJECT_MANHATTAN_GATE_CLOSED
Phase 6
PROJECT_MANHATTAN_SSH_REPAIRED (if SSH was off)
PROJECT_MANHATTAN_POWER_POLICY_REPAIRED (if pmset values were wrong)
PROJECT_MANHATTAN_FIREWALL_REPAIRED (if firewall was on)
PROJECT_MANHATTAN_PF_KILLED (if pf was enabled)
PROJECT_MANHATTAN_WIFI_DRIFT (if no internet — not auto-repairable)
PROJECT_MANHATTAN_ETHERNET_PEER_REPAIRED (if static IP was wrong)
PROJECT_MANHATTAN_TEAMVIEWER_SERVICE_REPAIRED (if service was down)
PROJECT_MANHATTAN_REMOTE_MANAGEMENT_OK (if kickstart worked)
PROJECT_MANHATTAN_AUTO_LOGIN_REQUIRES_MDM (if MDM-locked)
PROJECT_MANHATTAN_FILEVAULT_ON_HUMAN_REQUIRED (if FileVault on)
PROJECT_MANHATTAN_BLUETOOTH_REQUIRES_MANUAL (if repair failed on macOS 12+)
Phase 7
PROJECT_MANHATTAN_SCREENSAVER_REPAIRED (if prefs were wrong)
PROJECT_MANHATTAN_TEAMVIEWER_SESSION_OK
PROJECT_MANHATTAN_CLOUDFLARED_RESTARTED
PROJECT_MANHATTAN_TUNNEL_REFRESHED (or _FAILED)
PROJECT_MANHATTAN_LOGIN_SURVIVAL_OK (or _FAILED)
PROJECT_MANHATTAN_AIRDROP_OK (or _REQUIRES_MANUAL)
PROJECT_MANHATTAN_HANDOFF_OK
PROJECT_MANHATTAN_TCC_HUMAN_REQUIRED (if TCC drift detected)
Phase 8
PROJECT_MANHATTAN_DAILY_REFRESH_STARTED
PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_OK (×4 — one per phase step)
PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED (written BEFORE shutdown -r now)
Phase 9
PROJECT_MANHATTAN_PEER_OK (or _PING_FAILED)
PROJECT_MANHATTAN_PEER_WOL_SENT (only after G-02+G-03 resolved)
Phase 10
PROJECT_MANHATTAN_POST_REBOOT_SURVIVAL_OK (or _PARTIAL)
Full audit receipt: rogue=0, stale=0, drift_items=0 (or honest human-required items)
PH-10-LAB8GB-V2-COMPLETE (manual notation)
Phase 11
PH-11-PORTING-KIT-READY (manual notation)
9. First Executable Slice
Recommendation: Phase 0 + Phase 1.

These two phases together are:

Fully read-only
Cannot harm the running v1 system
Cannot trigger any launchd mutation
Cannot open the gate
Resolve 5 of 8 ghosts (G-01, G-02, G-05, G-07, G-08)
Produce the evidence base required to correctly execute Phase 2 patches
The alternative of starting with Phase 2 (code patches) before Phase 1 (ghost resolution) risks:

Patching BUG-03 config with the wrong Ethernet interface name (G-08 still unknown)
Patching BUG-04 and then having the audit find items in /Library/LaunchAgents/ that cannot be classified correctly because the registry is not yet normalized
Phase 0 + Phase 1 is the minimum slice that produces receipts, moves the system forward, and leaves nothing broken.

First slice completion criteria:

Phase 0 baseline read complete (no system mutation)
Phase 1 ghost resolution record exists with documented values for G-01, G-02, G-05, G-07, G-08
G-03 (WOL policy) escalated to Daniel for decision
G-04 (Bluetooth repair reliability) scheduled for per-LAB test during Phase 6
Daniel must sign Phase 1 ghost resolution record before Phase 2 begins. Phase 2 introduces the first gate open on this pass.

End of PROJECT MANHATTAN v2 Implementation Plan.
12 phases. 8 ghosts mapped. 7 bugs inventoried. 7 no-helper-plist justifications. 13 stop conditions. Receipts enumerated per phase.
First executable slice: Phase 0 + Phase 1 (read-only). No system mutation until Daniel signs.