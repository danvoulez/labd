# PROJECT MANHATTAN LIST v2 — Canonicalization Pass
**Revised Draft for Daniel Review**
**Status:** Revised draft — not final — awaiting Daniel sign-off
**Source:** LIST v2 (Daniel's semantic authority)
**Evidence base:** LAB 8GB current state (evidence/receipt, not canon source)
**Constraint:** No system mutations in this pass

---

## 1. Revised Canonical Principles

**P-01 — A LAB is a caged headless appliance, not a personal Mac.**
It must power on, log in, stay awake, expose all remote access surfaces, keep its peer link, refresh daily, restart on schedule, and write receipts — without any local human presence.

**P-02 — Canon derives from operational requirements, not from local garbage.**
Survey output from any LAB is evidence of local drift. It is not a canon source. Garbage found on any machine does not expand the canonical item set. The canonical source is this document as reviewed and signed by Daniel.

**P-03 — Each canonical item has exactly one primary instrument.**
A canonical responsibility cannot be co-owned by a daemon, an agent, a watchdog, and a shell script simultaneously. One primary instrument. Dependencies are listed and do not share ownership. `config_value` is never a primary instrument — it is always a dependency.

**P-04 — Allowed final classifications: `admitted`, `vendor`, `out_of_scope`, `deleted`.**
Forbidden forever: `quarantine`, `rogue` (transient audit state only), `stale` (transient audit state only), `unknown_lab_infra`, `parallel_authority`, `duplicate_watchdog`, `scheduled_shutdown_wake`.

**P-05 — Identity check precedes all other actions.**
If LAB identity is unknown or mismatched, Manhattan halts destructive and mutating actions, writes the identity drift receipt, and stops. No policy is applied to a machine that does not know what it is.

**P-06 — Manhattan does not fake closure.**
TCC permissions, FileVault, Keychain, Wi-Fi credentials: detect honestly, report truthfully, write the correct receipt. A success receipt requires runtime proof, not just a plist write or a command that returned 0.

**P-07 — No new launchd infrastructure beyond the admitted registry.**
The filesystem gate enforces this physically. No helper plist, no parallel watchdog, no repair loop, no scheduled-reboot job, no guardian daemon outside the admitted registry. All new behavior enters through Manhattan canon, config, registry, and receipts.

**P-08 — Every meaningful action produces a receipt. Receipts never contain secrets.**
No credentials, passwords, keys, tokens, or sensitive values appear in any receipt, log, or state file.

**P-09 — The sudo password is the human signature boundary.**
Gate open requires sudo. Gate close requires sudo. `sudo -K` follows every gate close. This is the only human-enforced mutation boundary.

**P-10 — Daily restart is `shutdown -r now`. Not shutdown. Not pmset. Not a helper plist.**
The system daemon triggers restart at the per-LAB canonical time. No `pmset repeat` event. No `pmset schedule` event. No `StartCalendarInterval` launchd job. The 300-second daemon loop handles timing internally.

**P-11 — The three LABs must not restart simultaneously.**
Stagger is canonical. Each LAB has a fixed restart time within the 06:00–07:00 window.

---

## 2. Revised Atomic Canonical Items

---

**L-01**
**Name:** LAB Identity
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** config_value (expected ComputerName, HostName, LocalHostName, LAB_ID per machine)
**Probe:**
```
scutil --get ComputerName
scutil --get HostName
scutil --get LocalHostName
```
Compare all three against per-LAB config values.
**Expected state:** All three names match LAB config. LAB_ID deterministic from hostname.
**Repair/action:** None. Identity mismatch or unknown → halt all mutating actions → write drift receipt → stop.
**Forbidden action:** Apply any mutating or repair action while identity is unknown or mismatched. Apply LAB_512 topology to LAB_8GB or vice versa.
**Drift condition:** `identity_unknown`, `identity_mismatch`, `hostname_mismatch`, `wrong_lab_profile_applied`
**Receipt:** `PROJECT_MANHATTAN_IDENTITY_VERIFIED`, `PROJECT_MANHATTAN_IDENTITY_MISMATCH`
**Notes:** Must be the first check in every audit cycle and before every repair action. Per-LAB expected values stored in config, not hardcoded in Manhattan source.

---

**L-02**
**Name:** Auto-Login Policy
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** config_value (LAB user account name), L-03 (FileVault must be off — FileVault on blocks auto-login)
**Probe:**
```
defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser
```
Key must be present and equal to the LAB user account name.
**Expected state:** `autoLoginUser` = LAB user. No password required at login, wake, or restart.
**Repair/action:** Attempt: `defaults write /Library/Preferences/com.apple.loginwindow autoLoginUser {user}`. Then verify by reading back. If MDM-locked and state still wrong: write `auto_login_requires_mdm`. Closure requires reboot proof — a successful login after restart, or verified loginwindow state post-reboot, or explicit human/MDM receipt. Do not claim fixed from plist write alone.
**Forbidden action:** Claim auto-login fixed without reboot-level verification. Skip check because repair is uncertain.
**Drift condition:** `auto_login_off`, `login_password_blocks_recovery`, `auto_login_requires_mdm`
**Receipt:** `PROJECT_MANHATTAN_AUTO_LOGIN_OK`, `PROJECT_MANHATTAN_AUTO_LOGIN_DRIFT`, `PROJECT_MANHATTAN_AUTO_LOGIN_REQUIRES_MDM`
**Notes:** On macOS 13+ with MDM enrollment, auto-login may require a configuration profile. Probe is reliable. Repair is best-effort. Closure requires post-reboot evidence, not just successful plist write.

---

**L-03**
**Name:** FileVault Off
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
fdesetup status
```
Must return: `FileVault is Off.`
**Expected state:** FileVault is Off.
**Repair/action:** Cannot disable headlessly without pre-authorized recovery key or user password. Write `filevault_on`. Mark as human_required. Do not attempt to disable without credential.
**Forbidden action:** Attempt FileVault disable without credential. Fake closure. Skip check.
**Drift condition:** `filevault_on`
**Receipt:** `PROJECT_MANHATTAN_FILEVAULT_OFF_OK`, `PROJECT_MANHATTAN_FILEVAULT_ON_HUMAN_REQUIRED`
**Notes:** FileVault on blocks unattended boot after restart and blocks auto-login (L-02). If on, this is a hard drift requiring physical presence. Manhattan detects and reports only.

---

**L-04**
**Name:** Keychain Usable
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** user session (auto-login establishes this), L-02
**Probe:**
```
security show-keychain-info ~/Library/Keychains/login.keychain-db
```
Must not return "Keychain locked." Run in user session context.
Indirect confirmation: Wi-Fi reconnects at boot (credential in keychain), cloudflared starts without auth error.
**Expected state:** Login keychain unlocked. Wi-Fi credential accessible. cloudflared credential accessible.
**Repair/action:** If keychain locked (rare on auto-login machines): human action required — cannot unlock headlessly without user password. Write `keychain_unavailable`.
**Forbidden action:** Log keychain passwords. Store credentials in receipts, state files, or logs.
**Drift condition:** `keychain_unavailable`, `keychain_locked`
**Receipt:** `PROJECT_MANHATTAN_KEYCHAIN_OK`
**Notes:** On auto-login machines, login keychain unlocks automatically at session start. Direct keychain content inspection is forbidden. Verification is indirect via L-05 and L-15 success.

---

**L-05**
**Name:** Wi-Fi On and Internet Route Active
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** config_value (Wi-Fi interface name per LAB)
**Probe:**
```
networksetup -getairportpower {wifi_iface}    # must return "On"
scutil --nwi | grep -A2 {wifi_iface}          # IPv4 route present
ping -c 2 -q 1.1.1.1                          # internet reachable
```
**Expected state:** Wi-Fi power on. IPv4 assigned. Internet reachable via Wi-Fi interface.
**Repair/action:** If Wi-Fi power off: `networksetup -setairportpower {wifi_iface} on`. If Wi-Fi on but no internet: no auto-repair (credential or ISP issue) — write `wifi_no_internet_route`.
**Forbidden action:** Modify Wi-Fi credentials or SSID. Route internet traffic through Ethernet peer interface.
**Drift condition:** `wifi_off`, `wifi_service_missing`, `wifi_no_internet_route`
**Receipt:** `PROJECT_MANHATTAN_WIFI_OK`, `PROJECT_MANHATTAN_WIFI_DRIFT`
**Notes:** Interface name is a per-LAB config_value. Internet probe failure distinguishes by checking whether interface has an IP assignment vs. no IP — determines ISP-side vs. LAB-side failure.

---

**L-06**
**Name:** Ethernet Peer Link (Private Static)
**Applies to:** pair_8gb_512
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** config_value (ethernet interface name, static IP, peer IP, subnet mask)
**Probe:**
```
networksetup -getinfo {eth_iface}    # IP matches config, Router empty, DNS empty
ifconfig {eth_iface}                 # interface active
```
**Expected state:**
- LAB_8GB ethernet: IP=10.88.0.9, mask=255.255.255.252, gateway=empty, DNS=empty
- LAB_512 ethernet: IP=10.88.0.10, mask=255.255.255.252, gateway=empty, DNS=empty
- Interface up and configured
**Repair/action:**
```
networksetup -setmanual {eth_iface} {ip} {subnet} ""
networksetup -setdnsservers {eth_iface} Empty
```
If interface physically down (cable unplugged): write `ethernet_interface_down`, no auto-repair possible.
**Forbidden action:** Set a gateway on the Ethernet peer interface. Set DNS on the Ethernet peer interface. Allow Ethernet to carry internet traffic.
**Drift condition:** `ethernet_peer_missing`, `ethernet_static_ip_wrong`, `ethernet_gateway_present`, `ethernet_dns_present`, `ethernet_interface_down`
**Receipt:** `PROJECT_MANHATTAN_ETHERNET_PEER_OK`, `PROJECT_MANHATTAN_ETHERNET_PEER_REPAIRED`
**Notes:** Interface name (en1, en2, etc.) is a per-LAB config_value (Ghost G-08). A gateway present on this interface risks routing conflicts with Wi-Fi and must never exist.

---

**L-07**
**Name:** Peer Witness
**Applies to:** pair_8gb_512
**Canon status:** canonical
**Primary instrument:** peer_witness
**Dependencies:** L-06 (Ethernet peer link), config_value (peer IP, peer health port, peer MAC for WOL)
**Probe:**
```
ping -c 3 -q {peer_ip}                                       # packet loss = 0
nc -z -G 3 {peer_ip} 22                                      # port 22 open
curl -sf --max-time 3 http://{peer_ip}:{health_port}/health  # health endpoint responds
```
WOL: MAC stored in config_value. Sent only when peer is confirmed down (policy per G-03).
**Expected state:** Peer ping OK. Peer SSH port 22 open. Peer health endpoint responding.
**Repair/action:** If peer down: write `PROJECT_MANHATTAN_PEER_PING_FAILED`. Send WOL magic packet to peer MAC per G-03 policy. Wait 60 seconds. Re-probe once. If still down: write receipt and stop — human action required.
**Forbidden action:** SSH into peer and run commands. Edit peer registry. Open peer gate. Mutate peer launchd. Auto-reboot peer outside admitted policy. Become peer authority.
**Drift condition:** `peer_ping_failed`, `peer_ssh_unreachable`, `peer_health_stale`, `peer_wol_sent`
**Receipt:** `PROJECT_MANHATTAN_PEER_OK`, `PROJECT_MANHATTAN_PEER_PING_FAILED`, `PROJECT_MANHATTAN_PEER_WOL_SENT`
**Notes:** Each machine runs peer_witness toward the other. Neither machine becomes the other's authority. Peer MAC addresses are config_values (Ghost G-02). WOL retry/cooldown policy is Ghost G-03.

---

**L-08**
**Name:** SSH Remote Login On, Port 22
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
systemsetup -getremotelogin                 # "Remote Login: On"
lsof -nP -iTCP:22 -sTCP:LISTEN             # sshd listening on port 22
```
**Expected state:** Remote Login On. sshd listening on port 22. No extra sshd on any other port.
**Repair/action:** `systemsetup -setremotelogin on`. Verify after setting.
**Forbidden action:** Create alternate sshd on any other port without explicit registry admission. Disable SSH.
**Drift condition:** `ssh_off`, `ssh_port_22_not_listening`, `unexpected_extra_sshd`
**Receipt:** `PROJECT_MANHATTAN_SSH_OK`, `PROJECT_MANHATTAN_SSH_REPAIRED`
**Notes:** Requires root. System daemon performs repair. Any sshd listener beyond port 22 is drift requiring deletion, not quarantine.

---

**L-09**
**Name:** pmset Policy — No Sleep, Power Recovery, Wake for Network
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
pmset -g custom    # check all 9 canonical values
pmset -g sched     # must return empty output
```
**Expected state:**
```
sleep          = 0
displaysleep   = 0
disksleep      = 0
standby        = 0
powernap       = 0
tcpkeepalive   = 1
womp           = 1
autorestart    = 1
ttyskeepawake  = 1
pmset sched    = empty (no shutdown/sleep/wake/poweron/wakepoweron events)
```
**Repair/action:**
```
pmset -a sleep 0 displaysleep 0 disksleep 0 standby 0 powernap 0 tcpkeepalive 1 womp 1 autorestart 1 ttyskeepawake 1
```
Verify after setting. System updates and some software may reset pmset — daemon's 5-minute cycle detects and repairs.
**Forbidden action:** Set any sleep timer. Set standby. Enable energy saver or power nap. Create any `pmset repeat` or `pmset schedule` event of any kind.
**Drift condition:** `sleep_enabled`, `display_sleep_enabled`, `disk_sleep_enabled`, `standby_enabled`, `powernap_enabled`, `autorestart_off`, `wake_for_network_off`, `ttyskeepawake_off`, `scheduled_shutdown_or_wake_present`
**Receipt:** `PROJECT_MANHATTAN_POWER_POLICY_OK`, `PROJECT_MANHATTAN_POWER_POLICY_REPAIRED`
**Notes:** Nine canonical values checked and repaired atomically. Other pmset keys (`SleepServices`, `networkoversleep`, `SleepOnPowerButton`) are observed but not part of the canonical set.

---

**L-10**
**Name:** macOS Firewall Off
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate
# must return: "Firewall is disabled. (State = 0)"
```
**Expected state:** Firewall disabled. State = 0.
**Repair/action:** `/usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate off`
**Forbidden action:** Enable firewall. Use firewall as a default security posture.
**Drift condition:** `firewall_enabled`, `firewall_state_unknown`
**Receipt:** `PROJECT_MANHATTAN_FIREWALL_OFF_OK`, `PROJECT_MANHATTAN_FIREWALL_REPAIRED`
**Notes:** macOS system updates can silently re-enable the firewall. Requires root. Daemon repairs automatically on detection.

---

**L-11**
**Name:** pf Disabled
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
pfctl -s info 2>/dev/null | grep "^Status:"
# must return: "Status: Disabled"
```
**Expected state:** pf disabled. No rules loaded.
**Repair/action:** `pfctl -d`
**Forbidden action:** Load pf rules. Use pf as a security or routing mechanism.
**Drift condition:** `pf_enabled`, `pf_rules_loaded`
**Receipt:** `PROJECT_MANHATTAN_PF_DISABLED_OK`, `PROJECT_MANHATTAN_PF_KILLED`
**Notes:** VPNs and networking tools may activate pf. Daemon kills on every cycle.

---

**L-12**
**Name:** Screensaver and Lock Screen Disabled
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** user session active, L-02 (auto-login establishes session)
**Probe:**
```
defaults -currentHost read com.apple.screensaver askForPassword    # must be 0
defaults -currentHost read com.apple.screensaver idleTime          # must be 0
```
Run in user context, not root.
**Expected state:** `askForPassword = 0`. Idle time = 0 (screensaver disabled). No password gate on wake or restart.
**Repair/action:**
```
defaults -currentHost write com.apple.screensaver askForPassword -int 0
defaults -currentHost write com.apple.screensaver idleTime -int 0
```
Run via Manhattan user_agent as the LAB user.
**Forbidden action:** Enable lock screen. Enable screensaver password.
**Drift condition:** `screensaver_password_enabled`, `lock_screen_blocks_recovery`
**Receipt:** `PROJECT_MANHATTAN_SCREENSAVER_OK`, `PROJECT_MANHATTAN_SCREENSAVER_REPAIRED`
**Notes:** User-level preferences. System daemon running as root cannot write to user's `currentHost` domain reliably. This belongs to user_agent. On some newer macOS, may require MDM profile.

---

**L-13**
**Name:** TeamViewer System Service
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** launchd_admitted_service
**Dependencies:** TeamViewer installed at `/Applications/TeamViewer.app`
**Probe:**
```
launchctl print system/com.teamviewer.service
# state = running, pid present, last_exit = never exited
```
**Expected state:** Running. Pid present.
**Repair/action:** `launchctl kickstart -k system/com.teamviewer.service`. If not loaded: `launchctl bootstrap system /Library/LaunchDaemons/com.teamviewer.teamviewer_service.plist && launchctl kickstart -k system/com.teamviewer.service`
**Forbidden action:** Delete TeamViewer plist. Create a parallel TeamViewer guardian daemon. Mark TeamViewer as optional.
**Drift condition:** `teamviewer_service_down`, `teamviewer_not_installed`
**Receipt:** `PROJECT_MANHATTAN_TEAMVIEWER_SERVICE_OK`, `PROJECT_MANHATTAN_TEAMVIEWER_SERVICE_REPAIRED`
**Notes:** TeamViewer is mandatory canonical. It is vendor-implemented (managed=false for plist ownership) but canonical for presence and health. If not installed: human-required action. Daily refresh at 06:00 (LAB_8GB window): `launchctl kickstart -k system/com.teamviewer.service`.

---

**L-14**
**Name:** TeamViewer User Session Component
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** user session active, TeamViewer installed, L-13 running
**Probe:**
```
launchctl print gui/501/com.teamviewer.teamviewer
# state = running or loaded
```
Plist at: `/Library/LaunchAgents/com.teamviewer.teamviewer.plist`
**Expected state:** Loaded and running in gui/501.
**Repair/action:** `launchctl bootstrap gui/501 /Library/LaunchAgents/com.teamviewer.teamviewer.plist`
**Forbidden action:** Replace TeamViewer user agent plist. Create a parallel session watcher.
**Drift condition:** `teamviewer_user_agent_missing`, `teamviewer_session_down`
**Receipt:** `PROJECT_MANHATTAN_TEAMVIEWER_SESSION_OK`
**Notes:** Manhattan v1 does NOT scan `/Library/LaunchAgents/` — this label is currently invisible. v2 must add this scan path (CC-4). This item requires user_agent context. TeamViewer is mandatory canonical — this item is not optional.

---

**L-15**
**Name:** cloudflared Process Health
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** launchd_admitted_service
**Dependencies:** user session active, cloudflared binary installed, tunnel credentials in Keychain (L-04)
**Probe:**
```
launchctl print gui/501/work.minilab.cloudflared
# state = running, pid present
```
**Expected state:** Running. Pid present. Last exit = never exited.
**Repair/action:** `launchctl bootout gui/501/work.minilab.cloudflared 2>/dev/null; launchctl bootstrap gui/501 {plist_path}`
**Forbidden action:** Run cloudflared outside admitted launchd context. Create a parallel cloudflared guardian.
**Drift condition:** `cloudflared_down`, `cloudflared_refresh_failed`
**Receipt:** `PROJECT_MANHATTAN_CLOUDFLARED_OK`, `PROJECT_MANHATTAN_CLOUDFLARED_RESTARTED`
**Notes:** This is PROCESS HEALTH ONLY. Process running ≠ tunnel healthy — see L-16. The cloudflared plist currently has an XML parse error that corrupts the program_arguments field in the audit. Data quality bug to fix in v2.

---

**L-16**
**Name:** Cloudflare Tunnel Health
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** L-15 (cloudflared process running)
**Probe:** Probe unresolved — see Ghost G-01. Working candidates:
```
curl -sf --max-time 5 http://localhost:2000/metrics
cloudflared tunnel info {tunnel_name}
```
Check response for active connection indicator, not just HTTP 200.
**Expected state:** Tunnel established and active. Not just process running — actual Cloudflare connection alive.
**Repair/action:** Restart cloudflared (L-15 repair sequence). Re-probe tunnel after 15 seconds. Write receipt.
**Forbidden action:** Claim tunnel healthy based solely on process state. Create a separate tunnel-health watchdog daemon.
**Drift condition:** `cloudflare_tunnel_unhealthy`, `cloudflared_running_but_tunnel_dead`, `cloudflare_tunnel_probe_missing`
**Receipt:** `PROJECT_MANHATTAN_TUNNEL_HEALTH_OK`, `PROJECT_MANHATTAN_TUNNEL_REFRESHED`, `PROJECT_MANHATTAN_TUNNEL_FAILED`
**Notes:** Most critical gap between LIST v2 and Manhattan v1. The exact probe endpoint must be determined before L-16 can be implemented (Ghost G-01). Daily refresh at 06:20 (LAB_8GB window): probe tunnel, restart and re-probe if unhealthy.

---

**L-17**
**Name:** Login Survival
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** user session active, L-13, L-14, L-15, L-16
**Probe:** On session start (RunAtLoad=true on user agent): verify cloudflared running, tunnel healthy, TeamViewer service running, TeamViewer user agent loaded. Write result.
**Expected state:** All remote access surfaces verified OK within 60 seconds of session start.
**Repair/action:** Start any missing remote access services (bootout+bootstrap or kickstart). Re-probe. Write receipt.
**Forbidden action:** Create additional helper plists for this check. Assume previous session's state is still valid.
**Drift condition:** `login_survival_failed`, `login_cloudflared_missing`, `login_teamviewer_missing`, `login_tunnel_dead`
**Receipt:** `PROJECT_MANHATTAN_LOGIN_SURVIVAL_OK`, `PROJECT_MANHATTAN_LOGIN_SURVIVAL_FAILED`
**Notes:** NOT implemented in Manhattan v1. Requires Manhattan user_agent (`com.project-manhattan.agent`). The user_agent is canonical in v2.

---

**L-18**
**Name:** Daily Rejuvenation — Pre-Restart Phases
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** L-13, L-14, L-15, L-16, user_agent (for gui/501 restarts), config_value (per-LAB window times)
**Probe:** At each 5-minute loop, system_daemon checks local time against per-LAB refresh window. If in window and no restart today: begin phase execution.
**Phase sequence (LAB_8GB example — other LABs offset by stagger):**
```
06:00  restart TeamViewer service                   → PHASE_TEAMVIEWER_OK
06:10  restart cloudflared (bootout + bootstrap)    → PHASE_CLOUDFLARED_OK
06:20  verify Cloudflare tunnel health              → PHASE_TUNNEL_OK
06:30  verify all admitted remote access surfaces   → PHASE_SURFACES_OK
06:35  write pre-restart receipt                    → PRE_RESTART_READY
06:40  trigger L-19 (daily restart)
```
**Expected state:** All phase receipts written before per-LAB restart time.
**Repair/action:** If a phase fails: write drift receipt and continue to next phase. Do not abort restart due to phase failure.
**Forbidden action:** Shutdown without restart. Use pmset repeat/schedule for timing. Create a separate launchd job for scheduling. Restart all services simultaneously. Skip restart because services appear healthy.
**Drift condition:** `daily_refresh_missed`, `refresh_phase_failed`
**Receipt:** `PROJECT_MANHATTAN_DAILY_REFRESH_STARTED`, `PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_OK`, `PROJECT_MANHATTAN_DAILY_REFRESH_PHASE_FAILED`
**Notes:** Daemon tracks "restart happened today" via last restart receipt timestamp. If `DAILY_RESTART_REQUESTED` receipt exists within 23 hours, skip window. Phase timing has ±5 min accuracy given 300-second loop granularity — acceptable.

---

**L-19**
**Name:** Daily Restart
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** L-18 (pre-restart phases completed or timed out), config_value (per-LAB restart time)
**Probe:** Current local time in per-LAB restart window (±5 min). No restart in past 23 hours (verified via last `DAILY_RESTART_REQUESTED` receipt timestamp).
**Expected state:** Machine restarts once per day at per-LAB canonical time. Machine returns and passes L-20.
**Per-LAB restart times:**
```
LAB_8GB:  06:40 local
LAB_512:  06:50 local
LAB_256:  06:59 local
```
**Repair/action:** Write `PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED` receipt first. Then: `shutdown -r now`
**Forbidden action:** `shutdown` without `-r`. Create pmset scheduled wake/sleep/shutdown event. Create a launchd StartCalendarInterval job for this. Skip daily restart because services seem healthy.
**Drift condition:** `daily_restart_missed`, `restart_window_exceeded`
**Receipt:** `PROJECT_MANHATTAN_DAILY_RESTART_REQUESTED` (written BEFORE reboot)
**Notes:** Receipt written before shutdown executes. After reboot, daemon starts fresh and runs L-20. KeepAlive=true ensures daemon restarts immediately after reboot. Per-LAB restart time is a config_value defaulting to the canonical stagger above.

---

**L-20**
**Name:** Post-Reboot Survival Probe
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** all admitted services, user_agent (for session-bound checks after login)
**Probe:** On daemon startup, if uptime < 10 minutes and `DAILY_RESTART_REQUESTED` receipt exists within past 2 hours: run full survival check. System checks: SSH, pmset, firewall, pf, gate state, Manhattan daemon itself. User-session checks (via user_agent after login): cloudflared, tunnel health, TeamViewer.
**Expected state:** All admitted services running. All probes ok. drift_items = 0.
**Repair/action:** Same as individual item repair policies. Write per-item repair receipts if needed.
**Forbidden action:** Claim survival OK without probing. Skip survival because uptime appears short.
**Drift condition:** `post_reboot_survival_failed`, plus all individual drift conditions
**Receipt:** `PROJECT_MANHATTAN_POST_REBOOT_SURVIVAL_OK`, `PROJECT_MANHATTAN_POST_REBOOT_SURVIVAL_PARTIAL`
**Notes:** Survival probe is both a reboot confirmation and a live correctness check. PARTIAL = some services recovered, some did not — human attention needed.

---

**L-21**
**Name:** Manhattan Filesystem Gate
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** gate paths exist
**Probe:**
```
ls -ldO /usr/local/project-manhattan/etc
ls -ldO /Library/LaunchDaemons
ls -ldO ~/Library/LaunchAgents
```
Check `uchg` present for all three. Gate probe is classified `admitted` in the audit — not `candidate` (current v1 code bug to fix in v2).
**Expected state:** All three gate paths show `uchg`. Any gate open must have a recent `PROJECT_MANHATTAN_GATE_OPENED` receipt.
**Repair/action:** If gate found open without a recent GATE_OPENED receipt: write `gate_open_without_receipt`. Do NOT auto-close — operator may be actively working. Report and wait for human.
**Forbidden action:** Auto-close gate. Classify gate probe as `candidate` in v2 code. Ignore gate state.
**Drift condition:** `gate_unlocked`, `gate_path_missing_uchg`, `gate_open_without_receipt`, `unauthorized_plist_birth`
**Receipt:** `PROJECT_MANHATTAN_GATE_CLOSED`, `PROJECT_MANHATTAN_GATE_OPENED`, `PROJECT_MANHATTAN_GATE_PROBE_OK`
**Notes:** Gate paths are currently hardcoded in the manhattan bash binary. v2 must read them from config. Individual plist files within gate dirs are NOT uchg-flagged — only the directory itself. This blocks new file creation but not overwrite of existing inodes. This boundary must be documented honestly and may be tightened in a future pass.

---

**L-22**
**Name:** No Parallel Authority
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** registry, L-21 (gate)
**Probe:** Every audit: classify all launchd plists. Any lab-like label not in registry → rogue. Any registry-admitted label now missing or in wrong domain → drift.
**Expected state:** rogue = 0, stale = 0 in every audit cycle.
**Repair/action:** Rogue items: human decision required (admit or delete). Manhattan does NOT auto-delete. Manhattan does NOT auto-admit. Write drift receipt per rogue item found.
**Forbidden action:** Auto-delete rogue items. Auto-admit items to registry without human signature. Create any new helper plist outside the registry.
**Drift condition:** `parallel_authority_detected`, `rogue_launchd`, `unadmitted_helper_daemon`, `duplicate_watchdog`
**Receipt:** Audit receipt showing `rogue=0, stale=0` proves clean state.
**Notes:** Gate enforces physically. Audit detects continuously. Registry is the single truth. LAB_NEEDLES list is a config_value maintained per LAB lineage.

---

**L-23**
**Name:** Receipt Production and Retention
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** user_agent (also writes receipts to same tree), state path writable
**Probe:** Last audit receipt timestamp must be < 10 minutes old. Receipts directory must exist. No receipt file contains secret values.
**Expected state:** Receipts directory present. Audit receipts current. Mutation/gate/restart receipts permanent. No secret values in any receipt.
**Retention policy:**
```
Audit receipts:           keep 7 days, then delete
Mutation receipts:        keep forever
Gate open/close:          keep forever
Restart receipts:         keep forever
Recovery/repair receipts: keep forever
```
**Repair/action:** If receipts directory missing or unwritable:
	- write to stderr and syslog/daemon stderr if possible
	- refuse success closure (do not emit success receipts)
	- write `PROJECT_MANHATTAN_RECEIPT_STORE_MISSING`
	- require human repair before proceeding
**Forbidden action:** Write credentials, passwords, keys, or secret values to any receipt. Write success receipt without runtime probe evidence. Delete receipts to fake clean state.
**Drift condition:** `receipts_directory_missing`, `audit_receipt_stale`
**Receipt:** (every audit run is itself a receipt)
**Notes:** No rotation is currently implemented in Manhattan v1. v2 must implement the 7-day audit receipt cleanup. Both system_daemon and user_agent write to the same receipts path.

---

**L-24**
**Name:** Drift Detection and Reporting
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** all canonical items L-01 through L-23
**Probe:** Continuous at every 5-minute cycle. `drift.json` overwritten with current actionable state on every run.
**Expected state:** `drift.json items = []`. All probe statuses = ok.
**Repair/action:** Drift detected → attempt repair per individual item policy → re-probe → write receipt. If repair fails or is not possible: write drift receipt and leave for human.
**Forbidden action:** Delete `drift.json` to fake clean state. Suppress rogue detection because an item seems benign. Ignore drift without a receipt.
**Drift condition:** (every L-item defines its own drift condition; drift detection is the mechanism)
**Receipt:** Audit receipt contains `drift_count` and list of items. `drift.json` maintained separately.
**Notes:** Manhattan v1 detects drift but does NOT repair it — all repair_policy values are declared but unimplemented. v2 must implement per-item repair as specified in each L-item above.

---

**L-25**
**Name:** Remote Management
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** Remote Management installed/enabled (Ghost G-07)
**Probe:**
```
launchctl print system/com.apple.RemoteDesktop.agent
```
Or check ARD state via `/System/Library/CoreServices/RemoteManagement/ARDAgent.app`.
**Expected state:** Remote Management on. This is the canonical selected remote desktop/control surface. Screen Sharing alone is not the canonical selection unless Remote Management is unavailable and Daniel explicitly downgrades.
**Repair/action:** `launchctl kickstart -k system/com.apple.RemoteDesktop.agent` or equivalent ARD activation command.
**Forbidden action:** Enable Screen Sharing AND Remote Management simultaneously (they conflict on macOS). Treat Screen Sharing as a canonical equivalent without explicit downgrade decision.
**Drift condition:** `remote_management_disabled`, `remote_management_not_installed`
**Receipt:** `PROJECT_MANHATTAN_REMOTE_MANAGEMENT_OK`
**Notes:** Whether Remote Management is actually installed and enabled on all three LABs is Ghost G-07. If not yet installed, this is a human-required action.

---

**L-26**
**Name:** Bluetooth On
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** system_daemon
**Dependencies:** none
**Probe:**
```
defaults read /Library/Preferences/com.apple.Bluetooth ControllerPowerState
# must return 1
```
**Expected state:** Bluetooth power on.
**Repair/action:** `defaults write /Library/Preferences/com.apple.Bluetooth ControllerPowerState 1 && killall -HUP bluetoothd` — effective on macOS 11 and earlier. On macOS 12+: CLI control may be unreliable. If repair fails and state is still off: write `bluetooth_requires_manual` (see Ghost G-04).
**Forbidden action:** Disable Bluetooth. Use Bluetooth off as a security posture.
**Drift condition:** `bluetooth_off`, `bluetooth_repair_failed`
**Receipt:** `PROJECT_MANHATTAN_BLUETOOTH_OK`, `PROJECT_MANHATTAN_BLUETOOTH_REQUIRES_MANUAL`
**Notes:** Bluetooth is mandatory canonical. Detection is reliable. Repair is best-effort on newer macOS. Bluetooth is a dependency for AirDrop (L-27) and Universal Control (L-28).

---

**L-27**
**Name:** AirDrop Enabled
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** L-26 (Bluetooth on), user session active
**Probe:**
```
ifconfig awdl0 | grep "status: active"    # AWDL interface active = AirDrop capable
```
Or check Finder/sharing preferences in user context.
**Expected state:** AirDrop enabled and receivable. AWDL interface active.
**Repair/action:** Enable in user session if disabled. `defaults write com.apple.NetworkBrowser BrowseAllInterfaces -bool true` in user context. If controllability is restricted: write `airdrop_requires_manual` (Ghost G-04).
**Forbidden action:** Disable AirDrop.
**Drift condition:** `airdrop_disabled`, `awdl_inactive`
**Receipt:** `PROJECT_MANHATTAN_AIRDROP_OK`
**Notes:** AirDrop depends on Bluetooth (L-26). AWDL interface presence is a reliable proxy for AirDrop capability.

---

**L-28**
**Name:** Handoff and Universal Control / Inter-Computer Mouse-Keyboard
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** user_agent
**Dependencies:** L-26 (Bluetooth on), L-27 (AirDrop), user session active, Apple continuity stack (same Apple ID, compatible hardware)
**Probe:**
```
defaults read /Library/Preferences/com.apple.NetworkBrowser DisableHandoff
# must be 0 or absent (Handoff enabled)
```
Universal Control availability: check system settings via defaults or scripted System Events query in user session.
**Expected state:** Handoff enabled. Universal Control available where Apple hardware supports it. Inter-computer mouse/keyboard functional via Universal Control by default.
**Repair/action:** `defaults write /Library/Preferences/com.apple.NetworkBrowser DisableHandoff -bool false` in user context. If Universal Control cannot be made reliable on a specific LAB: write `universal_control_unreliable` ghost for Daniel to choose a replacement tool. Do not invent a third-party tool without approval.
**Forbidden action:** Disable Handoff. Invent or install a third-party inter-computer mouse/keyboard tool without Daniel's approval.
**Drift condition:** `handoff_disabled`, `universal_control_unavailable`, `universal_control_unreliable`
**Receipt:** `PROJECT_MANHATTAN_HANDOFF_OK`, `PROJECT_MANHATTAN_UNIVERSAL_CONTROL_UNAVAILABLE`
**Notes:** Default implementation is Apple Universal Control / Handoff continuity stack. If unreliable: report ghost, stop. Do not invent an alternative.

---

**L-29**
**Name:** TCC / Accessibility Permissions for Remote Tools
**Applies to:** all
**Canon status:** canonical
**Primary instrument:** manual_or_mdm
**Dependencies:** remote tools installed (TeamViewer, Remote Management)
**Probe:** Indirect — verify tools are functioning (TeamViewer can control, etc.). Observe tool logs for access-denied errors. Direct TCC DB read requires Full Disk Access (circular dependency) — use indirect behavioral evidence.
**Expected state:** TeamViewer has Accessibility permission. Remote Management has necessary permissions. Input Monitoring and Screen Recording granted where needed.
**Repair/action:** Cannot be granted programmatically on macOS 12+ without MDM. Write `tcc_permission_drift`. Human must grant in System Settings > Privacy & Security or via MDM profile.
**Forbidden action:** Modify TCC database directly. Claim repaired without actual grant. Use `tccutil reset` as a repair action (it revokes, not grants).
**Drift condition:** `accessibility_permission_missing`, `screen_recording_permission_missing`, `tcc_permission_drift`
**Receipt:** `PROJECT_MANHATTAN_TCC_HUMAN_REQUIRED`
**Notes:** Hard ceiling on automation. TCC permissions must be set during initial machine setup. Manhattan detects and alerts only. Ghost G-05 covers whether MDM exists to handle this.

---

**L-30**
**Name:** LAB Runtime Process
**Applies to:** all (currently admitted on LAB_8GB as com.minilab.host-runtime)
**Canon status:** canonical
**Primary instrument:** launchd_admitted_service
**Dependencies:** user session active, runtime script exists at admitted path
**Probe:**
```
launchctl print gui/501/com.minilab.host-runtime
# state = running, pid present
```
**Expected state:** Running. Pid present.
**Repair/action:** `launchctl kickstart -k gui/501/com.minilab.host-runtime` or bootout + bootstrap.
**Forbidden action:** Replace host-runtime with an unadmitted wrapper. Create a parallel runtime guardian.
**Drift condition:** `host_runtime_down`
**Receipt:** `PROJECT_MANHATTAN_HOST_RUNTIME_OK`, `PROJECT_MANHATTAN_HOST_RUNTIME_REPAIRED`
**Notes:** What the runtime does is application-level (out of infrastructure canon). That one admitted runtime process is running IS infrastructure canon. Each LAB may have a different implementation — the canonical requirement is one admitted runtime process, running.

---

*(Note: L-28 from the previous draft has been renumbered. Handoff/Universal Control is now L-28, TCC is L-29, LAB Runtime is L-30, to accommodate AirDrop as its own item L-27.)*

---

## 3. Instrument Separation Table

| Item | Primary Instrument | Dependencies | Why This Owner | Why Not Helper Plist |
|---|---|---|---|---|
| L-01 Identity | system_daemon | config_value | Root-level scutil; runs before any user session | Identity is not a service — it's a gate condition |
| L-02 Auto-Login | system_daemon | config_value, L-03 | Plist at /Library/Preferences is root-writable; MDM check is root | Writing a plist is not a service |
| L-03 FileVault | system_daemon | none | fdesetup requires root; repair is human-required | FileVault state is not a service |
| L-04 Keychain | user_agent | user session, L-02 | Login keychain is user-session-scoped; root cannot access meaningfully | Keychain state is not a service |
| L-05 Wi-Fi | system_daemon | config_value | networksetup requires root | Wi-Fi is infrastructure state, not a separate service |
| L-06 Ethernet Peer | system_daemon | config_value | networksetup requires root; static IP is root-level config | Ethernet config is infrastructure state |
| L-07 Peer Witness | peer_witness | config_value (peer IP, MAC) | Peer probes are root-capable; WOL is outbound UDP only | Peer witness is a probe, not a guardian daemon |
| L-08 SSH | system_daemon | none | systemsetup requires root | SSH state is infrastructure state |
| L-09 pmset Policy | system_daemon | none | pmset requires root | Power policy is infrastructure state |
| L-10 Firewall | system_daemon | none | socketfilterfw requires root | Firewall state is infrastructure state |
| L-11 pf | system_daemon | none | pfctl requires root | pf state is infrastructure state |
| L-12 Screensaver | user_agent | user session, L-02 | currentHost defaults are user-session-scoped; root cannot reliably write | Screensaver pref is not a service |
| L-13 TeamViewer Service | launchd_admitted_service | TeamViewer installed | System domain launchd requires root; vendor plist | The vendor plist IS the service definition |
| L-14 TeamViewer Session | user_agent | user session, L-13 | /Library/LaunchAgents bootstrap requires gui/501 context | Vendor plist at /Library/LaunchAgents |
| L-15 cloudflared | launchd_admitted_service | user session | gui/501 bootstrap requires user session | Admitted plist IS the service definition |
| L-16 Tunnel Health | user_agent | L-15 | HTTP probe to localhost; restart must match cloudflared's gui/501 context | Tunnel health is a probe, not a guardian |
| L-17 Login Survival | user_agent | user session, L-13–L-16 | Login checks are session-bound; must run in gui/501 | Login survival is a check, not a new service |
| L-18 Pre-Restart Phases | system_daemon | L-13–L-16, user_agent | Phase scheduling is root-level; restart command is root | Phases run inside daemon loop — no separate job |
| L-19 Daily Restart | system_daemon | L-18, config_value | shutdown -r now requires root | Restart trigger is daemon logic — no StartCalendarInterval |
| L-20 Post-Reboot Survival | system_daemon | all admitted items | System checks need root; user checks via user_agent | Survival is a probe sequence, not a new service |
| L-21 Gate | system_daemon | gate paths | chflags requires root; observation is audit function | Gate is a state, not a guardian service |
| L-22 No Parallel Authority | system_daemon | registry, L-21 | Admission control is root-level scan + gate | Admission control IS the daemon's core function |
| L-23 Receipts | system_daemon | state path | Both daemon and agent write here; root owns state path | Receipts are outputs, not services |
| L-24 Drift Detection | system_daemon | all L-items | Audit is daemon's core function | Drift detection IS what the daemon does |
| L-25 Remote Management | system_daemon | ARD installed | ARD control requires root | ARD is a system service — kickstart via launchctl |
| L-26 Bluetooth | system_daemon | none | Bluetooth plist at /Library/Preferences is root-writable | Bluetooth state is infrastructure state |
| L-27 AirDrop | user_agent | L-26, user session | AirDrop/Finder prefs are user-level | AirDrop state is session preference |
| L-28 Handoff/Universal Control | user_agent | L-26, L-27, user session | Continuity stack is user-session-bound | UC/Handoff is session feature, not daemon |
| L-29 TCC Permissions | manual_or_mdm | remote tools | TCC DB is SIP-protected; cannot grant programmatically | TCC cannot be automated — report only |
| L-30 LAB Runtime | launchd_admitted_service | user session | gui/501 bootstrap requires user session | Admitted plist IS the service definition |

---

## 4. Conflict / Overlap Report

**C-01 — TeamViewer: system service (L-13) vs user session component (L-14)**
L-13 is system domain (root), L-14 is gui/501. Same application, different launchd contexts.
*Separation:* system_daemon manages L-13 via `launchctl system/`. user_agent manages L-14 via `launchctl gui/501/`. Manhattan v1 does NOT scan `/Library/LaunchAgents/` — L-14 is invisible. v2 must add this scan path. Both write to the same receipt tree.

**C-02 — cloudflared process health (L-15) vs Cloudflare tunnel health (L-16)**
L-15 is a binary launchctl state check. L-16 requires an HTTP probe to the cloudflared metrics/API. Process running ≠ tunnel connected.
*Separation:* L-15 probe is launchctl. L-16 probe is HTTP (exact endpoint is Ghost G-01). L-16 depends on L-15 but is a separate check with its own drift condition and receipt. Both must pass for cloudflared to be considered healthy.

**C-03 — Wi-Fi internet route (L-05) vs Ethernet peer link (L-06)**
L-05 is the internet route (DHCP or router-assigned, DNS present). L-06 is a private peer-only link (static /30, no gateway, no DNS). Different physical interfaces, different purposes.
*Separation:* L-05 probe checks internet reachability via Wi-Fi interface. L-06 probe explicitly verifies static IP AND empty gateway AND empty DNS. A routing leak from the peer interface to internet is detected as `ethernet_gateway_present` drift.

**C-04 — Daily restart (L-19) vs forbidden scheduled events**
L-19 must trigger at per-LAB canonical time. Forbidden: pmset repeat events, separate launchd StartCalendarInterval jobs.
*Separation:* System daemon's 5-minute loop checks local time. At per-LAB restart time, if no restart today: write receipt → `shutdown -r now`. "Today" tracked via last restart receipt timestamp. No additional launchd infrastructure. Timer logic lives inside the daemon loop.

**C-05 — Auto-login repair (L-02) vs proof after reboot**
Writing the plist does not prove auto-login works. macOS must actually log in after a restart.
*Separation:* L-02 repair writes the plist. Closure requires post-reboot evidence: verified loginwindow state after restart, or a successful post-reboot login receipt from the user_agent, or explicit human/MDM receipt if macOS prevents automatic repair.

**C-06 — Screensaver preferences (L-12): system daemon context vs user preference domain**
`currentHost` screensaver preferences are user-session-scoped. System daemon as root cannot write to the user's currentHost domain reliably.
*Separation:* L-12 owned by user_agent running as the LAB user in gui/501. System daemon does not own L-12. System daemon observes L-12 drift only via user_agent's reported receipt.

**C-07 — TCC permissions (L-29): detection possible, repair impossible without MDM**
TCC database is SIP-protected on macOS 12+. Programmatic grants require MDM.
*Separation:* Manhattan detects TCC drift indirectly (tool behavior, log errors). Writes `tcc_permission_drift` and `PROJECT_MANHATTAN_TCC_HUMAN_REQUIRED`. Never writes a success receipt without proof. Human grants via System Settings or MDM profile. Ghost G-05 covers MDM existence.

**C-08 — Universal Control / Bluetooth / AirDrop split (L-26, L-27, L-28)**
These three are related but distinct: Bluetooth is a radio state, AirDrop is a sharing capability dependent on Bluetooth, Universal Control is an application feature dependent on both.
*Separation:* L-26 Bluetooth: system_daemon probes/repairs radio power state. L-27 AirDrop: user_agent probes AWDL interface and sharing preference. L-28 Universal Control/Handoff: user_agent probes continuity stack settings. Each has its own drift condition. If Universal Control is unreliable: report ghost, do not invent a third-party tool.

**C-09 — Remote Management (L-25) selected vs Screen Sharing fallback**
Screen Sharing and Remote Management conflict on macOS — only one can be active at a time.
*Separation:* Remote Management is the canonical selected surface. Screen Sharing is not canonical and must not be co-enabled. If a specific LAB host cannot run Remote Management, that is a local exception requiring Daniel's explicit downgrade decision — it does not change the canon.

**C-10 — /Library/LaunchAgents/ scan gap (CC-4)**
Manhattan v1 scans only `/Library/LaunchDaemons` and `~/Library/LaunchAgents`. TeamViewer user agent at `/Library/LaunchAgents/com.teamviewer.teamviewer.plist` is invisible.
*Separation:* v2 adds `/Library/LaunchAgents/` as a third scan domain (`system_launchagents`). Vendor and admitted items there must be registered. Any unregistered lab-like label there is classified rogue.

**C-11 — headless-repair and headless-watchdog: transitional admitted status**
These are explicitly marked "Temporary admitted implementation until Manhattan owns the single daemon loop." LIST v2 forbids extra repair loops and watchdogs.
*Separation:* They remain admitted by exception pending Ghost G-06 (

If you need specific details from before compaction (like exact code snippets, error messages, or content you generated), read the full transcript at: /Users/danvoulez/.claude/projects/-Users-danvoulez-Pictures-Camera-Hub/be48f55b-d212-43ef-8366-f75b82e001f3.jsonl
Continue the conversation from where it left off without asking the user any further questions. Resume directly — do not acknowledge the summary, do not recap what was happening, do not preface with "I'll continue" or similar. Pick up the last task as if the break never happened.

Claude: **C-11 — headless-repair and headless-watchdog: transitional admitted status**
These are explicitly marked "Temporary admitted implementation until Manhattan owns the single daemon loop." LIST v2 forbids extra repair loops and watchdogs. Their continued existence is a technical debt item, not a canon expansion.
*Separation:* They remain admitted by explicit exception — Ghost G-06 resolves when their functions are absorbed into the Manhattan system_daemon loop. On resolution, they are deleted and their registry entries move to `deleted` status. They do not set precedent for future helper plists. The filesystem gate must remain closed while they exist — they are admitted, not tolerated outside the gate.

---

## 5. Ghost Items — True Technical Unknowns

These are unresolved technical questions only. Operator decisions are not listed here. Each ghost blocks specific implementation work.

---

**G-01 — Cloudflare Tunnel Health Probe Endpoint**
*What is unknown:* The exact local endpoint that reports live tunnel connection state for the admitted cloudflared instance on each LAB. Candidates: `http://localhost:2000/metrics`, `http://localhost:2000/ready`, `cloudflared tunnel info {name}`. Which endpoint is actually available on the running cloudflared version on each LAB is not confirmed.
*Blocks:* L-16 implementation. Cannot implement tunnel health probe without confirmed working endpoint.
*Resolution path:* On each LAB: `curl -sf http://localhost:2000/metrics` and `cloudflared tunnel info` — examine response. Confirm which returns a parseable tunnel-active signal. Record endpoint and parse pattern per LAB in config.

---

**G-02 — Peer MAC Addresses for WOL**
*What is unknown:* The exact Ethernet MAC address of LAB_8GB and LAB_512 on their dedicated peer Ethernet interfaces (not Wi-Fi, not Thunderbolt bridge — the physical Ethernet interface used for the /30 static link). MAC is required for WOL magic packet targeting.
*Blocks:* L-07 WOL implementation. Peer witness can probe and report, but WOL requires the correct MAC stored in config.
*Resolution path:* On each LAB: `ifconfig {eth_iface} | grep ether`. Record MAC in per-LAB config. Confirm the interface is the correct peer Ethernet, not Wi-Fi.

---

**G-03 — WOL Retry and Cooldown Policy**
*What is unknown:* How many WOL packets to send on peer-down detection. How long to wait before re-probe. Maximum retry attempts before writing HUMAN_REQUIRED and stopping. Whether to send WOL if peer was never seen up in the current boot cycle (might indicate a deeper problem).
*Blocks:* L-07 repair behavior. Without policy, peer_witness cannot implement WOL correctly.
*Resolution path:* Daniel decides: proposed default is 3 packets spaced 2 seconds apart, wait 60 seconds, re-probe once, then write HUMAN_REQUIRED. Await confirmation before implementing.

---

**G-04 — Bluetooth / AirDrop CLI Reliability on macOS 13+**
*What is unknown:* Whether `defaults write /Library/Preferences/com.apple.Bluetooth ControllerPowerState 1` followed by `killall -HUP bluetoothd` reliably enables Bluetooth headlessly on the macOS version installed on each LAB. Also whether AirDrop can be reliably enabled in a headless user session via defaults without interactive confirmation.
*Blocks:* L-26 and L-27 repair action reliability. Detection is confirmed reliable. Repair is best-effort — but the exact failure mode on each LAB's macOS version is unknown.
*Resolution path:* Test on each LAB: toggle Bluetooth off, run the repair command, verify state, report result. If repair fails: document as REQUIRES_MANUAL and update L-26 repair policy accordingly.

---

**G-05 — MDM Enrollment Status**
*What is unknown:* Whether any of the three LABs are enrolled in an MDM profile that can push configuration (TCC grants, auto-login policy, Remote Management, AirDrop/Handoff). If MDM exists, which profile manager and whether it conflicts with Manhattan's direct plist writes.
*Blocks:* L-02 MDM repair path, L-25 Remote Management activation, L-29 TCC repair path. If MDM is active and conflicts with Manhattan's defaults writes, Manhattan's repairs will be silently overridden.
*Resolution path:* On each LAB: `profiles status -type enrollment`. Report result. If enrolled: identify MDM provider and confirm whether Manhattan's repair actions are compatible.

---

**G-06 — headless-repair and headless-watchdog Replacement Timeline**
*What is unknown:* What specific behaviors from `com.minilab.work.headless-repair` and `com.minilab.work.headless-watchdog` must be absorbed into the Manhattan system_daemon loop before these transitional admitted services can be deleted. The exact function list from their scripts is not confirmed in the audit record.
*Blocks:* Deletion of two transitional admitted services. Until this is resolved, they remain admitted by exception against P-07.
*Resolution path:* Read the actual scripts run by each service. Map each behavior to the L-item that covers it or to a gap. Confirm with Daniel which behaviors are canonical (absorb to daemon) and which are vestigial (delete with no replacement).

---

**G-07 — Remote Management Install and Enable State Per LAB**
*What is unknown:* Whether Remote Management (ARD) is currently installed and enabled on LAB_8GB, LAB_512, and LAB_256. The audit record shows Screen Sharing vs. Remote Management as an unresolved choice in v1 — the v2 decision is Remote Management, but whether it is currently active on each LAB has not been verified.
*Blocks:* L-25 repair confidence. If not installed, repair is human-required (App Store or system install). If installed but disabled, kickstart may suffice.
*Resolution path:* On each LAB: `launchctl print system/com.apple.RemoteDesktop.agent`. If not found: check for ARD installation. Report state and determine whether human installation is needed.

---

**G-08 — Ethernet Interface Name Per LAB**
*What is unknown:* The exact BSD interface name (en1, en2, en3, or Thunderbolt-based) used for the /30 peer Ethernet link on LAB_8GB and LAB_512. The audit probed this but the result was not captured definitively in the registry config.
*Blocks:* L-06 probe and repair command construction. The repair command `networksetup -setmanual {eth_iface} {ip} {subnet} ""` requires the correct interface name. Wrong interface name silently misconfigures the wrong adapter.
*Resolution path:* On each LAB: `networksetup -listallhardwareports` cross-referenced with `ifconfig -a`. Identify the interface that has the 10.88.0.x static assignment. Confirm it is not the Wi-Fi or Thunderbolt bridge. Record per-LAB in config.

---

## 6. Instrument Inventory — v2 Architecture

Manhattan v2 requires exactly three instrument processes plus human/MDM for two items:

**A — system_daemon (`com.project-manhattan.daemon`)**
- Already admitted. System domain. KeepAlive=true. Starts at boot before user login.
- Owns: L-01, L-02, L-03, L-05, L-06, L-07, L-08, L-09, L-10, L-11, L-13, L-18, L-19, L-20, L-21, L-22, L-23, L-24, L-25, L-26
- Does not own session-bound items.

**B — user_agent (`com.project-manhattan.agent`)**
- NOT YET ADMITTED in Manhattan v1. Must be created and admitted to registry before v2 behaviors can be implemented.
- Runs as LAB user in gui/501. RunAtLoad=true. KeepAlive=true.
 - Plist at: `/Library/LaunchAgents/com.project-manhattan.agent.plist`
 - domain at runtime: gui/501/com.project-manhattan.agent
 - plist location: /Library/LaunchAgents/com.project-manhattan.agent.plist
 - scan domain: system_launchagents (`/Library/LaunchAgents`)
- Owns: L-04, L-12, L-14, L-16, L-17, L-27, L-28
- Also assists: L-18 (gui/501 kickstarts), L-20 (session-bound survival checks), L-23 (receipt writing from user session)

**C — peer_witness**
- Logical instrument. May be implemented as a function inside system_daemon or as a separate internal module.
- Owns: L-07
- Must NOT become its own launchd job. Lives inside system_daemon's loop.

**D — manual_or_mdm**
- Not a software instrument. Human action or MDM profile push.
- Owns: L-29 (TCC permissions)
- Manhattan detects and writes receipt. Cannot repair. Stops there.

**Transitional admitted (exception, pending G-06):**
- `com.minilab.work.headless-repair` — system domain, until G-06 resolved
- `com.minilab.work.headless-watchdog` — system domain, until G-06 resolved

---

## 7. Registry State Required for v2 Clean State

After v2 implementation, the registry must contain exactly these entries:

| Registry File | Label | Domain | Status |
|---|---|---|---|
| `manhattan-daemon.json` | com.project-manhattan.daemon | system | admitted |
| `manhattan-agent.json` | com.project-manhattan.agent | /Library/LaunchAgents (system_launchagents) | admitted (plist=/Library/LaunchAgents/com.project-manhattan.agent.plist; runtime=gui/501/com.project-manhattan.agent; scan_domain=system_launchagents) |
| `cloudflared.json` | work.minilab.cloudflared | gui/501 | admitted |
| `teamviewer-service.json` | com.teamviewer.service | system | admitted (canonical=true; managed=false; vendor_implemented=true) |
| `teamviewer-agent.json` | com.teamviewer.teamviewer | /Library/LaunchAgents | admitted (canonical=true; managed=false; vendor_implemented=true) |
| `host-runtime.json` | com.minilab.host-runtime | gui/501 | admitted |
| `power.json` | (virtual) | virtual | admitted |
| `ssh.json` | (virtual) | virtual | admitted |
| `repair.json` | com.minilab.work.headless-repair | system | admitted (temporary) |
| `watchdog.json` | com.minilab.work.headless-watchdog | system | admitted (temporary) |
| `a-converge.json` | (virtual) | virtual | out_of_scope (LAB_256) |
| `tv-today.json` | work.minilab.tv-today | gui/501 | out_of_scope |
| `health.json` | com.minilab.work.health-agent + com.minilab.work.headless-health-server | system | admitted (evaluate for G-06 scope) |

Items to be confirmed or corrected against current LAB state before registry is locked.

---

## 8. v2 Code Bugs to Fix

These are code defects identified during inspection. Each has a canonical correction:

**BUG-01 — Gate probe classified as `candidate` instead of `admitted`**
*Location:* manhattan-audit, gate probe classification block
*Fix:* Gate probe result must be classified `admitted` when gate paths exist and uchg is set. Change the hardcoded `"candidate"` return to `"admitted"` with a receipt write.

**BUG-02 — Binary hardcodes `mode: "audit-only"` regardless of config**
*Location:* manhattan-audit, mode assignment at output construction
*Fix:* Read mode from `/usr/local/project-manhattan/etc/manhattan.json` and reflect actual value. Current config says `enforcement` — audit output must say `enforcement`.

**BUG-03 — Gate paths hardcoded in manhattan binary**
*Location:* manhattan bash dispatcher, GATE_PATHS array
*Fix:* Read gate paths from manhattan.json config. Add a `gate_paths` key to config. manhattan bash dispatcher reads and expands the array from JSON.

**BUG-04 — `/Library/LaunchAgents/` not scanned**
*Location:* manhattan-audit, scan domain configuration (uses `system_launchdaemons` and `user_launchagents` from config, missing `system_launchagents`)
*Fix:* Add `system_launchagents: "/Library/LaunchAgents"` to manhattan.json scan section. Add scan loop for this domain in manhattan-audit. Classify items found there against vendor prefixes and registry.

**BUG-05 — cloudflared plist XML parse error corrupts label extraction**
*Location:* manhattan-audit, plist parser for `work.minilab.cloudflared`
*Fix:* Investigate the plist file for the stray content after the closing `</plist>` tag. Remove trailing content. Alternatively: add a fallback in the parser to strip content after `</plist>` before parsing. Validate fix by re-reading label from parsed XML, not from first program_argument.

**BUG-06 — Receipt retention not implemented**
*Location:* manhattan-audit and manhattan-daemon, no cleanup logic
*Fix:* Add cleanup pass to daemon loop: find receipts older than 7 days matching `audit-*` pattern → delete. Mutation/gate/restart receipts: never delete. Implement as final step in daemon loop after audit run.

**BUG-07 — `ttyskeepawake` not checked in power probe**
*Location:* manhattan-audit, power probe canonical pmset values list
*Fix:* Add `ttyskeepawake` to the checked values list alongside the existing 8. Repair command must include `ttyskeepawake 1`.

---

## 9. Items Explicitly Out of Scope

These were considered during LIST v2 canonicalization and explicitly excluded. They must not re-enter through drift detection, audit reports, or helper plists.

| Item | Reason Excluded |
|---|---|
| Quarantine state for any item | Hard rejected by operator. Eliminated from model. |
| Helper plists for any function | P-07 forbids. All behavior is daemon loop or admitted service. |
| Parallel watchdog daemons | P-07 forbids. headless-watchdog is temporary exception, not pattern. |
| Scheduled shutdown events (pmset, launchd) | P-10 forbids. Restart only, via daemon loop. No pmset schedule events. |
| Wake events (pmset wakepoweron, repeat) | Forbidden by P-10. pmset schedule = empty. |
| com.lab-sshd-2222 (port 2222 sshd) | Deleted by operator decision during Phase 1. Not canonical, not stale — deleted. |
| health-agent / headless-health-server (if confirmed redundant to daemon) | G-06 scope — evaluate for deletion when G-06 resolves. |
| tv-today service | Admitted to out_of_scope. Not a LAB infrastructure item. |
| a-converge (LAB_256 only) | out_of_scope on LAB_8GB and LAB_512. Not general infrastructure canon. |
| Cloudflare as internet gateway (routing) | cloudflared is a tunnel to external services, not a default route. L-05 internet route is Wi-Fi. |
| Third-party inter-computer mouse/keyboard tool | Forbidden without Daniel's approval. Default is Apple Universal Control. If UC fails: report ghost, stop. |

---

## 10. Cross-LAB Applicability Summary

| Item | LAB_8GB | LAB_512 | LAB_256 | Notes |
|---|---|---|---|---|
| L-01 Identity | ✓ | ✓ | ✓ | Per-LAB config values differ |
| L-02 Auto-Login | ✓ | ✓ | ✓ | Same policy, same user account per LAB |
| L-03 FileVault Off | ✓ | ✓ | ✓ | Identical requirement |
| L-04 Keychain | ✓ | ✓ | ✓ | Identical requirement |
| L-05 Wi-Fi | ✓ | ✓ | ✓ | Interface name differs per LAB (G-08 scope) |
| L-06 Ethernet Peer | ✓ | ✓ | — | pair_8gb_512 only |
| L-07 Peer Witness | ✓ | ✓ | — | pair_8gb_512 only |
| L-08 SSH Port 22 | ✓ | ✓ | ✓ | All three LABs |
| L-09 pmset | ✓ | ✓ | ✓ | Identical 9-value set |
| L-10 Firewall Off | ✓ | ✓ | ✓ | Identical requirement |
| L-11 pf Disabled | ✓ | ✓ | ✓ | Identical requirement |
| L-12 Screensaver | ✓ | ✓ | ✓ | Identical requirement |
| L-13 TeamViewer Service | ✓ | ✓ | ✓ | Mandatory canonical, all LABs |
| L-14 TeamViewer Session | ✓ | ✓ | ✓ | Mandatory canonical, all LABs |
| L-15 cloudflared | ✓ | ✓ | ✓ | Tunnel names differ per LAB |
| L-16 Tunnel Health | ✓ | ✓ | ✓ | Probe endpoint per G-01 |
| L-17 Login Survival | ✓ | ✓ | ✓ | Identical requirement |
| L-18 Pre-Restart Phases | ✓ | ✓ | ✓ | Phase times offset per LAB stagger |
| L-19 Daily Restart | ✓ (06:40) | ✓ (06:50) | ✓ (06:59) | Staggered — not simultaneous |
| L-20 Post-Reboot Survival | ✓ | ✓ | ✓ | Identical requirement |
| L-21 Gate | ✓ | ✓ | ✓ | Gate paths identical across LABs |
| L-22 No Parallel Authority | ✓ | ✓ | ✓ | Identical requirement |
| L-23 Receipts | ✓ | ✓ | ✓ | Identical retention policy |
| L-24 Drift Detection | ✓ | ✓ | ✓ | Identical requirement |
| L-25 Remote Management | ✓ | ✓ | ✓ | Canonical surface selected |
| L-26 Bluetooth | ✓ | ✓ | ✓ | All three LABs |
| L-27 AirDrop | ✓ | ✓ | ✓ | All three LABs |
| L-28 Handoff / Universal Control | ✓ | ✓ | ✓ | All three LABs |
| L-29 TCC | ✓ | ✓ | ✓ | Human/MDM required on all |
| L-30 LAB Runtime | ✓ | ✓ | ✓ | Implementation may differ per LAB |

---

## 11. Operator Decisions Locked — Not Open for Debate

These decisions were made by Daniel and are reflected in this document. They are not ghosts. They are not open questions. Any code or future document that presents them as open is wrong.

| Decision | Locked State |
|---|---|
| TeamViewer | Mandatory canonical. All three LABs. If down: turn on. Not optional. |
| cloudflared | Mandatory canonical. All three LABs. If down: restart. |
| Cloudflare tunnel health | Separate from process health. Mandatory canonical. If tunnel dead: restart cloudflared, re-probe. |
| SSH port 22 | Mandatory canonical. All three LABs. Port 22 only. No alternate ports. |
| Remote Management | Canonical selected remote desktop surface. Not Screen Sharing. Not "either". Remote Management. |
| Universal Control / inter-computer mouse | Canonical. Default = Apple Universal Control. No third-party tool without approval. |
| Bluetooth | Canonical on. All three LABs. |
| AirDrop | Canonical on. All three LABs. |
| Handoff | Canonical on. All three LABs. |
| FileVault | Off. Canonical. All three LABs. |
| Keychain | On. Canonical. All three LABs. |
| Auto-login | On. Canonical. All three LABs. Closure requires reboot proof. |
| Daily restart stagger | LAB_8GB 06:40 / LAB_512 06:50 / LAB_256 06:59. Not simultaneous. Not negotiable. |
| No quarantine | Eliminated from model. Not a classification. Not a state. Not a path. |
| No helper plists | All new behavior enters through daemon loop or admitted registry. Gate enforces physically. |
| No scheduled shutdown/wake | pmset sched must return empty. No StartCalendarInterval restart jobs. Daemon loop owns restart timing. |
| No extra watchdogs | headless-watchdog is a temporary exception, not a model. Temporary means it ends when G-06 resolves. |

---

## 12. Document Status

**Version:** LIST v2 — Canonicalization Pass, Revised
**Prepared by:** PROJECT MANHATTAN audit process
**Status:** Revised draft — awaiting Daniel sign-off
**Authority:** Daniel Amarilho (human signer per manhattan.json)
**Host evidence base:** LAB_8GB current state (not canon source — canon source is this document)

**What sign-off means:**
- L-01 through L-30 are the canonical item set. No items added or removed without a new signed pass.
- Ghost G-01 through G-08 are the complete list of true technical unknowns. Resolution of each ghost updates the relevant L-items and removes the ghost. No ghost is resolved by assumption.
- Operator decisions in Section 11 are closed. They do not appear in future drafts as open questions.
- Code bugs BUG-01 through BUG-07 are queued for v2 implementation. No fix may silently deviate from the canonical behavior specified in the corresponding L-item.
- The user_agent (`com.project-manhattan.agent`) must be created and admitted before any user_agent-owned items (L-04, L-12, L-14, L-16, L-17, L-27, L-28) can be implemented.

**Next actions pending sign-off:**
1. Resolve G-01 (tunnel probe endpoint) — required before L-16 implementation
2. Resolve G-07 (Remote Management state) — required before L-25 is meaningful
3. Resolve G-08 (Ethernet interface names) — required before L-06 probe is correct
4. Create and admit `com.project-manhattan.agent` — required before any user_agent items
5. Fix BUG-04 (scan /Library/LaunchAgents/) — required before L-14 is visible to audit
6. Fix BUG-01, BUG-02, BUG-07 — correctness fixes, low risk

**Items that can proceed without ghost resolution:**
- BUG-01, BUG-02, BUG-03, BUG-05, BUG-06, BUG-07 (code fixes, no ghost dependency)
- L-08, L-09, L-10, L-11, L-13, L-19, L-21, L-22, L-23, L-24 (fully specified, no ghost dependency)
- L-26 detection pass (repair confirmation requires G-04 resolution)

---

*End of document. 30 canonical items. 8 ghosts. 7 code bugs. All operator decisions locked. Awaiting Daniel sign-off.*