# Source Fruits Inventory

These ZIPs were added as **raw source fruits**, not as authority.

They are preserved under:

```txt
source-fruits/incoming-zips/
```

Smaller ZIPs were also extracted under:

```txt
source-fruits/extracted/
```

`Archive(1)(1).zip` was intentionally **not extracted** because it is large and contains build outputs / duplicate historical material. It is preserved raw for recovery only.

## Incoming ZIPs

| ZIP | Classification | Files | Uncompressed bytes | Cargo.toml | Rust files | SQL files | Markdown files | Use |
|---|---:|---:|---:|---:|---:|---:|---|---|
| `logline_lab_kit_rust.zip` | core/recovery fruit | 392 | 3,348,437 | 36 | 86 | 0 | 122 | older Rust Lab Kit + vendored Foundation; useful for core crate mining, but contains stale terms to repair |
| `logline-lab-kit-ready (1).zip` | ready/recovery fruit | 427 | 19,454,996 | 41 | 93 | 13 | 129 | broad Lab Kit tree with Supabase migrations, labd, outbox/local-sql, artifacts crate risk |
| `LogLine-Lab-Kit-online-spine (3).zip` | spine fruit | 414 | 2,556,025 | 40 | 91 | 13 | 123 | online spine variant with 13 Supabase migrations and repair receipt; strong candidate for profile/supabase material |
| `LogLine-Lab-Kit-clean (1).zip` | clean fruit | 414 | 2,525,877 | 41 | 92 | 13 | 122 | cleaned Lab Kit tree; still contains artifacts crate; compare against online-spine and ready |
| `Archive(1)(1).zip` | heavy archive fruit | 5944 | 872,082,912 | 78 | 195 | 23 | 290 | large historical archive; contains build outputs and duplicates; preserve raw, do not merge directly |
| `merging-codex-update-labd-to-comply-with-core-laws.zip` | labd/core-laws fruit | 126 | 2,371,994 | 14 | 53 | 1 | 20 | small focused merge with labd, engine, constitutional-runtime; useful for labd/gate boundary mining |

## Extraction Notes

```json
[
  {
    "zip": "logline_lab_kit_rust.zip",
    "extracted_to": "source-fruits/extracted/logline_lab_kit_rust",
    "status": "extracted"
  },
  {
    "zip": "logline-lab-kit-ready (1).zip",
    "extracted_to": "source-fruits/extracted/logline-lab-kit-ready_1",
    "status": "extracted"
  },
  {
    "zip": "LogLine-Lab-Kit-online-spine (3).zip",
    "extracted_to": "source-fruits/extracted/LogLine-Lab-Kit-online-spine_3",
    "status": "extracted"
  },
  {
    "zip": "LogLine-Lab-Kit-clean (1).zip",
    "extracted_to": "source-fruits/extracted/LogLine-Lab-Kit-clean_1",
    "status": "extracted"
  },
  {
    "zip": "Archive(1)(1).zip",
    "extracted_to": null,
    "status": "skipped extraction: uncompressed size 873493257 > limit 50000000"
  },
  {
    "zip": "merging-codex-update-labd-to-comply-with-core-laws.zip",
    "extracted_to": "source-fruits/extracted/merging-codex-update-labd-to-comply-with-core-laws",
    "status": "extracted"
  }
]
```

## Recovery Rule

Do not copy any extracted repo directly into the final project tree.

First classify each file as one of:

```txt
core
profile
pack
runtime
adapter
deploy
docs
test/bench
recovery-only
debris
```

## High-Value Fruit by Target

### Lab Kit core

```txt
logline_lab_kit_rust.zip
logline-lab-kit-ready (1).zip
LogLine-Lab-Kit-clean (1).zip
merging-codex-update-labd-to-comply-with-core-laws.zip
```

Mine for:

```txt
crates/logline-act
crates/logline-lab-core
crates/logline-lab-cli
crates/logline-lab-labd
crates/logline-lab-clock
crates/logline-lab-dispatch
```

### Supabase / online spine

```txt
LogLine-Lab-Kit-online-spine (3).zip
logline-lab-kit-ready (1).zip
LogLine-Lab-Kit-clean (1).zip
```

Mine for:

```txt
profiles/supabase/migrations
crates/logline-lab-supabase
crates/logline-lab-outbox
crates/logline-lab-local-sql
```

### Foundation refs / engine

```txt
logline_lab_kit_rust.zip
logline-lab-kit-ready (1).zip
LogLine-Lab-Kit-clean (1).zip
merging-codex-update-labd-to-comply-with-core-laws.zip
```

Mine for:

```txt
foundation/vendor/engine
foundation/conformance
foundation/hash-profiles
```

### Labd / gate / core-laws

```txt
merging-codex-update-labd-to-comply-with-core-laws.zip
```

Mine for:

```txt
crates/logline-lab-labd
crates/logline-lab-core
gate/admission tests
```

## Known Repair Warnings

- `logline-lab-artifacts` appears in several fruits; do not promote `artifact` as a semantic category.
- SQLite/local SQL must remain local cache/outbox, not truth/spine.
- File output can be export/debug/report, not official Act storage.
- Assistant-generated ADRs or decision docs must not become authority.
- Old `passport` / `visa` / `ghost` names may be useful internally but public docs prefer entity / grant / blocked Act.
- `Archive(1)(1).zip` contains build outputs (`.o`, `.rlib`, target-like material); treat as recovery-only.
