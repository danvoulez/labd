# 5. The Bench

This is where you actually spend your day: at a bench, with a screen, doing work. Two kinds of work happen here — **normal coding** and **experiments** — and they run on the same rules, with the same companion: an LLM working beside you as a **co-scientist**.

The whole feel of it is a pit wall. You're the driver; the LLM is the race engineer on the radio. It isn't off somewhere imagining what might be happening — it's looking at the *same screen you are*, reading the same telemetry, and telling you the truth about what's actually there.

## The co-scientist: gazing at the real screen

The single most important rule of the bench is what the LLM is **not** allowed to do: it is not allowed to make anything up. It can only speak about what is genuinely on the screen — the terminal output, the files that changed, the test results, the diff, the receipts. If the evidence isn't there, it says so.

These are its standing instructions, and they're just LogLine's honesty written for a person watching a screen:

```
claim                  ≠  evidence
"the test ran"         ≠  "the test passed"
"it passes locally"    ≠  "it works in production"
"the file changed"     ≠  "the bug is fixed"
"done"  (no test)      ≠  verified
Never describe evidence that isn't actually present.
```

So when you ask "what's happening?", you get a factual summary built from real things: recent output, files changed, what tests ran and what they showed, the current diff, and — crucially — **any claim that doesn't yet have evidence**. The co-scientist's main job is to keep pointing at the gap between what was *claimed* and what was *shown*. That gap is exactly LogLine's `if_doubt`: a claim with no evidence sits in doubt, and the co-scientist won't let you pretend otherwise.

It can also work several "watchers" at once, each looking at the screen for one thing and reporting plainly:

```
scout         which files and context look relevant to what you're doing
reviewer      what's risky in the current diff: bugs, missing handling, security
test monitor  which claims have evidence and which are still unverified
risk monitor  is the work declaring victory early, touching unrelated files, going dangerous
```

None of these decide anything. They observe and report. You — and the Lab's rules — decide.

## Two kinds of work, one set of rules

**Normal coding.** You code (or the LLM codes) in a real terminal. Everything observable becomes a line in the Lab: a command ran, a file changed, a test passed or failed, a claim was made. The co-scientist watches, the honest summary updates, and when you want to commit, deploy, or do anything risky, that's a pending Act the gate has to decide (allow / require / deny). "Just vibe-coding" stops being a leap of faith, because the receipts are real.

**Experiments.** When you're not building but *finding out*, the work takes the shape of an experiment. Same rules, more structure — because the temptation in research is to let a beautiful idea outrun the evidence.

## Experiments, the honest way

The one rule above all (kept from your doc 11):

```
Never let beauty outrun evidence.
```

An idea is allowed to start as a hunch, a metaphor, an intuition. It doesn't *count* until it's been turned into something that can be checked, and the check has actually been run. So an experiment walks a ladder, and each rung is an Act:

```
intuition      the pattern you suspect
thesis         the precise claim
invariant      a falsifiable version: "this should hold; this would break it"
probe          the test/command/inspection that would show it
observation    what the probe actually returned
receipt        a scoped close: "this invariant held under this probe" — and nothing more
```

Notice the discipline at the end: a receipt closes only what the probe actually showed. You may say *"this held under this probe."* You may not say *"the whole idea is proven."* Anything the experiment couldn't reach is named as a blocked Act, out in the open, not quietly skipped.

The roles from doc 11 survive too — not as job titles, but as **hats** you (or the co-scientist) put on so one mind doesn't fool itself: the one who finds the structure, the one who turns it into a falsifiable claim, the one who runs the probe and refuses to overclaim, the one who names what's missing. The point of separating the hats is to stop *"a smart-sounding sentence"* from becoming a result.

This is what makes the Lab a place to study LogLine and not just use it: every experiment is itself a little LogLine — a claim, its three routes, its evidence — and the bench keeps it honest.

## The cockpit: one screen for everything

The UI you liked is a cockpit, and its job is described in one line from your own plan: **it is the human face, not the executor, and not the source of truth.** It shows you the Lab in plain language; the Acts and the spine remain the truth underneath.

One screen joins the three things you do:

```
daily        the day's notebook — what's alive, what changed, what's blocked, what needs you
control      the machines and the world — Observe, the Registry of what exists, the Policies (the gate's rules)
work         the Code bench and experiments — coding or probing, with the co-scientist beside you
```

Two habits make the cockpit trustworthy, and both come straight from your plan:

**It speaks human, not engine.** The screen never shows raw machinery. It translates:

```
allowed and closed        →  Worked ✓
denied                    →  Didn't ✗   (+ the reason, in one line)
needs a human             →  Waiting on you ⏸
blocked: missing evidence →  Missing proof ⚠
blocked: missing rights   →  Not allowed yet ⚠
gone quiet                →  Offline for X minutes
```

**You add things by telling, showing, or photographing.** The "+ New" flow is one box: *"Tell it, show it, or photograph it — we'll organize it and hand you back a proposal."* You dump messy input; the co-scientist drafts a clean Act and shows it back to you as a proposal; you **Refine** or **Register**. That confirm step is the gate. The LLM proposed; you (or a rule) decided. It never registers anything behind your back.

And one preview rail shows the *actual* evidence in whatever form it took — a receipt, an event's trace, an image, a snippet of code, a web page, a table — so "show me the proof" is always one click, never a story.

## What's already built (borrow it)

Almost none of this needs to be built from scratch — which is the whole spirit (doc 3):

- **The co-scientist dynamic** is already working in your **pitwall** prototype: a real terminal (PTY), an append-only event ledger in SQLite, automatic claim-vs-evidence tracking (`evidence_captured` is deliberately *not* `verified`), the watcher lanes, secret redaction before anything reaches the model, and adapters for Claude / GPT / a stub. It is built almost entirely from off-the-shelf parts (node-pty, xterm.js, simple-git, chokidar, the model SDKs).
- **The cockpit UI** is your **vibe-codin** app — a fork of an open-source vibe-coding platform (Next.js, the AI SDK, a sandbox for running code, shadcn/ui components) repainted into the control-plane / code-lab screens.

Both are in your home folder, not the archive, because they're alive. What's left to do is small and is the only part that's *ours*: make every claim, probe, observation, commit, and registration flow through the Lab as Acts against the spine — so the pit wall and the cockpit are reading the same truth the rest of LogLine runs on.

---

Next: **[06_manhattan.md](06_manhattan.md)** — the control plane made real, on three machines.
