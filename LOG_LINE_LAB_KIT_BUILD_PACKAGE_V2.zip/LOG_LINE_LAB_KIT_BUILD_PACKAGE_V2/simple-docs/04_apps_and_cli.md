# 4. Apps and the CLI

Two ways to do things in a Lab: **apps** plug into it (the way apps plug into ChatGPT), and the **CLI** drives it (and grows new commands as you need them). Both do the same underlying thing — emit and read Acts — so anything you can do one way you can do the other.

## Apps: copy the ChatGPT model

ChatGPT doesn't hard-code every integration. It exposes a connection standard, and apps plug in over it. We copy that exactly. The standard is **MCP** (the Model Context Protocol — the same one ChatGPT and Claude use for connectors and apps). We don't invent a plugin API; we adopt MCP.

A **Lab Connection app** is any program that speaks MCP to your Lab. It can be something you write, something open-source you clone, or a model-driven agent. The Lab doesn't care what's inside it — it only sees Acts coming in and going out.

```
                ┌─────────── your Lab ───────────┐
   an app  ──MCP──▶  gate (allow/require/deny)  ──▶  worker  ──▶  spine
 (cloned,                       ▲                                   │
  written,                      └────────── projections ◀───────────┘
  or an LLM)                                  (the app reads these back)
```

The rules that make this safe are already in LogLine — you don't build new ones:

- **An app is an entity.** Connecting an app emits a `register_entity` Act (entity kind: `app` or `mcp tool` — doc 12 already lists these). Its identity is the Act's hash, not a row in a table.
- **An app's access is a grant Act.** What an app may do is an `issue_grant` Act scoped to that app: which verbs, which resources, for how long. Revoking access is just a later Act. No app has standing permission — every action it requests still goes through the gate.
- **An app can only ever propose.** Like a language model (see [02_the_method.md](02_the_method.md)), an app emits *draft Acts*. The gate decides allow / require / deny. An app can't close a receipt, can't widen its own grant, can't write to the spine directly.

So adding a capability to your Lab = connect an app over MCP, register it, grant it a scope. No core changes, no redeploy. This is how the Lab grows: not by getting bigger, but by getting more apps. Want web search, a code runner, a calendar, control of a machine? Each is an MCP app with a scoped grant — exactly like enabling an app in ChatGPT.

> Manhattan (doc 5) is a good first app to think of this way: it already exposes its state over HTTP; wrapping it as an MCP app makes "check and repair my machines" a Lab capability you can call from anywhere, including a model.

### Building or cloning an app

Use the official **MCP SDK** (TypeScript). The shape of any app is tiny:

1. Declare the **tools** it offers (each tool call becomes a draft Act).
2. On connect, register as an entity and present its grant.
3. Translate incoming requests into Acts; return projections (results) back.

Most apps you'll never write — you'll clone a proven MCP server (there are many open-source ones) and point it at your Lab. The only LogLine-specific glue is "emit the Act, respect the grant, return the projection."

## The CLI: small core, grows forever

The Lab's command line is built to **add commands easily** — that's the whole point. Use **oclif** (the open-source framework Salesforce/Heroku built for exactly this): commands are files, and *plugins* add whole command groups without touching the core CLI. New capability = drop in a command or install a plugin. Same philosophy as the apps: a small core that grows by addition.

Everything a command does is emit or read Acts. The command is a thin, friendly front end over the same gate/spine path an app uses.

### The starting commands

```
logline status                     show the Lab's current state (a projection)
logline doctor                     check health: spine reachable, projections fresh, brakes sane

logline add experiment <name>      emit an Act that opens an experiment
logline add entity <kind> <name>   register an entity (person, machine, app, runtime…)
logline grant <app> <scope>        issue a scoped grant to an app
logline emit <file.json>           emit a raw Act from a file
logline act list                   read recent Acts back
logline blocked                    list what's blocked and why
logline receipt prepare <scope>    prepare a scoped closure

logline app connect <name>         connect/register an MCP app
logline app list                   list connected apps and their grants
```

`add experiment`, `add entity`, and the rest are not special machinery — each is a small command that builds an Act (the right `did`, the detail in `this`), sends it through the gate, and prints the resulting projection. That's why the list can keep growing cheaply: a new command is just a new verb wrapped in a nice front end.

### Adding your own command

Because it's oclif, adding `logline add <whatever>` is: create one command file that constructs the Act and calls the same emit path. No core changes. If a command group is big enough (say, everything Manhattan-related), ship it as a **plugin** so it installs and updates on its own. The CLI is meant to be extended by you, by packs, and by anyone — that's the design, not an afterthought.

## Apps vs CLI — same engine

```
an app  →  MCP tool call   →  draft Act  →  gate  →  worker  →  spine  →  projection
the CLI →  a command        →  draft Act  →  gate  →  worker  →  spine  →  projection
```

Pick whichever fits the moment. A human at a terminal uses the CLI. A model or a service uses an app. Both are just polite ways to put Acts into the Lab and read the results back — which is the only thing a Lab ever really does.

---

Next: **[05_the_bench.md](05_the_bench.md)** — the daily experience: you and the LLM co-scientist, coding and running experiments.
