# 1. The Act

The Act is the whole idea. If you only read one page, read this one.

## The inversion

Every computer system since 1945 works like this:

```
code runs  →  log writes
```

The action happens, and then — maybe, if nothing crashed and nobody tampered with it — a log gets written about it. The log comes after. That gap is where everything goes wrong: logs get forged, deleted, or simply don't say *why* anything was allowed.

LogLine turns it around:

```
log writes  →  code runs
```

You write the line first. The line is checked first. Only then can the action run. The line is not a description of the past. **The line is the permission slip for the future.** No line, no action.

## The nine slots

An Act has exactly nine slots. Not eight, not ten. Every meaningful move — a claim, a question, a decision, a job, a result — can be written as one Act.

```
who           Who is acting. A person, a machine, a program, a named identity.
did           What is being done. A verb.
this          What it's being done to. The payload: the content, claim, or thing.
when          The moment it happened.
confirmed_by  The evidence or witness. What backs this up, and who or what confirms it.
if_ok         What should happen if this works.
if_doubt      What should happen if this is uncertain — not enough proof, a guess, a plan.
if_not        What should happen if this fails, is denied, or is contradicted.
status        Where this Act stands right now.
```

## Two things at once

### It's a contract

Read the slots out loud as promises:

```
who           I say who I am.
did           I say what I intend.
this          I say exactly what I'm touching.
when          I mark the moment.
confirmed_by  I name my evidence.
if_ok         I commit to what success means.
if_doubt      I commit to what I do when unsure.
if_not        I commit to what I do when it fails.
status        I accept the outcome.
```

You cannot write a valid Act with `if_ok`, `if_doubt`, or `if_not` left blank. That's the point. You are not allowed to act without first saying what happens in *every* outcome — including the bad one. This kills the most common failure in software: the unhandled case that quietly does the wrong thing. The failure path was declared and signed before anything ran.

### It's the scientific method

The three routes are exactly how an honest experiment ends:

```
if_ok     →  the hypothesis held. There was enough support.
if_doubt  →  inconclusive. A guess, a plan, a simulation, not enough proof yet.
if_not    →  the hypothesis was falsified, denied, or contradicted.
```

`confirmed_by` is the pivot: it carries the evidence and decides which route you're really on. An Act with no evidence cannot honestly claim `if_ok` — it sits in `if_doubt` until something confirms it. This is why LogLine works for experiments: every Act is a small, recorded experiment that can't pretend to be more certain than its evidence.

## What an Act looks like

```json
{
  "who": "dan",
  "did": "transfer",
  "this": { "from": "account:operating", "to": "account:external", "amount": 47500 },
  "when": "2026-06-05T14:23:07.847Z",
  "confirmed_by": null,
  "if_ok": "emit:transfer.completed",
  "if_doubt": "ask:treasury.human",
  "if_not": "emit:transfer.denied",
  "status": "pending"
}
```

Because nothing runs before the line is written, even a *rejected* action leaves a line behind. Forty-seven rejected transfers in forty-seven minutes is no longer an invisible probe — it's forty-seven signed lines saying someone tried. Every attempt becomes a confession. (See blocked Acts in [02_the_method.md](02_the_method.md).)

## The lifecycle

`status` moves through a small set of states. The exact words can vary by Lab, but the shape is always:

```
draft      →  being written
pending    →  written, waiting to be decided
committed  →  decided "allow" and run
blocked    →  decided "deny" or stuck waiting on something missing
```

The important rule: the Act is written to storage **before** the decision is made. Whether it ends up `committed` or `blocked`, the line exists either way. That's what makes the record trustworthy — you can't act first and decide whether to write it down afterward.

## What is *not* a slot

The nine slots are the meaning. Everything else — hashes, the machine that produced it, timestamps about when it was stored, signatures, which route was actually taken — is useful bookkeeping that travels *around* the Act, not *inside* it. Don't add a tenth slot. If you need to record which branch was taken or who stored it, that lives in the wrapper or in a projection (see [02_the_method.md](02_the_method.md)), never as a tenth field of the Act.

## Ugly is allowed

When you capture an Act, it does not have to be clean. A messy, half-formed Act is still information — sometimes the mess *is* the information. Capture first; make it readable later. The strictness belongs at the moment you decide to *run* something or *close* something — not at the moment you write it down. Don't let the front door be so strict that real events go unrecorded.

---

Next: **[02_the_method.md](02_the_method.md)** — how Acts get decided, blocked, proven, and closed.
