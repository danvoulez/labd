# 6. Manhattan

**Manhattan** is the *design* for running your three real computers and keeping them healthy — and checking on them and fixing them from your phone. Honestly stated: it's the most built-out design in the project — about 1,700 lines that really implement the probes and repairs, not a skeleton — but it is **not proven**. As of now it isn't installed or running on the fleet (one stale, failing agent registration on LAB_8GB aside); the machines are actually kept alive by the separate `minilab` runtime. So treat this doc as a written design awaiting proof, not a running system. Saying that plainly is the LogLine way: a claim isn't a receipt.

It's also the clearest example of the spirit in docs 3 and 4. Manhattan builds almost nothing: it leans on `launchd` to stay running, Cloudflare's tunnel to be reachable, plain HTTP to be read, and (in the simpler variant) Ansible and osquery to do the actual work. The only thing that's *ours* is the checklist and the rule that every action leaves a receipt. And the natural next step is to wrap it as a **Lab Connection app** (doc 4): expose "check and repair my machines" over MCP so the CLI, a web view, or a model can call it through the same gate as everything else.

The three machines:

```
LAB_8GB    the supervisor — watches health, holds the links
LAB_512    the heavy worker — does the demanding jobs
LAB_256    the workbench — for hands-on / manual work
```

One installable package goes on all three. The machines differ only by their identity and a little per-machine config; the operating rules are shared.

## The three roles, and the inference bus

Each machine has a job, and the jobs shape the wiring:

- **LAB_8GB — the Capital (supervisor).** The orchestrator. It runs the agent that drives the Lab (Hermes), the clock, the MCP host-runtime, and the sync that pushes receipts up to the spine. It holds the links and watches the others.
- **LAB_512 — the engine room (inference).** Dedicated to one good model, served over the OpenAI-compatible standard. Kept deliberately lean — the model wants every spare GB, so the heavy orchestration lives on the Capital, not here. (Mistral's own in-process agent can live here, since it consumes the local model directly; that's the natural LAB_512-local agent.)
- **LAB_256 — the workbench.** Where a human sits: the bench (pitwall + the cockpit) and the agent for hands-on work. This is where you and the co-scientist actually work.

Two networks join them, on purpose:

```
                       INTERNET (WiFi)  ──  Cloudflare tunnel  ──  the spine
                            ▲                    ▲                    ▲
                        WiFi│                WiFi│                WiFi│
                   ┌────────┴───────┐  ┌─────────┴──────┐  ┌─────────┴──────┐
                   │    LAB_8GB     │  │    LAB_512     │  │    LAB_256     │
                   │  the Capital   │  │  engine room   │  │   workbench    │
                   │  Hermes·clock  │◀═│  good model    │  │  Hermes·bench  │
                   │  MCP·spine     │ETH (OpenAI-API)   │  │  MCP           │
                   └────────────────┘  └────────────────┘  └────────────────┘
                       MCP hands           MCP hands           MCP hands
                       └────────── the Lab has hands on all three ──────────┘
```

The **WiFi** carries the internet and the spine. The **Ethernet cable** between the Capital and the engine room is a *private* link — checklist item **L-06**: a static `/30` (`LAB_8GB 10.88.0.9`, `LAB_512 10.88.0.10`) with no gateway and no DNS, explicitly forbidden from carrying internet traffic. Its whole job is to be the **inference bus** — LAB_512 streams the model to the Capital over Ethernet, so heavy token traffic never competes with WiFi. The Capital thinks; the engine room computes; the cable between them is the fast lane.

**MCP everywhere.** Each machine runs an MCP host-runtime, so the Lab has hands on all three — and every action on any of them is still an Act through the gate, with a receipt. The agents (Hermes on the Capital and the workbench, Mistral's own on the engine room) are participants, not authorities.

## The core loop

Each machine runs two background processes that never stop:

```
a daemon   (runs as root, every ~5 minutes)
an agent   (runs in your user session, every ~minute)

both do the same thing:   observe  →  repair drift  →  observe again
```

"Drift" means the machine has wandered away from how it's supposed to be. The loop notices the difference and fixes what it safely can. Anything it can't safely fix becomes a blocked Act that says exactly what's wrong and what it needs from you.

## The checklist: 30 things that must be true

Manhattan keeps a list of about thirty items — `L-01` through `L-30` — that together define "this machine is set up correctly." Each item is concrete and has the same shape:

```
name            what this item is
applies to      all machines, or a specific one
probe           the command that checks the real state
expected        what "correct" looks like
repair          what to do if it drifted (or "needs a human")
receipt         the proof produced when it's checked or fixed
```

The items cover the real, boring, important things: machine identity, auto-login, disk encryption, Wi-Fi and internet, the link between machines, the SSH server, power settings so it never sleeps, the secure tunnel that exposes it, a daily refresh, a daily restart, survival across reboots, and where receipts and logs are stored.

**Identity comes first.** Item `L-01` checks the machine is who it claims to be. If identity is wrong, *everything* stops — no repairs run on a machine that might be the wrong one. This is the same fail-closed instinct as the gate: when unsure, do nothing.

## Everything it does is an Act with a receipt

Every check and every repair produces a receipt — a small signed record of what was found and what was done. Receipts never contain secrets. A repair cycle, a daily restart, a survived reboot: each one leaves proof behind. This is LogLine's rule applied to real hardware: the machine doesn't just *do* things, it leaves a line saying what it did, and the things it *couldn't* do show up as blocked Acts instead of being silently skipped.

So a drifted setting isn't fixed in the dark — it's: observe (evidence) → repair (an allowed action by the worker) → receipt (proof) → or, if it can't, a blocked Act naming what's missing.

## Running it from your phone

Each machine already serves its state over plain HTTP — `/health`, `/status`, `/items`, `/metrics`, `/receipts`, `/dashboard` — exactly the same endpoints a Lab serves. Each machine also keeps a secure tunnel open to the outside (via Cloudflare's tunnel, which is one of the checklist items). 

Put those two facts together and that's your phone control:

```
your phone  →  the secure tunnel  →  the machine's /dashboard, /status, /health
```

From your phone you can already **see** everything: which machine is healthy, what drifted, what's blocked, the recent receipts. To *act* from your phone — trigger a repair, approve a `require` decision — you send an Act to the machine; it goes through the gate, the worker runs it, and you get a receipt back. The phone is just another way to emit and read Acts. Nothing about the safety model changes because the request came from a phone.

> What's **written** (and substantial, ~1,700 lines): the observe/repair loop, the thirty checklist items, the receipts, the HTTP endpoints, and the installer — real code that implements the probes, not stubs. What's **not yet true**: it has never been installed or validated on the fleet. Today nothing runs it beyond one stale, failing `com.project-manhattan.agent` registration on LAB_8GB (exit 78); the machines are kept alive by the separate `minilab` runtime stack. The policy also still carries open "ghosts" (unknown probe endpoints, peer MACs, interface names — G-01…G-08). So the honest status is: a written design awaiting a first real install + validation, plus a phone-facing view and the wiring of repair receipts into the spine. (The inference bus is up: a recent L-06 drift — LAB_512's `en0` had wandered off the canonical `/30` — was repaired by hand, and 512↔8GB now passes over the cable at sub-millisecond latency, ~50× faster than the WiFi path. The cable itself only negotiates 100 Mbit, so latency is excellent but throughput is capped; a better cable is the one hardware upgrade worth making.)

## A simpler alternative is sketched

There's also a plan to do the same job with off-the-shelf parts instead of custom code — Ansible to converge the machines and osquery to inspect them — keeping only the genuinely Manhattan-specific bits (identity pinned per machine, the manual items, tunnel health). It's an option, not a replacement. The point worth keeping: the *checklist* is the real asset; how you enforce it can change.

## Where the working code lives

All of it is in the archive:

- **The fleet system** — `_archive/manhattan 3/project-manhattan-v2/` — the engine (`src/manhattan.py`), the daemon and agent entry points (`bin/`), the installer (`install/`), the background-job definitions (`launchd/`), and the checklist itself (`PROJECT_MANHATTAN_POLICY_REVIEW.json`).
- **The checklist in readable form** — `_archive/manhattan 3/# PROJECT MANHATTAN LIST v2 — Canonicali.md` — every `L-01`…`L-30` item spelled out.
- **The off-the-shelf alternative** — `_archive/manhattan 3/project-manhattan-v2/upstream-replacement/` — the Ansible + osquery sketch.

---

Back to: **[README.md](README.md)** · or the words: **[07_glossary.md](07_glossary.md)**.
