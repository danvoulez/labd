# 3. The Lab

A **Lab** is a place where you actually run LogLine: you emit Acts, decide them, run the allowed ones, store everything, and read it back. `minilab.work` is your Lab.

Said sharply: every Act is a contract — it names who commits to what, the evidence that confirms it, and what happens on success, doubt, or failure. So **the Lab is the thing that executes contracts**, and time is just the order it executes them in. (The clock that makes this real is at the end of this doc.)

A Lab is itself declared by an Act — "this Lab exists, here's its name and purpose, here's how it's set up" is just another line. No special ceremony.

The most important thing about a Lab is what it *isn't*: it isn't a pile of infrastructure you have to build. **You own the rules. You borrow everything else.**

## Own the rules, borrow everything else

The temptation in the old material was to build everything from scratch — a custom engine, a custom store, a custom everything — wrapped in heavy language. Forget that. The plan now is the opposite:

```
Write down only what is genuinely different about LogLine.
Express it as rules in JSON.
Hand those rules to proven, tested, open-source tools and let them obey.
```

There is exactly **one** thing about LogLine that no off-the-shelf tool already does: the Act, and the discipline around it (canonical form, hashing, the three routes, allow/require/deny, blocked Acts, receipts). That is the only thing we build. Everything else — storage, auth, transport, scheduling, dashboards, the CLI framework — already exists, works, and is tested by people who aren't us. We use it.

And our rules don't live in code we have to maintain. They live in **JSON** that the borrowed tools read:

- The shape of a valid Act and a valid receipt → a **JSON Schema** any validator can enforce (the conformance examples in the archive are the real spec).
- What's allowed, what needs a human, what's denied → a **policy JSON** the gate reads.
- Domain-specific opinions and defaults → a **pack** (see below), which is just more JSON and assets.

If you ever feel yourself building infrastructure, stop. The question is always "what proven thing already does this, and what JSON do I feed it?"

## Universal standards are our standards

We do not invent formats. We adopt the ones the whole world already uses, and we only specify the small piece that's ours.

| Need | We use the standard | We do **not** build |
|---|---|---|
| Validate Acts/receipts | JSON Schema (2020-12) | a custom validator |
| Stable identity / hashing | canonical JSON (RFC 8785) + SHA-256 / BLAKE3 | a custom serializer |
| Signatures | Ed25519 | custom crypto |
| Storage / spine | Postgres (Supabase) | a custom database |
| Local cache / offline | SQLite | a custom store |
| Login / identity | OAuth 2 / JWT (Supabase Auth) | a custom auth system |
| Apps connecting to the Lab | MCP (the protocol ChatGPT-style apps use) | a custom plugin API |
| The CLI | oclif (plugin-based) | a bespoke arg parser |

The only column that's truly *ours* is the rules that ride on top: the Act shape, the policy, the receipt discipline. Maintain only what's different.

## The layer cake

Borrowed from your doc 12 and the packs/profiles split — cleaned up. A Lab is built in layers, and each layer can change without touching the others:

```
core      The Act and its discipline. Tiny. Written in Rust. Never changes for your domain.
          (validate the Act, canonical form, hashes, signatures, the three routes)

profile   Which proven tools you run on. JSON config.
          minilab.work: Postgres spine (Supabase), SQLite cache, OAuth/JWT auth.
          Swap the profile, run the same Lab on different tools.

pack      Opinionated plugins that increment LogLine the way you want. JSON + assets.
          Your domain verbs, golden configs, default policies, projections, study setups.
          A pack adds capability; it never edits the core.

apps      ChatGPT-style connection apps that plug into the Lab over MCP.
          Each app is just another participant that emits and reads Acts. See doc 4.

surface   How you touch it: the CLI, a web view, your phone. Optional and replaceable.
```

The load order is simple: **core loads → a pack interprets → a profile provides the tools → the Lab runs → a surface shows it.** Pure LogLine first; your practice loaded on top; never the two confused.

This is the freedom doc 12 was after: anyone can write a pack to extend LogLine however they like, and it plugs in without forking the core. Your `minilab` setup is one pack + one profile. Someone else's offline, no-cloud Lab is a different pack + profile — same core, equally legitimate.

## No native objects — only Acts and projections

A rule worth keeping verbatim from doc 12, because it's what makes "borrow everything" possible:

```
There are no native business objects.
There are only admitted Acts and projections over them.
```

You never model your domain as tables and classes the core has to understand. An experiment, an entity, a machine, an app, a permission — each is just an Act, with the domain detail living inside the `this` slot. The core validates the *shape* and stays ignorant of your domain. The meaning appears later, as a **projection** the borrowed database builds for you to read.

So "add an entity," "add an experiment," "grant an app access" are not new object types to design — they're verbs you put in `did`, captured as Acts, and projected into rows. (Identity is anchored to the Act, not to a database row: `passport_ref = act://sha256:<the register Act's hash>`.)

## The two roles, now borrowed

The gate and the worker from before still exist — but you don't build them, you configure them:

- **The gate** decides allow / require / deny. It's a small function that reads your **policy JSON** and the Act. Fails closed. You write the policy, not a policy engine.
- **The worker** runs an allowed Act on a real machine and returns evidence. It's whatever proven tool does the job — a shell runner, a job queue, an MCP app, Manhattan — wrapped just enough to take an allowed Act in and hand evidence back.

## Where Acts live

Unchanged in spirit, concrete in choice:

```
The Postgres spine (Supabase) is the source of truth.
SQLite is a local cache and outbox — never the truth.
Loose files are examples and exports — never the truth.
```

You emit an Act → it's written to the local SQLite cache and queued → synced up to Postgres. Postgres wins any disagreement. Supabase also gives you auth and realtime for free, so projections (the registry, dashboards) update live without you building a sync system. The database is a **projection**: every meaningful row got there because of an Act, and you could delete it and rebuild it from the Acts. A form writing straight to a table is forbidden — if it didn't go through an Act, it didn't happen.

## Config and secrets

Config tells the Lab *how* to reach things; it never grants permission. Secrets (keys, tokens) are referenced and redacted — never written into Acts, receipts, the database, or logs — and kept in the secrets manager / environment. Brakes are safety switches that default to off (deny) until explicitly released; a released brake still isn't permission, because only the gate grants that.

## The daily loop

```
load     →  read the current state from projections
declare  →  write Acts for what you intend
observe  →  run the allowed ones; collect evidence
emit     →  record results as Acts
project  →  the database rebuilds the views (live, via Supabase)
learn    →  read it back, decide the next move
```

## The Lab is a clock

The daily loop describes one pass. But the Lab doesn't wait for you to start a pass — it runs on Earth's own clock, because time is part of every contract: each Act carries a `when`. Lay all the Acts out by `when` and you have a timeline.

The present is a ruler sweeping that timeline at the planet's pace — one heartbeat, not a thousand alarms. (A standard scheduler *fires* the heartbeat; but the tick is a line in the spine, not an off-the-books cron.) Acts don't wake up — the ruler **reaches** them. And where it reaches NOW, the contract must resolve. There is no fifth option called "nothing happened":

```
the contract says         at NOW, the Lab makes it true
─────────────────         ─────────────────────────────
confirmed_by is in    →   if_ok fires
confirmed_by missing  →   if_doubt fires   (wait, ask you, retry)
it cannot hold        →   if_not fires
not yet its turn, but
  it can run later    →   the Lab proposes a reschedule — itself an Act, in the open
```

The Lab isn't *judging* when the ruler arrives; the verdict was written when the Act was registered. It's only being **faithful** to the contract, on time. That's all "enforcement" means here — honesty with a clock attached.

### Capacity is a band

Time isn't free, so the Lab watches its load against a band, and warns from **both** edges:

```
over the band    too much for now, or for a projected slot   →  warn, slide, refuse what it can't honor
under the band   slots sitting empty                         →  defect: pull standing work
```

The top edge is obvious — a contract executor must never promise what it can't deliver, so it won't accept a future Act past what the projection says it can carry. The bottom edge is the part that's easy to miss: **an idle Lab is a broken Lab.** The Lab is under a standing contract with you to stay useful, so empty slots get filled, never left blank:

```
research      read the web on the open questions
tend          watch the scheduled experiments — even if watching is all that's due
organize      tidy the ledger, the registry, the debts
communicate   send what's owed; surface what's gone quiet
think         turn observations into new theses
enhance       sharpen the tools, the projections, the docs
help          do the things you've been meaning to ask for
```

This is what makes the Lab run 24/7 *honestly*: an agent not currently with a human is never off — it's paying down that standing contract.

### Projections keep it concrete

You don't re-derive "can we run this and that at the same time?" from scratch each time. A **projection** is a precomputed read over the ledger — load for the next hour, debts outstanding, what's due, what's gone quiet — so capacity is a glance, not a meditation. A projection is never the truth; it's the Acts already added up. Delete it and you rebuild it from the spine.

So the arrow of time is just the ledger read three ways: **the past** is closed Acts you learn from, **the present** is the ruler making due contracts true, **the future** is Acts you've placed up to what the projection says you can carry.

---

Next: **[04_apps_and_cli.md](04_apps_and_cli.md)** — the ChatGPT-style apps and the CLI you grow.
