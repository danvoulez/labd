# 8. How we build it

The honest answer to *"how the hell are we gonna build this?"* is: **we mostly don't.** Around nine-tenths of it is already written, installed, and in several cases *already running* on this machine. What's left to build is one thin layer we own — the Act and the wiring that routes everything through it — plus the discipline to not rebuild what already works.

This doc is the map from *what exists today* to *the Lab in doc 3*. Every path below is real and was read off this machine; where something is unverified or risky, it says so.

## The one-line architecture

```
runtimes that already work   →   the thing we own   →   the store that already works
(Hermes, OpenClaw, pitwall,      the Act + its           Supabase / Postgres spine
 MCP host-runtime)               nine-slot discipline    + live projections
```

We own the middle. The edges are borrowed. Time is the order it all runs in (doc 3, *"The Lab is a clock"*).

## What already exists (read off this machine)

| Role (doc 3) | What's here, and where | State |
|---|---|---|
| **The Act core** — the only thing that's ours | `_archive/…/engine-main/` — a Rust workspace with a crate for **all nine slots** (`who, did, this, when, confirmed_by, if_ok, if_doubt, if_not, status`) **+ `logline-cli`** | Written, near-complete. Needs lifting out of the archive and building. |
| **The worker / agent runtime** | **Hermes** (`~/.local/bin/hermes`, Nous Research) and **OpenClaw** (`/opt/homebrew/bin/openclaw`) | Both **installed and configured**. |
| **The clock / scheduler** | Hermes `cron/` + `hooks/`; OpenClaw `cron/` + `tasks/` | Present, **empty** — no jobs defined yet. |
| **The bench / co-scientist** | **pitwall** (`~/pitwall`) — TS/Electron | **Built and runnable.** |
| **The cockpit** | **vibe-codin** (`~/vibe-codin-.but.-real`) — Next.js, with `Project-Manhattan-Official/` and repainted control-plane / code-lab screens | **Built**, partly wired to Hermes. |
| **App connections (MCP)** | `host-runtime (MCP/Node)` on `lab512`, port 8788, exposed at `lab512-runtime.minilab.work` | **Already running and tunneled.** |
| **The models** | Mistral (local) and Hermes, spoken to directly over the **OpenAI-compatible API** (the international standard both understand) | The old `llm-gateway` is **dropped** — see *"Models: speak the standard"* below. |
| **The spine** | Supabase / Postgres (`supabase-js`) | To be pointed at; standard. |
| **Secrets / config** | **Doppler** (`logline-trust` project, `prd` config) | In use. |
| **Reach from your phone** | **Cloudflare tunnel** `lab512` routing `*.minilab.work` | **Already running.** |

The takeaway: the spine of Manhattan — a local model, an MCP runtime, an agent, and a public reachable endpoint — is **already live on `192.168.0.240` and reachable at `minilab.work` subdomains.** This is not a greenfield build.

## The Act core (the part we own and finish)

Path: `_archive/logline-foundation-canonical-repos 2/engine-main/`.

It is exactly what doc 3 says the core should be: *tiny, Rust, never changes for your domain.* Its own README states the discipline verbatim — *"Natural language never executes — only nine-slot LogLine acts cross the runtime boundary"* and *"Receipts beat stories."*

What's already implemented:

- **All nine slots** as separate crates implementing a `SlotHouse` trait, plus a `logline` binary (`crates/logline-cli`).
- **The evidence pivot** lives in `confirmed_by`: it parses an evidence requirement (`receipt:…`, `digest:…`, `signature:…`, `quorum:N:label`, or a bare token), checks it against provided evidence, and returns a branch — `Branch::Ok`, `Branch::Doubt`, or `Branch::Not`. **This is the three routes, in code.** Missing/`none`/`ghost` evidence routes to doubt unless the canon explicitly allows no confirmation.
- **`did` verb classification**: runtime-operation vs. canonical-law vs. domain vs. unknown; an unknown verb routes to doubt instead of guessing.
- **The CLI surface**: `logline version | status | check-canon <path> | parse-logline <path>` and a `run` path with a `RunContext`. Downstream systems are meant to point an env var `LOGLINE_RUNTIME_BIN` at the built binary — that's the integration handle.
- **An adapter protocol** is specced (`spec/logline.adapter.v0`, LIP-0004) plus a declaration profile (LIP-0005) and adapter-conformance (LIP-0006). **This is the documented seam external runtimes plug into.** It deserves a close read before we wire anything — it may already define exactly the contract we need.
- **A receipt format**: `logline.receipt.v0`, with conformance claimed-then-proved externally.

What's left on the core: build it (`cargo build --release`), lift it out of `_archive` into a live working copy, read the adapter spec, and expose the binary so TypeScript can call it (shell out to `LOGLINE_RUNTIME_BIN`, or compile a thin wasm/N-API binding later). **We do not rewrite this.** It's the one genuinely-ours thing and it's already most of the way done.

## The agent runtimes (borrow, don't build)

You named the two open-source standards, and both are already installed:

**Hermes** (`~/.local/bin/hermes`, by Nous Research). `~/.hermes/` holds:

```
SOUL.md      the agent's system prompt (currently the stock Nous one)
skills/      a large skill library — including mcp, research, autonomous-ai-agents,
             software-development, devops, email, apple (imessage/notes/reminders), …
cron/        scheduled jobs        ← empty: this is where the clock's heartbeat goes
hooks/       event hooks           ← empty
sessions/    running/!past sessions
memories/    persistent memory
logs/        agent.log, errors.log, curator/
```

Hermes maps directly onto three roles from the docs at once: the **worker** (it has the skills that do real things), the **clock** (its `cron/` fires the heartbeat tick), and the **standing-work** engine (its `research`, `autonomous-ai-agents` skills are exactly the "agents are never idle" backlog from doc 3).

**OpenClaw** (`/opt/homebrew/bin/openclaw`). `~/.openclaw/` is a full runtime:

```
agents/          agent definitions and defaults
cron/            scheduled work
tasks/           a task queue
devices/         registered devices  ← the three machines live here
identity/        who the runtime is
plugins/         extensions
exec-approvals.json   a human-in-the-loop approval gate  ← this is "require" from doc 2
credentials/     auth profiles (openai:default; a lab512 local provider)
```

OpenClaw's `exec-approvals.json` is notable: it's already a *gate* in the doc-2 sense — actions that need a human signature. (Its model provider currently points at the local gateway; that connection gets repointed at the standard — see the next section.)

Decision still open: **Hermes and OpenClaw overlap heavily** (both have cron, skills/plugins, agents). We probably want *one* as the primary runtime and the other for what it's uniquely good at, rather than wiring both into the spine. The first probe (below) will tell us which is easier to make emit Acts.

## Models: speak the standard, keep the rules in middleware

**The `llm-gateway` is out.** It became poisoned — a bespoke layer between us and the models that accumulated rot and distortion. The lesson is the doc-3 borrow rule biting us for ignoring it: a custom gateway is exactly the kind of infrastructure we promised not to build. So we delete it from the path.

The models don't need a gateway, because they already speak a real international standard: the **OpenAI-compatible chat API**. Mistral (local) and Hermes both connect cleanly over it — the right model for the right job. We talk to them directly over that standard, nothing in between that we have to maintain.

But "nothing in between" can't mean "no rules." Our rules don't belong in a gateway; they belong in **middleware** — a thin wrapper around the *standard* model call:

```
without a gateway:

   our rules (middleware)  ──wraps──▶  standard model call (OpenAI-compatible)
        │                                   │
        ├─ redact secrets before the call   ├─ Mistral (local), or
        ├─ frame the request as an Act       └─ Hermes — chosen per task
        ├─ capture the model's output as a claim, never as truth
        └─ route claim + evidence through the canon engine (logline binary)
           → if_ok / if_doubt / if_not → emit a receipt
```

The **Vercel AI SDK** gives us this shape off the shelf, and the API is confirmed against the current SDK: `wrapLanguageModel({ model, middleware })`, where a **`LanguageModelV3Middleware`** (from `@ai-sdk/provider`) implements any of three hooks — `transformParams` (before the call), `wrapGenerate` / `wrapStream` (around it). Multiple middlewares compose in order: `[a, b]` applies as `a(b(model))`. The model stays a swappable, standard provider underneath; the LogLine discipline rides on top as a middleware stack; the **Rust canon engine remains the authority** the middleware defers to for the verdict.

The SDK's own example middlewares map almost one-to-one onto the doc-2 rules — we're not inventing patterns, we're naming ours after theirs:

| AI SDK example | Our middleware | Hook |
|---|---|---|
| Guardrails (redact `badword` → `<REDACTED>`) | **secret redaction** — strip tokens/keys from params *and* output | `transformParams` + `wrapGenerate` |
| RAG (`addToLastUserMessage`) | **Act framing** — inject the Act's context into the request | `transformParams` |
| Logging (capture params + generated text) | **ledger capture** — record the call as a *claim* event, never as truth | `wrapGenerate` / `wrapStream` |
| (after the call) | **canon verdict** — hand claim + evidence to the `logline` binary → `if_ok`/`if_doubt`/`if_not` → receipt | tail of `wrapGenerate` |

So a LogLine model is just:

```ts
wrapLanguageModel({
  model: openaiCompatible(mistralOrHermes),   // the international standard
  middleware: [
    redactionMiddleware,    // doc-2: secrets never reach the model or the ledger
    actFramingMiddleware,   // doc-2: the request carries its Act context
    ledgerMiddleware,       // doc-2: output captured as claim ≠ evidence
    hermesToolMiddleware,   // @ai-sdk-tool/parser: tool-calling for non-native models
  ],
})
```

This is what the engine's **adapter protocol** (`logline.adapter.v0`) was always for: the bridge between an Act and a standard call out to the world. The middleware stack *is* the adapter, in the language the AI SDK already speaks. We keep our rules; we don't keep a gateway.

**Bonus — the weak-local-model problem is now a middleware, not a wall.** OpenClaw's local provider declares `supportsTools: false`; the community **`@ai-sdk-tool/parser`** package fixes exactly this with ready-made `hermesToolMiddleware` (Hermes/Qwen format) and `createToolMiddleware` (roll your own), which give function-calling to models that lack it natively by turning schemas into prompt instructions and parsing the replies. The local Mistral can orchestrate after all — with the documented caveat that you should *not* apply it to models that already do native tool calls. The SDK's built-ins also earn their place: `extractReasoningMiddleware` (pull `<think>…</think>` out of reasoning models) and `simulateStreamingMiddleware` (uniform streaming over non-streaming models).

## The bench (already built: pitwall)

Path: `~/pitwall`. TypeScript + Electron. Dependencies tell the story: `node-pty` + `@xterm/xterm` (a real terminal), `better-sqlite3` (the ledger), `chokidar` (file watching), `simple-git` (diffs), `@anthropic-ai/sdk` + `openai` (model adapters), `express` + `ws` (a server).

Two pieces of pitwall are *already* LogLine, by another name:

1. **`src/core/events/EventLedger.ts`** is an append-only SQLite ledger: `events(id, session_id, ts, type, payload_json)`, with live listeners. **That is the spine in miniature.** The `PitwallEvent` union already covers `pty.output`, `pty.input`, `file.changed`, `git.diff.snapshot`, `command.detected`, `test.detected`, `claim.detected`, `risk.detected`, `engineer.message`, `mission.state`, `lane.update`.
2. **`src/core/claims/types.ts`** — a `Claim` has `evidenceStatus: unverified | probe_proposed | evidence_captured | verified | failed | contradicted | inconclusive`. **That is the three routes already implemented:** `verified` → `if_ok`, `failed`/`contradicted` → `if_not`, everything else → `if_doubt`. The deliberate gap between `evidence_captured` and `verified` is the doc-2 rule "evidence does not, by itself, close anything" — already enforced in code.

So the bench doesn't need building. It needs **binding**: each `PitwallEvent` becomes an Act, each `Claim` transition becomes an Act's route, and the local SQLite ledger syncs up to the Supabase spine.

## The cockpit (already built: vibe-codin)

Path: `~/vibe-codin-.but.-real`. Next.js, with `components.json` (shadcn/ui), an `ai/` dir, and — telling — `Project-Manhattan-Official/` plus screenshots named `control-plane-home`, `code-lab-actual-components-repainted`, `control-plane-code-lab-fixed`. The three-screen cockpit from doc 5 (daily / control / work) is already repainted from a vibe-coding platform.

It also already has `PLAN-expose-hermes-webui.md`, a finished plan to expose the Hermes WebUI at `lab512-hermes.minilab.work` over the existing Cloudflare tunnel. So the cockpit ↔ agent ↔ phone path is mid-wiring, not unstarted.

## The one thing we actually write: the binding

Everything above already runs. The Lab in doc 3 exists the moment all of it speaks one language — the Act — against one spine. That binding layer is the whole of our net-new work:

```
1. lift the Rust engine out of _archive, `cargo build --release`, read the adapter spec
2. a small TypeScript "spine" package:
     - shape of an Act + receipt as JSON Schema (the conformance vectors are the spec)
     - emit(act): validate → shell out to LOGLINE_RUNTIME_BIN for the branch/receipt
       → write to local SQLite (pitwall's ledger) → sync to Supabase
     - read projections back from Supabase (registry, schedule, capacity)
3. adapters, one per edge — each just turns that edge's events into Acts:
     - pitwall   : PitwallEvent → Act (mostly a rename; the ledger is already there)
     - hermes    : a cron tick → Act; a skill run → Act + receipt
     - openclaw  : a task → Act; exec-approval → the "require" route
     - mcp        : the running host-runtime's calls → Acts (copy the ChatGPT app model)
     - model      : Vercel AI SDK middleware wrapping a standard OpenAI-compatible
                    provider (Mistral / Hermes) — redact → frame as Act → claim≠evidence
                    → canon engine verdict → receipt (replaces the dropped llm-gateway)
4. the policy JSON the gate reads (allow / require / deny), per doc 2
```

That's it. No engine, no scheduler, no database, no UI, no model gateway — all borrowed or already running. We write the Act binding and the policy, and we keep the discipline that *nothing crosses into execution except as a nine-slot Act.*

## The first probe (prove the architecture in one loop)

Before building the whole binding, run the smallest experiment that proves it can work — itself a doc-2 experiment with a falsifiable invariant:

```
intuition    the parts are all here; they just need one shared language
thesis       a scheduled tick can become an Act, get a real verdict, and be seen
invariant    one Hermes cron job writes one Act through the logline binary into
             Supabase, and pitwall (or the cockpit) shows it — with a receipt
probe        - cargo build --release the engine; confirm `logline parse-logline`
               accepts a hand-written nine-slot Act and returns a branch
             - add ONE Hermes cron job that shells that Act through the binary
             - have it INSERT the resulting Act+receipt into a Supabase table
             - confirm pitwall's ledger / the cockpit renders it live
observation  (to be filled by the run — claim ≠ evidence until then)
receipt      closes ONLY "a tick became a verified Act end to end," nothing more
```

### What's been run so far (2026-06-05): the engine half

A narrower sub-probe of the above has been executed, covering the *engine* leg only:

```
probe run    - lifted engine out of _archive to ~/logline-engine (existing canon, NOT a new one)
             - cargo build --release → clean, 25s, Rust 1.94, binary at target/release/logline
             - logline check-canon <existing conformance canon> → {"ok":true}
             - logline run on a REAL existing Act vector (sample.ok.logline):
                 · no evidence       → confirmed_by: doubt (receipt_missing) → if_doubt:suspend selected
                 · --evidence ana    → confirmed_by: ok (receipt_found)     → if_ok:execute selected,
                                        status pending → confirmed
observation  the engine builds and walks real Acts; the evidence pivot routes the SAME Act
             to if_doubt or if_ok purely on whether the witness is present. The three routes
             and the status lifecycle work in the real binary.
receipt      closes ONLY: "the existing Rust engine builds and correctly routes a real Act by
             evidence." It does NOT close the Hermes cron leg, the Supabase write, or the
             pitwall display — those remain blocked/unrun, the next steps.
```

### What's been run so far (2026-06-05): the model-middleware leg

Built and run on lab512 (`~/logline-model-middleware`, `ai@6` + `@ai-sdk/openai-compatible` + `@ai-sdk-tool/parser`):

```
probe run    - wrapLanguageModel({ model: openai-compatible(mistralrs @ 127.0.0.1:1234),
                 middleware: [redaction, ledger] })  — the POISONED gateway (:7700) bypassed
             - generateText with a planted secret (sk-…) in the prompt:
                 · [redaction] stripped 1 secret BEFORE the model saw it
                 · real completion came back from the local Mistral (slow: ~36s)
                 · [ledger] captured it as model.claim, evidenceStatus "evidence_captured" (NOT verified)
             - framed the claim as a 9-slot Act (confirmed_by:"none") and walked it through the
               canon engine (minilab logline walk): verdict branch="doubt", route="suspend",
               reason="receipt_missing"; receipt emitted (receipts/logline/1c9300d50fde1bbc/…)
observation  the full stack works with NO gateway: standard model → LogLine middleware → canon
             verdict → receipt. A raw model claim with no evidence is correctly routed to if_doubt,
             never accepted as truth. Secret redaction happens pre-model. claim≠evidence is enforced.
receipt      closes ONLY: "the model-middleware → canon-verdict → receipt loop works for one
             non-streaming call against the local model." It does NOT close: tool-calling via
             hermesToolMiddleware (the model emitted a function-call shape unprompted — next step),
             streaming, Hermes-as-model, or the Supabase write.

Leg A (the if_ok hinge) — also run, via the standalone `logline run --evidence` engine:
             claim "The capital of France is Paris." judged twice —
                 · no evidence            → branch=doubt,  route=suspend, status pending → doubt
                 · with independent witness → branch=ok, position=if_ok, route=record,
                                              reason=receipt_found, status pending → CONFIRMED
             Same Act, same claim; the witness alone moved it from doubt to confirmed. The full
             evidence hinge works through the live model→middleware→canon path.

Leg B (governed tool use — joins A) — middleware [redaction, ledger, hermesToolMiddleware]:
             - hermesToolMiddleware gave the non-native local Mistral real function-calling
             - the model called a real tool: lookup_capital("France") → "Paris", and the tool
               returned its OWN witness receipt: `receipt:lookup:france=Paris`
             - that witness was fed to the canon engine as evidence → branch=ok, if_ok, record,
               reason=receipt_found, status pending → CONFIRMED
             So B PRODUCES the evidence that A CONSUMES: model → governed tool → tool's receipt →
             canon if_ok. The whole arc runs gateway-free on lab512.
             (Minor: top-level result.toolCalls was empty though the tool executed — hermes
             surfaces parsed calls its own way; execution + witness are real.)
```

Spine write (the final leg) — DONE: `spine.mjs` took a fresh canon verdict (if_ok, status
             confirmed) and wrote it to the LIVE Supabase spine (project `jlwfigogxftsegzwmaon`,
             eu-central-1) via the Supavisor pooler (`aws-1-eu-central-1.pooler.supabase.com:5432`,
             user `postgres.<ref>`) — the broken outbox-worker path bypassed entirely. Created
             `logline_acts`, inserted the Act, read it back over direct Postgres AND over Supabase's
             REST API (PostgREST 200, after a `NOTIFY pgrst, 'reload schema'`). A verified Act now
             lives in the real spine and is queryable the way the cockpit/apps would read it.

Net: the ENTIRE arc is proven, gateway-free, end to end on lab512 —
   standard model → middleware (redact + claim≠evidence) → governed tool use (evidence) →
   canon engine verdict (if_doubt without evidence, if_ok with it) → LIVE Supabase spine → read back.
The remaining unrun pieces (streaming, Hermes-as-the-model, and routing through the Base gateway /
fixing the launchd outbox workers) are refinements, not unknowns. The thesis is demonstrated.

## Honest gaps and risks

- **The engine is in `_archive` and unbuilt.** It must be lifted to a live working copy and compiled before anything calls it. The adapter spec (`spec/logline.adapter.v0`) is unread in detail — it may simplify or complicate step 2.
- **The local model's weak tool use is now mitigated, not fatal.** OpenClaw's `lab512` provider declares `"supportsTools": false` (a Mistral-class 7B), but `@ai-sdk-tool/parser` middleware (`hermesToolMiddleware` / `createToolMiddleware`) adds function-calling by prompt-injection + parsing — so the local model can orchestrate, at some quality cost. Heavy reasoning still belongs on the cloud models pitwall already adapts (Claude / GPT); the local model is for cheap, high-volume standing work.
- **Hermes vs. OpenClaw is undecided.** They overlap. Pick one primary runtime after the first probe shows which emits Acts more cleanly.
- **External validation was rate-limited.** The "open-source standard" framing of Hermes (Nous Research) and OpenClaw is asserted here from the installed binaries and configs on this machine plus prior knowledge, not from a fresh web check (search hit a session limit). Re-confirm versions and licenses before depending on them.
- **Live secrets are sitting in a plaintext plan file.** `~/vibe-codin-.but.-real/PLAN-expose-hermes-webui.md` contains a real Doppler API token and a Hermes WebUI password in cleartext. Those should be rotated and pulled from Doppler at runtime, not committed to a doc. (Per doc 3: secrets are referenced and redacted, never written into files.)

---

This doc is the bridge from the idea to the keyboard. The rest of the set says *what* the Lab is; this one says *it's mostly already here — wire it.*

Back to **[README.md](README.md)** · or the core it all routes through: **[01_the_act.md](01_the_act.md)**.
