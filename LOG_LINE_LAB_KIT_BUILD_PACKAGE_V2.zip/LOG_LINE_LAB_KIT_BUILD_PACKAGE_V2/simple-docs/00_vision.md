# 0. Vision — what LogLine is, in one map

LogLine is a **protocol, not a company.** The goal is to show the world that LogLine can be *the brick of accountable computation* — a small, universal unit you can build with freely, the way TCP/IP, HTTP and git are built on by anyone, including empires, because nobody owns them.

## The one form

The canon has **forms, not names.** And, at the limit, it has **one** form:

> **The LogLine Act** — a record of nine slots:
> `who · did · this · when · confirmed_by · if_ok · if_doubt · if_not · status`

Everything else — receipt, passport, visa, runtime, gate, ghost, workorder, report, health check, experiment — is a **name** that lives in a *Convention Table*, introduced by a Lab Kit or a Pack. Those conventions can be strong, recommended, even de-facto standard, but **they do not modify the canon.** The Foundation defines only the Act and its canonical behavior.

Working forms (Lab Kit conventions, not canon) collapse to four, with one open table and one transversal layer:

```
1. Act          writes meaning                (the only canonical form)
2. Envelope     carries run provenance        (Lab Kit)
3. Projection   reads derived state           (Lab Kit)
4. Bundle       transports conventions        (Lab Kit)
+ Convention Table   names + uses             (where receipt/passport/visa/… live)
— content hash + signature   identity + accountability, across all of them
```

## Trust and build

> **We trust and build with LogLine.**

- **TRUST** has two faces: the canon is trustworthy *because it is minimal, strong and humble* — it witnesses facts, it does not own them; and the **anchor** lets anyone *verify* without trusting anyone. LogLine's trust is **trustless**: you don't trust the keeper, you check the math (content hash + signature, recomputable by anyone).
- **BUILD**: the Act is a polar, energy-rich monomer — like an amino acid. Few universal units, charged with consequence (`if_ok`/`if_doubt`/`if_not`), bonding by content-hash into emergent structures that are light, versatile, cheap and resilient. You don't stack LogLine like bricks; you fold it like protein.

## The three umbrellas

```
LogLine Foundation        publishes, does not operate. Frozen repos on GitHub.
  - the Act + its canon (the mold logline.receipt.v0)
  - conformance (byte-vectors, hash-profiles, schemas)
  - canonicalization + hash definition
  - governance (LIP), slow and rare
        │  anyone takes it, no permission
        ▼
LogLine Lab Kit           the generic installable; opinion-free
  - labd (host: marries the engines, clock, CLI, empty registries, pack import)
  - chooses Envelope, Projection, Bundle, Convention Table
  - chooses content_hash as identity, did:key anchors
        │  + a pack
        ▼
a Lab (an instance)       Lab Kit + a Pack + its own anchor + its own spine
  - Santo André Lab   = Kit + Santo André Pack   (digital face: minilab.work)
  - Manhattan Lab     = Kit + Manhattan Pack      (physical infra; own spine)
        ↔  inter-Lab contracts (Acts signed by both anchors) — federation
```

Foundation **holds** the protocol; a Lab **uses and extends** it through packs (public or private); Manhattan **keeps the physical floor alive** as a federated peer Lab. The first federation is **Santo André ↔ Manhattan**, verifiable by each Lab's published anchor — no shared database, no center.

## The anchor

Each Lab (and the Foundation) has its own **anchor**: a self-attested genesis Act, signed by its own key.

- identity = an **Ed25519 key** as a W3C **`did:key`** (a key is its own identifier — no registry, no server, no authority);
- the genesis Act is the **only** Act allowed `confirmed_by: self` — the fixed point where the chain touches the ground;
- its **content_hash** is the root every other Act chains back to;
- anyone verifies it offline: recompute the hash, check the signature, confirm `who == did:key`.

(See `templates/anchor.md` and the real example in `templates/examples/`.)

## Done — v1, in one sentence

> **`labd`, on the Capital (LAB 8GB), takes the L-06 contract, admits it, runs the real `ping` over the Ethernet bus, closes a receipt signed under Santo André's anchor, writes it to the spine, and minilab.work shows the machine healthy.**

When that happens once — admitted, probed, receipted, signed, projected — the protocol is proven end to end. Everything else is the same move, repeated.

---

```
The Act records.
The hash addresses.
The signature answers.
The projection reads.
The pack interprets.
The Foundation holds the form — and nothing more.

We trust and build with LogLine.
```
