# 2. The Method

This is how you actually work with Acts: how they get captured, decided, blocked, proven, read back, and how a language model is allowed to help without lying. None of this changes the Act — it's all *around* the Act.

## Capture first, judge later

The first job is to get the move written down honestly, even if it's ugly. Strictness comes later, at two moments only:

- when you decide to actually **run** something, and
- when you decide to **close** something as done.

Everywhere else, capture is generous. A recorded ugly truth beats a clean lie.

## The decision: allow, require, deny

When a pending Act is judged, there are exactly three answers. Not "maybe," not "warn and continue."

```
allow    →  run it now.
require  →  don't run yet; it needs a human (or a second signer) to confirm first.
deny     →  never run it; keep the line as a blocked Act.
```

Three clean answers means there is no soft, ambiguous middle where unsafe things slip through "just this once." If the information needed to decide is missing, the answer defaults to **deny** — you fail closed, not open.

## Blocked Acts

A **blocked Act** is an Act that was denied, or that is stuck because something it needs is missing. It is *not* an error and it is *not* hidden. It's a real, signed line that records the absence.

A blocked Act says, plainly:

- what was being attempted,
- what's missing (proof, permission, identity, a value, a signature),
- why that missing thing blocks it,
- who can unblock it, and what the next move would be.

Blocked Acts are how the system stays honest about what it *couldn't* do. Forty-seven denied transfers are forty-seven blocked Acts. A job that can't run because a secret is missing is a blocked Act. You never close over a blocked Act by pretending it succeeded — you either resolve it or you carry it forward, visibly.

> This is the idea the old docs called a "ghost." It's just a recorded non-event. We call it a blocked Act.

## Evidence is not a receipt

Be strict about these, because almost every lie in software lives in collapsing one into the next:

```
a claim          is not  evidence
a plan           is not  execution
execution        is not  success
a vendor's "200 OK"  is not  closure
an observation   is not  verification
a report         is not  a receipt
```

- **Evidence** is a recorded observation you can point back to: a command's output, a probe result, a measurement. It has a source and a scope. Evidence on its own does not close anything.
- **A receipt** is a *scoped* closure. It says: "these specific Acts are done, here is the evidence, here is exactly what is *not* covered, and here are the blocked Acts that remain." A receipt that claims more than its evidence supports is not a receipt — it's a story. **Receipts beat stories.**

A receipt closes only what it names. It never quietly closes the things around it.

## Projections: how you read Acts back

Acts are the source of truth. But a long list of Acts is hard to read, so you build **projections**: views computed *from* the Acts.

```
the registry        what exists right now
the evidence view   what's been observed
the receipt view    what's been closed
the blocked view    what's stuck and why
a report            a summary for a decision
```

The one rule that keeps this honest:

```
A projection gives you a useful reading.
A projection is never the source of truth.
```

If a projection and the Acts disagree, the Acts win. A database, a dashboard, a report — these are all projections. They remember and display; they never decide. You can throw a projection away and rebuild it from the Acts.

## Identity: same meaning, same bytes, same hash

Acts need stable identities so two parties can agree they're talking about the exact same line. LogLine does this with a strict, boring rule:

```
same meaning  →  same bytes  →  same hash
```

Before hashing, an Act is written in one canonical form — keys sorted, no stray whitespace, numbers and text normalized — so that two Acts that *mean* the same thing produce the exact same bytes, and therefore the exact same hash. The identity of an Act is the hash of its canonical bytes. (The working implementation uses JSON canonicalization per RFC 8785 and a content hash; you'll find it and its test vectors in the archive — see below.)

In practice there are three useful hashes traveling *around* an Act:

```
tuple hash      over the nine slots — the Act's core identity
content hash    over the full record minus its own id and hashes
envelope hash   over the Act plus how it was sent — computed at the moment of transport
```

You don't need to memorize these. The point is: identity is computed, deterministic, and verifiable by anyone holding the same bytes. No central registry required.

## Letting a language model help

A language model is allowed to do a lot of useful work here — and it is allowed to do exactly none of the dangerous parts. The line is simple:

**A model fills a role for one conversation. The role outlives the model. The model's output is never, by itself, the truth.**

A model **may**:

- draft Acts, restate messy input as clean Acts,
- name what evidence exists and what's missing,
- point out blocked Acts,
- prepare a decision for a human to make,
- write up a report.

A model **may not**:

- decide its own permissions or widen its own scope,
- run a protected action on its own,
- close a receipt,
- write directly to storage as if it were the source of truth,
- treat its own memory or fluent summary as a fact.

This prevents the most common failure with AI in the loop: a confident model walks in, rewrites the scope, invents some state, declares victory, and leaves. With LogLine, anything the model produces is just a *draft Act* until a human or a rule confirms it through the normal allow / require / deny path.

## Honest status, every day

The daily status of any Lab is allowed — required, even — to say what it doesn't know. A good status report preserves uncertainty instead of hiding it. These are all valid, first-class things to report:

```
unknown
no change observed
no evidence available
this Act is still blocked
this needs you
nothing needs you today
```

What is *forbidden* in a status: invented state, fake urgency, empty optimism, a plan dressed up as a result, a report dressed up as proof, or stale information shown as current.

## Where the working code lives

The real, running implementation of the parts above is in `_archive/`. The keeper pieces:

- **Receipt format + identity rules + test vectors** — `_archive/logline-foundation-canonical-repos 2/conformance-main/` (the JSON schema for a receipt, plus valid/invalid example files that any implementation must pass).
- **The Rust engine** — `_archive/logline-foundation-canonical-repos 2/engine-main/` (one small crate per slot, the canonicalization and hashing, and a `logline` command-line tool that parses, validates, and runs Acts).
- **A working service that emits and signs receipts** — `_archive/logline-foundation-canonical-repos 2/Ethics-is-Efficient-main/` (an HTTP service plus a verifier tool).

Treat the conformance vectors as the real spec. If the prose here and a test vector ever disagree, the test vector wins.

---

Next: **[03_the_lab.md](03_the_lab.md)** — putting all of this to work as a Lab.
