# 7. Glossary

Two lists. First: every word that survived, in plain English. Second: every old word that was thrown out, and what it became — so the bloat can't quietly creep back.

## Words that survived

**LogLine** — The whole idea: nothing happens until it's written down as an Act. Also the name of the project.

**Act** — The nine-slot tuple (`who, did, this, when, confirmed_by, if_ok, if_doubt, if_not, status`). The atomic unit. Both a contract and a recorded experiment. See [01_the_act.md](01_the_act.md).

**slot** — One of the nine fields of an Act.

**the three routes** — `if_ok` / `if_doubt` / `if_not`: confirmed, uncertain, falsified. Declared before acting; chosen by the evidence.

**confirmed_by** — The slot holding the evidence or witness. The pivot that decides which route an Act is really on.

**Lab** — A place that runs LogLine: emits Acts, decides them, runs them, stores them, reads them back. Declared by an Act. See [03_the_lab.md](03_the_lab.md).

**minilab.work** — Your Lab. The specific instance set up to study LogLine and run your machines.

**the gate** — The thing that answers allow / require / deny for a pending Act. Fails closed. *(Was: "Tower" / "authority" / "Constitutional Runtime.")*

**the worker** — The thing that runs an allowed Act on a real machine and returns evidence. *(Was: "Hermes.")*

**allow / require / deny** — The only three answers the gate can give. `require` means a human or second signer must confirm first.

**blocked Act** — An Act that was denied, or is stuck because something it needs is missing. A signed record of a non-event, never hidden. *(Was: "ghost.")*

**evidence** — A recorded observation with a source and a scope. Does not, by itself, close anything.

**receipt** — A scoped closure: names exactly which Acts are done, the evidence, what's *not* covered, and what blocked Acts remain. "Receipts beat stories."

**projection** — A view computed from Acts (a registry, a report, the database, a dashboard). Useful for reading; never the source of truth.

**spine** — The online store of Acts that is the source of truth for a Lab. Local caches and files are not the spine.

**canonical form** — The one exact byte-for-byte way of writing an Act so that the same meaning always produces the same hash. The basis of an Act's identity.

**brake** — A safety switch that defaults to off/deny (e.g. "dry run," "allow running jobs"). Must be explicitly released. Being released is not permission — the gate still decides.

**the ruler / NOW** — The present, sweeping the timeline of Acts (ordered by their `when`) at Earth's real pace — one heartbeat, not a thousand alarms. Where it reaches NOW, a due Act must resolve. The Lab *executes contracts*; the ruler is how it does so on time. See [03_the_lab.md](03_the_lab.md).

**due** — An Act the ruler has reached. A due Act must run (`if_ok`), wait/ask/retry (`if_doubt`), fail (`if_not`), or be rescheduled by a new Act — never silently skipped.

**the band** — The Lab's healthy load range. *Over the band:* warn, slide, refuse contracts it can't honor. *Under the band:* a defect — an idle Lab is a broken Lab, so it pulls standing work.

**standing work** — What agents do when no human and no scheduled Act claims them: research, tend, organize, communicate, think, enhance, help. Fills empty slots so the Lab runs 24/7 honestly, never idle.

**Manhattan** — The system that runs and repairs your three machines (`LAB_8GB`, `LAB_512`, `LAB_256`) and lets you drive them from your phone. See [06_manhattan.md](06_manhattan.md).

**checklist item (L-01…L-30)** — One concrete thing Manhattan keeps true on a machine, with a probe, an expected state, a repair, and a receipt.

**daemon / agent** — Manhattan's two always-running loops (system-level and user-level) that observe, repair drift, and observe again.

**core** — The one thing we build and own: the Act and its discipline (validate, canonical form, hash, sign, the three routes). Tiny, written in Rust, never changes for your domain. See [03_the_lab.md](03_the_lab.md).

**pack** — An opinionated plugin that increments LogLine the way you want: domain verbs, golden configs, default policy, projections. JSON plus assets. Adds capability; never edits the core. *(Replaces the old "doctrine/canon" bundles.)*

**profile** — A JSON config choosing which proven, off-the-shelf tools a Lab runs on (Postgres spine, SQLite cache, OAuth auth…). Swap the profile, run the same Lab on different tools.

**app / Lab Connection app** — A program that plugs into the Lab over MCP, the way apps plug into ChatGPT. It's an entity with a scoped grant; it can only propose Acts. See [04_apps_and_cli.md](04_apps_and_cli.md).

**MCP** — The Model Context Protocol: the open standard ChatGPT-style apps use to connect. We adopt it instead of inventing a plugin API.

**grant** — An Act that gives an app (or anyone) a scoped, time-limited permission: which verbs, which resources, for how long. Revoked by a later Act. *(The old docs called this a "visa.")*

**the borrow rule** — Own the rules, borrow everything else. Write down only what's genuinely different about LogLine (as JSON), and hand it to proven open-source tools to obey. If you're building infrastructure, stop.

**the bench** — Where you work day to day: coding or running experiments, with the LLM co-scientist beside you. See [05_the_bench.md](05_the_bench.md).

**the co-scientist** — The LLM working beside you like a pit-wall race engineer: it watches the same real screen you do (terminal, diffs, tests, receipts), reports only what's actually there, and keeps pointing at claims that don't yet have evidence. It proposes; it never decides or fakes.

**experiment** — A piece of finding-out, structured as a ladder of Acts: `intuition → thesis → invariant → probe → observation → receipt`. Governed by one rule: never let beauty outrun evidence.

**invariant** — A claim stated so it can be falsified: what should hold, and what would break it.

**probe** — The test, command, or inspection that would actually show whether an invariant holds. No claim is counted until its probe has been run.

**the cockpit** — The human-facing UI: the day's notebook, the control plane (machines, registry, policies), and the code bench in one screen. It's the face, never the source of truth, and it speaks plain language, not engine jargon.

**plain-language rule** — The cockpit always translates the engine into human words: *Worked ✓ / Didn't ✗ / Waiting on you ⏸ / Missing proof ⚠*. *(The old docs called this the "lexicon.")*

## Words that were thrown out

These are gone. The middle column is the plain replacement; "deleted" means the word was pure costume and the idea (if any) is just stated directly now.

| Old word | Now say… | Why it's gone |
|---|---|---|
| canon | the rules / the spec | Dressed-up word for "the agreed rules." |
| doctrine | (deleted) | Padding. State the rule plainly. |
| constitutional / constitution | the setup / the rules | Grandiose. It's just how the Lab is configured. |
| institution | the Lab / the project | Inflation. It's a Lab. |
| ontology | the words we use | "Glossary" is the honest word — this file. |
| Tower / Torre | the gate | A role: it decides allow/require/deny. |
| Hermes | the worker | A role: it runs allowed Acts. |
| ghost | blocked Act | A recorded non-event. Plain term is clearer. |
| organs / jurisdictions | roles / who's responsible | Body-and-state metaphor that added nothing. |
| LLM offices | the rules for letting a model help | See [02_the_method.md](02_the_method.md). The idea was good; the costume wasn't. |
| morning state ritual | the daily status report | A status report that preserves uncertainty. |
| founding act | the Act that declares the Lab | It's just an Act. |
| Dan Control Plane | the Lab's tools (CLI + endpoints) | The way you touch the Lab. |
| Doppler (as authority) | the secrets manager / settings | A place to keep secrets and settings. It grants no permission. |
| Santo André Laboratory | a Lab setup | One example setup, not a universal truth. |
| primitives / primitive system | Acts | Everything is an Act. |
| passport | entity / the register Act | Identity is just the `register_entity` Act and its hash. |
| visa | grant | A scoped, time-limited permission Act. |
| profile / pack (old jargon sense) | profile / pack (kept, cleaned) | Now plain: profile = which tools; pack = a plugin. See above. |
| Ethics is Efficient | (deleted as framing) | A real cost argument lives in the archive; it's not a law. |
| Chip as Code / Hardware as Text / SecurityOS | (deleted as framing) | Big slogans. The real mechanisms (canonical hashing, the gate) are kept under plain names. |
| Declaration of Invention / Manifesto | (deleted) | Ceremony. The ideas stand on their own. |
| gates G1–G4, lineage IDs, RFC-2119 ceremony | (deleted) | Paper formality that obscured simple rules. |

## A note on the archive

Everything above came *from* the two years of material now in `_archive/`. The ideas are yours and they're intact. What changed is only the language: one tongue, plain words, and LogLine as the single special vocabulary. If you ever reach for one of the words in the right-hand column, that's the signal to stop and say the plain thing instead.

---

Back to **[README.md](README.md)**.
